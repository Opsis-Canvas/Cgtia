/**
 * Admin-only Firebase web app (same project: verify-cgtia-cert)
 * Auth uses browser session persistence: closing the tab requires sign-in again.
 */
const firebaseConfig = {
  apiKey: "AIzaSyCZOA3OxPyRyRT9XUTsFTUWKViFmkpfOV0",
  authDomain: "verify-cgtia-cert.firebaseapp.com",
  projectId: "verify-cgtia-cert",
  storageBucket: "verify-cgtia-cert.firebasestorage.app",
  messagingSenderId: "766655761701",
  appId: "1:766655761701:web:d59853909358bf3b9b5ecc",
  measurementId: "G-GV8D6MVNT1"
};

let _api = null;

function friendlyFirebaseError(err) {
  const msg = String((err && err.message) || err || "");
  const code = String((err && err.code) || "");
  if (/Failed to fetch|dynamically imported|Load failed|NetworkError|network/i.test(msg) || code === "auth/network-request-failed") {
    return "We could not connect to the database. Check your internet connection, then refresh this page. If it keeps happening, try another network or turn off any VPN/ad-blocker for this site.";
  }
  if (/auth\/invalid-credential|auth\/wrong-password|auth\/user-not-found|auth\/invalid-email/i.test(code + msg)) {
    return "That email or password is not correct. Please try again.";
  }
  if (/auth\/too-many-requests/i.test(code + msg)) {
    return "Too many sign-in attempts. Please wait a few minutes and try again.";
  }
  if (/auth\/user-disabled/i.test(code + msg)) {
    return "This account has been disabled. Contact the site owner.";
  }
  if (/permission|insufficient/i.test(msg)) {
    return "You do not have permission to do that. Ask the site owner to check your access.";
  }
  // Never show long technical URLs to staff
  if (/gstatic\.com|firebasejs|https?:\/\//i.test(msg)) {
    return "Something went wrong while starting the admin tools. Please refresh the page. If it continues, check your internet connection.";
  }
  if (msg.length > 160) return "Something went wrong. Please refresh the page and try again.";
  return msg || "Something went wrong. Please try again.";
}

export async function getDb() {
  if (_api) return _api;
  try {
  const { initializeApp, getApps, getApp } = await import("https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js");
  const {
    getFirestore, collection, getDocs, doc, getDoc, setDoc, updateDoc, deleteDoc, serverTimestamp, query, orderBy, limit
  } = await import("https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js");
  const { getStorage, ref: storageRef, uploadBytes, getDownloadURL } = await import("https://www.gstatic.com/firebasejs/10.12.2/firebase-storage.js");
  const {
    getAuth, signInWithEmailAndPassword, signOut, onAuthStateChanged,
    setPersistence, browserSessionPersistence
  } = await import("https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js");
  const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
  const db = getFirestore(app);
  const auth = getAuth(app);
  const storage = getStorage(app);
  // Session only — survives refresh in the same tab, not a new visit after closing the tab/browser
  try {
    await setPersistence(auth, browserSessionPersistence);
  } catch (e) {
    console.warn("Auth persistence:", e);
  }
  _api = {
    db, auth, collection, getDocs, doc, getDoc, setDoc, updateDoc, deleteDoc,
    serverTimestamp, query, orderBy, limit, signInWithEmailAndPassword, signOut, onAuthStateChanged,
    setPersistence, browserSessionPersistence,
    storage, storageRef, uploadBytes, getDownloadURL
  };
  return _api;
  } catch (err) {
    const e = new Error(friendlyFirebaseError(err));
    e.cause = err;
    throw e;
  }
}

export { friendlyFirebaseError };

/** Current staff profile from users/{uid} */
export async function getMyProfile() {
  const api = await getDb();
  const u = api.auth.currentUser;
  if (!u) return null;
  try {
    const snap = await api.getDoc(api.doc(api.db, "users", u.uid));
    if (!snap.exists()) return { uid: u.uid, email: u.email, role: null, active: false, missing: true };
    return { uid: u.uid, email: u.email, ...snap.data() };
  } catch (e) {
    return { uid: u.uid, email: u.email, role: null, active: false, error: e.message };
  }
}

/** Roles allowed into the CMS UI */
export function isStaffAllowed(profile) {
  if (!profile || profile.missing) return false;
  if (profile.active === false) return false;
  // Normalize: super_admin and super-admin both OK
  const role = String(profile.role || "").toLowerCase().replace(/_/g, "-");
  return ["super-admin", "admin", "admissions", "registrar", "licensing-officer", "training-officer", "instructor"].includes(role);
}
