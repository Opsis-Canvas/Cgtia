import { createElement, useEffect, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import htm from "htm";
import { getDb as getDbRaw, getMyProfile, isStaffAllowed, friendlyFirebaseError } from "./firebase.js";

async function getDb() {
  return liveAware(await getDbRaw());
}

const IMAGE_BASE_URL = "https://cgtia-assets.netlify.app";

/** Public student-facing site base URL (payment links, invites). You can type any host. */
const PUBLIC_SITE_STORAGE_KEY = "cgtia_public_site_base";
const PUBLIC_SITE_PRESETS = [
  "https://cgtia.com.ng",
  "https://cgtia.netlify.app",
  "https://cgtia.org"
];
function getStoredPublicSite() {
  try {
    const v = localStorage.getItem(PUBLIC_SITE_STORAGE_KEY);
    if (v && /^https?:\/\//i.test(v.trim())) return v.trim().replace(/\/$/, "");
  } catch (e) {}
  return "https://cgtia.com.ng";
}
function setStoredPublicSite(url) {
  try {
    const u = String(url || "").trim().replace(/\/$/, "");
    if (u) localStorage.setItem(PUBLIC_SITE_STORAGE_KEY, u);
  } catch (e) {}
}
function PublicSiteDomainField(props) {
  const domain = props.domain;
  const setDomain = props.setDomain;
  return html`
    <div class="form-row">
      <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Public site base URL (for the link)</label>
      <input
        type="url"
        required
        list="cgtia-public-site-presets"
        value=${domain}
        placeholder="https://cgtia.com.ng or your Cloudflare URL"
        onInput=${(e) => {
          const v = e.target.value;
          setDomain(v);
          setStoredPublicSite(v);
        }}
      />
      <datalist id="cgtia-public-site-presets">
        ${PUBLIC_SITE_PRESETS.map((d) => html`<option key=${d} value=${d}></option>`)}
      </datalist>
      <p class="muted" style=${{ margin: "0.35rem 0 0", fontSize: "0.7rem" }}>
        Type or paste any URL (Cloudflare workers.dev or https://cgtia.com.ng). Saved on this browser.
      </p>
    </div>
  `;
}


/** Soft-delete / trash for invites & payment links */
const TRASH_COLLECTIONS = ["studentInvites", "licensingInvites", "feePaymentLinks", "programs", "promotions", "certificates", "students", "siteMedia"];
const TRASH_RETENTION_KEY = "cgtia_trash_retention_days";

function getTrashRetentionDays() {
  try {
    const n = parseInt(localStorage.getItem(TRASH_RETENTION_KEY) || "30", 10);
    return n === 90 ? 90 : 30;
  } catch (e) {
    return 30;
  }
}
function setTrashRetentionDays(days) {
  try {
    localStorage.setItem(TRASH_RETENTION_KEY, String(days === 90 ? 90 : 30));
  } catch (e) {}
}
function isTrashed(row) {
  return !!(row && (row.deleted === true || row.trashed === true));
}
function trashMeta(days) {
  const d = days === 90 ? 90 : 30;
  const deletedAt = new Date().toISOString();
  const purgeAt = new Date(Date.now() + d * 86400000).toISOString();
  return {
    deleted: true,
    trashed: true,
    active: false,
    revoked: true,
    deletedAt,
    trashPurgeAt: purgeAt,
    trashRetentionDays: d
  };
}
function parseTime(v) {
  if (!v) return null;
  if (typeof v.toDate === "function") return v.toDate().getTime();
  if (v._seconds) return v._seconds * 1000;
  const ms = new Date(v).getTime();
  return isNaN(ms) ? null : ms;
}
async function moveToTrash(collection, id) {
  const api = await getDb();
  const ref = api.doc(api.db, collection, id);
  const before = await api.getDoc(ref);
  const prev = before.exists() ? before.data() : {};
  const meta = trashMeta(getTrashRetentionDays());
  await api.setDoc(ref, {
    ...meta,
    trashPrev: { active: prev.active === undefined ? null : prev.active, revoked: prev.revoked === undefined ? null : prev.revoked },
    updatedAt: api.serverTimestamp()
  }, { merge: true });
  return meta;
}
async function restoreFromTrash(collection, id) {
  const api = await getDb();
  const snap = await api.getDoc(api.doc(api.db, collection, id));
  const prev = (snap.exists() && snap.data().trashPrev) || {};
  await api.setDoc(api.doc(api.db, collection, id), {
    deleted: false,
    trashed: false,
    active: prev.active === null || prev.active === undefined ? true : prev.active,
    revoked: prev.revoked === null || prev.revoked === undefined ? false : prev.revoked,
    trashPrev: null,
    deletedAt: null,
    trashPurgeAt: null,
    updatedAt: api.serverTimestamp()
  }, { merge: true });
}
async function hardDeleteDoc(collection, id) {
  const api = await getDb();
  if (typeof api.deleteDoc === "function") {
    await api.deleteDoc(api.doc(api.db, collection, id));
  } else {
    await api.setDoc(api.doc(api.db, collection, id), {
      deleted: true,
      purged: true,
      active: false,
      updatedAt: api.serverTimestamp()
    }, { merge: true });
  }
}

function assetUrl(path) {
  if (!path) return "";
  const p = String(path).trim();
  if (/^https?:\/\//i.test(p)) return p;
  return IMAGE_BASE_URL.replace(/\/$/, "") + "/" + p.replace(/^\//, "");
}


const html = htm.bind(createElement);

const SECTION_KEYWORDS = {
  dashboard: "overview summary numbers", applications: "application applicant answers apply student message custom questions",
  payments: "payment paystack transfer money receipt", fees: "fee payment link pay who can pay payer email students instalment",
  students: "student record reg number cohort start date status portal", courses: "course module subject curriculum certificate diploma hibernate", assessments: "test assignment exam quiz homework", grades: "grade result mark score exam transcript teacher", transcript: "transcript official print lock average sheet", notifications: "portal notification bell student push notice", schedule: "timetable class schedule day time room tutor", attendance: "attendance present absent session mark", supportMessages: "student message support help reply portal", answerQueries: "answer query question review complaint test marking", invites: "profile invite link student token",
  certificates: "certificate code verify issued", idcards: "id card identity photo", licences: "licence license licensing certificate",
  users: "users roles staff access admin", promotions: "promotion promo banner discount offer",
  programs: "programme program fee price amount cost write-up subtitle features bullets start date tuition",
  wall: "wall of fame honoree", graduates: "graduate alumni", partners: "partner placement hospital",
  contact: "contact message enquiry", contactPage: "contact page address phone email office hours faq form heading",
  tuitionPage: "tuition page title intro notes payment fees paragraphs heading home", homePage: "home page hero approach practice tuition", aboutPage: "about page history mission board goals", galleryPage: "gallery page photos graduation classes", programsPage: "programs page hero track diploma delivery cards sections", legalPages: "terms privacy policy section legal wording",
  applyForm: "apply form application label question field required dropdown submit", pageControl: "page visibility on off maintenance not found hidden live 404",
  institutional: "institutional inquiry custom training", licrequests: "licensing request", licinvites: "licensing invite link",
  insights: "insight article note blog", media: "image photo picture upload media", backup: "backup export download",
  verifyFields: "verify verification public private show hide certificate id card licence student record", trash: "trash restore delete purge", settings: "site settings cohort label footer year"
};

const SECTIONS = [
  ["profile", "My profile"],
  ["dashboard", "Dashboard"],
  ["applications", "Applications"],
  ["payments", "Payments"],
  ["fees", "Fees & payment links"],
  ["students", "Students"],
  ["courses", "Modules"],
  ["assessments", "Tests & assignments"],
  ["grades", "Results / grades"],
  ["transcript", "Transcript"],
  ["resultsSummary", "Results summary"],
  ["notifications", "Portal notifications"],
  ["schedule", "Class schedule"],
  ["attendance", "Attendance"],
  ["supportMessages", "Student messages"],
  ["answerQueries", "Answer queries"],
  ["invites", "Profile invites"],
  ["certificates", "Certificates"],
  ["idcards", "ID cards"],
  ["licences", "Licences"],
  ["users", "Users & roles"],
  ["promotions", "Promotions"],
  ["dashboardSlides", "Dashboard carousel"],
  ["programs", "Programme cards"],
  ["homePage", "Home page"],
  ["aboutPage", "About page"],
  ["galleryPage", "Gallery page"],
  ["programsPage", "Programs page"],
  ["wall", "Wall of Fame"],
  ["graduates", "Graduates"],
  ["partners", "Partners"],
  ["contact", "Contact messages"],
  ["contactPage", "Contact page"],
  ["tuitionPage", "Tuition page"],
  ["legalPages", "Terms & Privacy"],
  ["applyForm", "Apply form"],
  ["pageControl", "Page visibility"],
  ["verifyFields", "Verification display"],
  ["institutional", "Institutional inquiries"],
  ["licrequests", "Licensing requests"],
  ["licinvites", "Licensing invites"],
  ["insights", "Insights"],
  ["media", "Images / media"],
  ["backup", "Backup / export"],
  ["trash", "Trash"],
  ["portalSettings", "Student portal"],
  ["settings", "Site settings"]
];

function toast(message, kind) {
  let host = document.getElementById("cgtiaToastHost");
  if (!host) {
    host = document.createElement("div");
    host.id = "cgtiaToastHost";
    host.style.cssText = "position:fixed;z-index:400;left:0;right:0;bottom:16px;display:flex;flex-direction:column;align-items:center;gap:8px;pointer-events:none;padding:0 12px";
    document.body.appendChild(host);
  }
  const tone = kind === "error"
    ? { bg: "#fef2f2", fg: "#991b1b", bar: "#dc2626", icon: "✕" }
    : kind === "warn"
      ? { bg: "#fffbeb", fg: "#92400e", bar: "#d97706", icon: "!" }
      : { bg: "#f0fdf4", fg: "#166534", bar: "#16a34a", icon: "✓" };
  const el = document.createElement("div");
  el.setAttribute("role", kind === "error" ? "alert" : "status");
  el.style.cssText = "pointer-events:auto;display:flex;align-items:flex-start;gap:10px;max-width:420px;width:100%;box-sizing:border-box;background:" + tone.bg + ";color:" + tone.fg + ";border:1px solid rgba(0,0,0,0.06);border-left:4px solid " + tone.bar + ";border-radius:12px;padding:11px 14px;box-shadow:0 10px 28px rgba(0,0,0,0.14);font-size:14px;line-height:1.4;opacity:0;transform:translateY(8px);transition:opacity .2s,transform .2s";
  const icon = document.createElement("span");
  icon.textContent = tone.icon;
  icon.style.cssText = "font-weight:800;flex:0 0 auto;width:18px;text-align:center";
  const text = document.createElement("span");
  text.textContent = message;
  el.append(icon, text);
  host.appendChild(el);
  requestAnimationFrame(function () { el.style.opacity = "1"; el.style.transform = "translateY(0)"; });
  setTimeout(function () { el.style.opacity = "0"; setTimeout(function () { el.remove(); }, 250); }, kind === "error" ? 6000 : 3500);
}

function escAdmin(v) {
  return String(v).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

/* In-app confirmation sheet (replaces the browser pop-up). Resolves true or false. */
function askConfirm(message, opts) {
  const o = opts || {};
  return new Promise(function (resolve) {
    const back = document.createElement("div");
    back.className = "modal-back";
    back.setAttribute("role", "dialog");
    back.setAttribute("aria-modal", "true");
    const danger = o.danger !== false && /delete|remove|revoke|permanent|trash|sign out|cancel/i.test(message);
    back.innerHTML =
      '<div class="modal sheet-up">' +
      '<h2 class="modal-title">' + escAdmin(o.title || (danger ? "Are you sure?" : "Please confirm")) + "</h2>" +
      '<p class="modal-text">' + escAdmin(message) + "</p>" +
      '<div class="modal-actions">' +
      '<button type="button" class="ghost" data-no>' + escAdmin(o.cancelText || "Cancel") + "</button>" +
      '<button type="button" class="' + (danger ? "danger" : "primary") + '" data-yes>' + escAdmin(o.okText || (danger ? "Yes, continue" : "OK")) + "</button>" +
      "</div></div>";
    const onKey = function (e) { if (e.key === "Escape") done(false); };
    const done = function (v) {
      document.removeEventListener("keydown", onKey);
      back.remove();
      resolve(v);
    };
    back.addEventListener("click", function (e) {
      if (e.target === back || e.target.hasAttribute("data-no")) done(false);
      else if (e.target.hasAttribute("data-yes")) done(true);
    });
    document.addEventListener("keydown", onKey);
    document.body.appendChild(back);
    const yes = back.querySelector("[data-yes]");
    if (yes) yes.focus();
  });
}

/* Delivery check: a save is confirmed only once the website reads the new version */
const LIVE_PATHS = /^(siteContent|promotions|programs)\//;
function liveAware(api) {
  const wrapped = Object.create(api);
  wrapped.setDoc = function (ref, data, opts) {
    const path = ref && ref.path;
    const counts = data && typeof data === "object" && data.updatedAt !== undefined && data.trashed === undefined && data.trashPrev === undefined;
    if (path && LIVE_PATHS.test(path) && counts) {
      const token = Math.random().toString(36).slice(2, 12) + Date.now().toString(36);
      return api.setDoc(ref, Object.assign({}, data, { publishToken: token }), opts).then(function (res) {
        scheduleLiveCheck(path, token);
        return res;
      });
    }
    return api.setDoc(ref, data, opts);
  };
  return wrapped;
}
async function scheduleLiveCheck(path, token) {
  let ok = false;
  const base = getStoredPublicSite();
  for (let i = 0; i < 6 && !ok; i++) {
    await new Promise(function (r) { setTimeout(r, 1500); });
    try {
      const res = await fetch(base + "/api/content-check?path=" + encodeURIComponent(path) + "&token=" + encodeURIComponent(token));
      const j = await res.json();
      ok = !!j.found;
    } catch (e) { /* try again */ }
  }
  toast(ok
    ? "Saved. The website is showing the new version."
    : "Saved, but the website has not picked it up yet. Wait a minute, refresh the website and check again.",
    ok ? "ok" : "warn");
}

function Badge({ status }) {
  const s = String(status || "—").toLowerCase();
  let cls = "pending";
  if (s.includes("paid") || s === "active" || s === "completed") cls = "paid";
  else if (s.includes("unpaid") || s === "inactive" || s === "false" || s === "pending") cls = s.includes("unpaid") ? "unpaid" : "pending";
  return html`<span class=${"badge " + cls}>${status || "—"}</span>`;
}

function Login({ onAuthed }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setLoading(true);
    setErr("");
    try {
      const api = await getDb();
      await api.signInWithEmailAndPassword(api.auth, email.trim(), password);
      onAuthed(api.auth.currentUser);
    } catch (ex) {
      setErr(friendlyFirebaseError(ex) || "Could not sign in. Check your email and password.");
    } finally {
      setLoading(false);
    }
  }

  return html`
    <div class="login-page">
      <div class="login-card">
        <div class="login-brand"><span class="brand-mark">C</span><span>CGTIA Admin</span></div>
        <h1 class="login-title">Sign in</h1>
        <p class="login-sub">For staff only. You will be signed out when you close this tab.</p>
        <form class="login-form" onSubmit=${submit}>
          <label class="field"><span>Email</span>
            <input type="email" autocomplete="username" placeholder="you@example.com" value=${email} onInput=${(e) => setEmail(e.target.value)} required /></label>
          <label class="field"><span>Password</span>
            <input type="password" autocomplete="current-password" placeholder="Your password" value=${password} onInput=${(e) => setPassword(e.target.value)} required /></label>
          ${err ? html`<p class="login-err" role="alert">${err}</p>` : null}
          <button class="login-btn" type="submit" disabled=${loading}>${loading ? "Signing in…" : "Sign in"}</button>
        </form>
        <p class="login-foot">Need help getting in? Contact the site owner.</p>
      </div>
    </div>
  `;
}

function ProfileBanner({ profile }) {
  if (!profile) return null;
  if (profile.missing) {
    return html`<div class="card" style=${{ borderColor: "#fca5a5", marginBottom: "1rem" }}>
      <p class="error"><strong>Your account is not on the staff list yet.</strong></p>
      <p class="muted">Ask the site owner to add you. Until then you cannot see or change anything here.</p>
    </div>`;
  }
  if (profile.active === false) {
    return html`<div class="card" style=${{ marginBottom: "1rem" }}>
      <p class="error">Your access has been turned off, so you cannot manage the website. Ask the site owner to turn it back on.</p>
    </div>`;
  }
  const role = profile.role || "—";
  return null;
}

function ApplicationsPanel() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");
  const [openId, setOpenId] = useState("");
  const [appTab, setAppTab] = useState("waiting");
  const isPaid = (r) => (r.paymentStatus || "") === "paid";
  const shown = rows.filter((r) => appTab === "all" || (appTab === "paid" ? isPaid(r) : !isPaid(r)));

  async function load() {
    setLoading(true);
    setErr("");
    try {
      const api = await getDb();
      const snap = await api.getDocs(api.collection(api.db, "applications"));
      const list = [];
      snap.forEach((d) => list.push({ id: d.id, ...d.data() }));
      list.sort((a, b) => String(b.createdAt?.seconds || 0) - String(a.createdAt?.seconds || 0));
      setRows(list);
      setMsg(list.length + " application(s)");
    } catch (e) {
      setErr("Could not load applications: " + (e.message || e.code || "you do not have permission to see this. Ask the site owner to check your access."));
      setRows([]);
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { load(); }, []);

  async function markPaid(id) {
    try {
      const api = await getDb();
      await api.updateDoc(api.doc(api.db, "applications", id), {
        paymentStatus: "paid",
        status: "paid",
        updatedAt: api.serverTimestamp()
      });
      setMsg("Marked paid: " + id);
      load();
    } catch (e) {
      setErr("Could not update: " + (e.message || e));
    }
  }

  return html`
    <div>
      <h1>Applications</h1>
      <p class="sub">Live list of applications.</p>
      <${SubTabs}
        tabs=${[
          { id: "waiting", label: "Waiting for payment (" + rows.filter((r) => !isPaid(r)).length + ")" },
          { id: "paid", label: "Paid (" + rows.filter(isPaid).length + ")" },
          { id: "all", label: "All (" + rows.length + ")" }
        ]}
        active=${appTab}
        onChange=${setAppTab}
        menu=${[{ label: "Refresh", run: () => window.dispatchEvent(new Event("cgtia:refresh")) }]} />
      <${ProfileHint} />
      ${msg ? html`<p class="muted">${msg}</p>` : null}
      ${err ? html`<p class="error">${err}</p>` : null}
      <button class="ghost" style=${{ marginBottom: "0.75rem" }} onClick=${load}>Refresh</button>
      <div class="table-wrap">
        <table>
          <thead>
            <tr><th>Name</th><th>Email</th><th>Program</th><th>Payment</th><th>Plan</th><th>Actions</th></tr>
          </thead>
          <tbody>
            ${loading ? html`<tr><td colspan="6"><${Skeleton} rows=${3} /></td></tr>` : null}
            ${!loading && !shown.length ? html`<tr><td colspan="6">Nothing in this tab yet.</td></tr>` : null}
            ${shown.map((r) => html`
              <tr key=${r.id}>
                <td>${r.fullName || "—"}</td>
                <td>${r.email || r.id}</td>
                <td>${r.program || "—"}</td>
                <td><${Badge} status=${r.paymentStatus || r.status || "unpaid"} /></td>
                <td class="muted">${r.paymentPlan || "—"} · ${r.installmentsPaid || 0}/${r.installmentsTotal || 1}</td>
                <td>
                  <button class="ghost" type="button" onClick=${() => setOpenId(openId === r.id ? "" : r.id)}>${openId === r.id ? "Hide answers" : "Answers"}</button>
                  ${(r.paymentStatus || "") !== "paid"
                    ? html`<button class="ghost" onClick=${() => markPaid(r.id)}>Mark paid</button>`
                    : html`<span class="muted">Paid</span>`}
                </td>
              </tr>
            `)}
          </tbody>
        </table>
      ${rows.filter((r) => r.id === openId).map((r) => html`
        <div class="card" style=${{ marginTop: "1rem" }}>
          <h3 style=${{ marginBottom: "0.5rem" }}>${r.fullName || r.email || r.id}</h3>
          ${r.message ? html`<div class="form-row"><label class="muted">Message</label><div>${r.message}</div></div>` : null}
          ${Array.isArray(r.customAnswers) && r.customAnswers.length
            ? r.customAnswers.map((a) => html`<div class="form-row"><label class="muted">${a.label}</label><div>${a.value || "—"}</div></div>`)
            : html`<p class="muted">No extra answers were saved for this application.</p>`}
        </div>`)}
      </div>
    </div>
  `;
}

function ProfileHint() {
  return null;
}

function PaymentsPanel() {
  const [rows, setRows] = useState([]);
  const [err, setErr] = useState("");
  const [filter, setFilter] = useState("all");
  const [payTab, setPayTab] = useState("list");
  const [cash, setCash] = useState({
    fullName: "",
    email: "",
    program: "certificate",
    amount: "",
    status: "paid",
    installmentsTotal: "1",
    installmentsPaid: "1",
    nextDueDate: "",
    installmentIntervalDays: "30",
    notes: ""
  });

  async function load() {
    try {
      const api = await getDb();
      const snap = await api.getDocs(api.collection(api.db, "payments"));
      const list = [];
      snap.forEach((d) => list.push({ id: d.id, ...d.data() }));
      list.sort((a, b) => {
        const ta = a.createdAt?.seconds || a.paidAt?.seconds || 0;
        const tb = b.createdAt?.seconds || b.paidAt?.seconds || 0;
        return tb - ta;
      });
      setRows(list);
      // Flag overdue installment rows (best-effort)
      list.forEach((r) => {
        const paid = Number(r.installmentsPaid || 0);
        const total = Number(r.installmentsTotal || 1);
        if (paid < total && r.nextDueDate) {
          const dueMs = new Date(r.nextDueDate).getTime();
          if (!isNaN(dueMs) && Date.now() > dueMs && !r.defaulted) {
            // soft-mark in UI only; full write on next open via markDefaultedIfNeeded when reminding
          }
        }
      });
    } catch (e) {
      setErr("Could not load payments: " + (e.message || e));
    }
  }
  useEffect(() => { load(); }, []);

  function displayMethod(r) {
    const m = String(r.method || r.channel || r.paymentMethod || "").toLowerCase();
    if (!m) return "—";
    if (m === "cash") return "cash";
    if (m.includes("transfer") || m === "bank" || m === "dedicated_nuban" || m === "bank_transfer") return "bank transfer";
    if (m === "ussd") return "ussd";
    if (m === "card") return "card";
    return m;
  }

  function displayAmount(r) {
    const candidates = [r.amountPaid, r.amount, r.paidAmount, r.programAmount];
    let n = null;
    for (const c of candidates) {
      if (c == null || c === "") continue;
      const v = Number(c);
      if (Number.isFinite(v) && v > 0) { n = v; break; }
    }
    // Paystack sometimes stored kobo by mistake (> 100000 and no amountPaid)
    if (n != null && n >= 100000 && r.amountPaid == null && r.currency !== "NGN") {
      /* keep as naira if already large tuition */ 
    }
    if (n == null) return "—";
    return "₦" + n.toLocaleString("en-NG");
  }

  function programKey(r) {
    // Normalize fee-link + tuition rows into stable filter buckets
    const blob = [
      r.feeType, r.feeName, r.purpose, r.program, r.programName, r.programId, r.source
    ].map((x) => String(x || "").toLowerCase()).join(" ");
    if (blob.includes("id-card") || blob.includes("id card") || blob.includes("student id")) return "id-card";
    if (blob.includes("higher")) return "higher-diploma";
    if (blob.includes("diploma") && !blob.includes("higher")) return "diploma";
    if (blob.includes("licen")) return "licensing";
    if (blob.includes("cert")) return "certificate";
    if (blob.includes("graduat") || blob.includes("clinic") || blob.includes("intern") || blob.includes("excurs")) return "other";
    if (r.feeType && r.feeType !== "tuition" && r.feeType !== "custom") {
      const ft = String(r.feeType).toLowerCase();
      if (["certificate", "diploma", "higher-diploma", "licensing", "id-card"].includes(ft)) return ft;
    }
    const p = String(r.program || r.programId || r.purpose || "").toLowerCase();
    if (p) {
      if (p.includes("higher")) return "higher-diploma";
      if (p.includes("diploma")) return "diploma";
      if (p.includes("licen")) return "licensing";
      if (p.includes("id") && p.includes("card")) return "id-card";
      if (p.includes("cert")) return "certificate";
      if (["certificate", "diploma", "higher-diploma", "licensing", "id-card"].includes(p)) return p;
    }
    // Fee-link custom fees that are not a main programme
    if (r.source === "fee-link" || r.feeName || r.feeId) return "other";
    return "other";
  }

  function installmentLabel(r) {
    const paid = Number(r.installmentsPaid != null ? r.installmentsPaid : (String(r.status).toLowerCase() === "paid" || String(r.status).toLowerCase() === "completed" ? 1 : 0));
    const total = Number(r.installmentsTotal || 1);
    return paid + "/" + total;
  }

  function dueInfo(r) {
    const paid = Number(r.installmentsPaid || 0);
    const total = Number(r.installmentsTotal || 1);
    if (paid >= total) return { text: "—", defaulted: false, days: 0 };
    let due = r.nextDueDate;
    if (!due) return { text: "not set", defaulted: false, days: 0 };
    const dueMs = new Date(due).getTime();
    if (isNaN(dueMs)) return { text: String(due), defaulted: false, days: 0 };
    const today = new Date();
    today.setHours(0,0,0,0);
    const diff = Math.floor((today.getTime() - dueMs) / 86400000);
    if (diff > 0) return { text: due + " (defaulted " + diff + "d)", defaulted: true, days: diff };
    if (diff === 0) return { text: due + " (due today)", defaulted: false, days: 0 };
    return { text: due + " (in " + (-diff) + "d)", defaulted: false, days: 0 };
  }

  async function markDefaultedIfNeeded(row) {
    const info = dueInfo(row);
    if (!info.defaulted) return;
    try {
      const api = await getDb();
      const interval = 14; // new window after default
      const next = new Date();
      next.setDate(next.getDate() + interval);
      await api.setDoc(api.doc(api.db, "payments", row.id), {
        defaulted: true,
        daysDefaulted: (Number(row.daysDefaulted) || 0) + info.days,
        lastDefaultedAt: new Date().toISOString().slice(0, 10),
        nextDueDate: next.toISOString().slice(0, 10),
        updatedAt: api.serverTimestamp()
      }, { merge: true });
    } catch (e) {}
  }

  async function setStatus(row, status) {
    // Manual override only — used for cash / corrections
    try {
      const api = await getDb();
      await api.setDoc(api.doc(api.db, "payments", row.id), {
        status,
        paymentStatus: status,
        updatedAt: api.serverTimestamp()
      }, { merge: true });
      toast("Payment → " + status);
      load();
    } catch (e) {
      toast(e.message || "Update failed", "error");
    }
  }

  async function saveCash(e) {
    e.preventDefault();
    if (!cash.fullName.trim()) { toast("Name required", "error"); return; }
    const total = Math.min(3, Math.max(1, parseInt(cash.installmentsTotal, 10) || 1));
    let paid = Math.min(total, Math.max(0, parseInt(cash.installmentsPaid, 10) || 0));
    const amount = Number(cash.amount) || 0;
    // Auto status from installments if they picked paid/unpaid inconsistently
    let status = cash.status;
    if (paid >= total) status = "paid";
    else if (paid > 0) status = "pending";
    let nextDue = (cash.nextDueDate || "").trim();
    if (!nextDue && paid < total) {
      const d = new Date();
      d.setDate(d.getDate() + (parseInt(cash.installmentIntervalDays, 10) || 30));
      nextDue = d.toISOString().slice(0, 10);
    }
    if (paid >= total) nextDue = "";
    try {
      const api = await getDb();
      const ref = "CASH-" + Date.now().toString(36).toUpperCase() + "-" + Math.floor(Math.random() * 9000 + 1000);
      const id = "cash-" + Date.now().toString(36);
      const emailNorm = (cash.email || "").trim().toLowerCase();
      let studentId = null;
      let regNumber = "";
      if (emailNorm) {
        try {
          const qs = await api.getDocs(api.collection(api.db, "students"));
          qs.forEach((d) => {
            const s = d.data() || {};
            if (String(s.email || "").toLowerCase().trim() === emailNorm) {
              studentId = d.id;
              regNumber = s.regNumber || "";
            }
          });
        } catch (_) {}
      }
      await api.setDoc(api.doc(api.db, "payments", id), {
        reference: ref,
        method: "cash",
        channel: "cash",
        fullName: cash.fullName.trim(),
        email: emailNorm,
        studentId: studentId,
        regNumber: regNumber || null,
        program: cash.program,
        amount,
        amountPaid: amount,
        status,
        paymentStatus: status,
        installmentsTotal: total,
        installmentsPaid: paid,
        nextDueDate: nextDue || null,
        installmentIntervalDays: parseInt(cash.installmentIntervalDays, 10) || 30,
        defaulted: false,
        daysDefaulted: 0,
        notes: cash.notes || "",
        source: "admin-cash",
        createdAt: api.serverTimestamp(),
        updatedAt: api.serverTimestamp()
      });
      // Link application if email matches
      if (cash.email) {
        try {
          await api.setDoc(api.doc(api.db, "applications", cash.email.trim().toLowerCase()), {
            paymentStatus: status === "paid" ? "paid" : "pending",
            installmentsTotal: total,
            installmentsPaid: paid,
            program: cash.program,
            fullName: cash.fullName.trim(),
            updatedAt: api.serverTimestamp()
          }, { merge: true });
        } catch (e) {}
      }
      toast("Cash payment saved · " + ref);
      setCash({ fullName: "", email: "", program: "certificate", amount: "", status: "paid", installmentsTotal: "1", installmentsPaid: "1", notes: "" });
      setShowCash(false);
      load();
    } catch (ex) {
      toast(ex.message || "Save failed", "error");
    }
  }

  async function sendReminder(row) {
    const email = row.email;
    if (!email) { toast("No email on this payment", "error"); return; }
    try {
      const base = getStoredPublicSite();
      const res = await fetch(base + "/api/send-applicant-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          to: email,
          subject: "CGTIA — Complete your payment",
          text: "Dear " + (row.fullName || "student") + ",\\n\\nOur records show your programme payment is not fully complete (" + installmentLabel(row) + " installments).\\n\\nPlease complete payment so your records, ID, and certificate processing can proceed without delay.\\n\\n— CGTIA Admissions"
        })
      });
      // Admin site may not hit client functions — try toast either way
      toast(res.ok ? "Reminder requested for " + email : "The reminder email could not be sent. Please email the applicant yourself: " + email, res.ok ? undefined : "error");
    } catch (e) {
      toast("The reminder email could not be sent. Please contact " + email + " manually.", "error");
    }
  }

  const groups = {};
  rows.forEach((r) => {
    const k = programKey(r);
    if (filter !== "all" && k !== filter) return;
    if (!groups[k]) groups[k] = [];
    groups[k].push(r);
  });
  const order = ["certificate", "diploma", "higher-diploma", "licensing", "id-card", "other"];
  const keys = order.filter((k) => groups[k]).concat(Object.keys(groups).filter((k) => !order.includes(k)));

  const incomplete = rows.filter((r) => {
    const paid = Number(r.installmentsPaid || 0);
    const total = Number(r.installmentsTotal || 1);
    const st = String(r.status || r.paymentStatus || "").toLowerCase();
    return paid < total || st === "unpaid" || st === "pending" || st === "failed";
  });

  const listKeys = payTab === "incomplete"
    ? order.filter((k) => groups[k] && groups[k].some((r) => {
        const paid = Number(r.installmentsPaid || 0);
        const total = Number(r.installmentsTotal || 1);
        const st = String(r.status || r.paymentStatus || "").toLowerCase();
        return paid < total || st === "unpaid" || st === "pending" || st === "failed";
      })).concat(Object.keys(groups).filter((k) => !order.includes(k) && groups[k] && groups[k].some((r) => {
        const paid = Number(r.installmentsPaid || 0);
        const total = Number(r.installmentsTotal || 1);
        const st = String(r.status || r.paymentStatus || "").toLowerCase();
        return paid < total || st === "unpaid" || st === "pending" || st === "failed";
      })))
    : keys;

  return html`
    <div>
      <h1>Payments</h1>
      <p class="muted">Online payments update automatically when verified. Use <strong>Cash payment</strong> for walk-in cash. Manual status buttons are for cash and corrections only.</p>
      ${err ? html`<p class="error">${err}</p>` : null}
      <${SubTabs}
        tabs=${[
          { id: "list", label: "Online payments (" + rows.length + ")" },
          { id: "cash", label: "Cash payment" },
          { id: "incomplete", label: "Incomplete (" + incomplete.length + ")" }
        ]}
        active=${payTab}
        onChange=${setPayTab}
        menu=${[
          { label: "All programmes", checked: filter === "all", run: () => setFilter("all") },
          { label: "Certificate", checked: filter === "certificate", run: () => { setFilter("certificate"); setCash((c) => ({ ...c, program: "certificate" })); } },
          { label: "Diploma", checked: filter === "diploma", run: () => { setFilter("diploma"); setCash((c) => ({ ...c, program: "diploma" })); } },
          { label: "Higher diploma", checked: filter === "higher-diploma", run: () => { setFilter("higher-diploma"); setCash((c) => ({ ...c, program: "higher-diploma" })); } },
          { label: "Licensing", checked: filter === "licensing", run: () => { setFilter("licensing"); setCash((c) => ({ ...c, program: "licensing" })); } },
          { label: "ID card", checked: filter === "id-card", run: () => { setFilter("id-card"); setCash((c) => ({ ...c, program: "id-card" })); } },
          { label: "Other", checked: filter === "other", run: () => setFilter("other") }
        ]} />
      ${payTab === "cash" ? html`
        <form class="card" onSubmit=${async (e) => { await saveCash(e); setPayTab("list"); }} style=${{ marginBottom: "1rem" }}>
          <p class="muted" style=${{ marginBottom: "0.75rem" }}>Cash / manual entry — reference will look like <code>CASH-…</code> (online Paystack still uses T… numbers).</p>
          <div class="form-row"><label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Full name *</label><input required value=${cash.fullName} onInput=${(e) => setCash({ ...cash, fullName: e.target.value })} /></div>
          <div class="form-row"><label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Email (optional)</label><input type="email" value=${cash.email} onInput=${(e) => setCash({ ...cash, email: e.target.value })} /></div>
          <div class="form-row"><label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Programme</label>
            <select value=${cash.program} onChange=${(e) => setCash({ ...cash, program: e.target.value })}>
              <option value="certificate">certificate</option>
              <option value="diploma">diploma</option>
              <option value="higher-diploma">higher-diploma</option>
              <option value="licensing">licensing</option>
              <option value="id-card">ID card</option>
            </select>
          </div>
          <div class="form-row"><label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Amount (₦)</label><input type="number" min="0" value=${cash.amount} onInput=${(e) => setCash({ ...cash, amount: e.target.value })} /></div>
          <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "0.5rem" }}>
            <div>
              <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Installments total</label>
              <select value=${cash.installmentsTotal} onChange=${(e) => setCash({ ...cash, installmentsTotal: e.target.value })}>
                <option value="1">1 (full)</option>
                <option value="2">2</option>
                <option value="3">3</option>
              </select>
            </div>
            <div>
              <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Installments paid so far</label>
              <select value=${cash.installmentsPaid} onChange=${(e) => setCash({ ...cash, installmentsPaid: e.target.value })}>
                <option value="0">0</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
              </select>
            </div>
            <div>
              <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Status</label>
              <select value=${cash.status} onChange=${(e) => setCash({ ...cash, status: e.target.value })}>
                <option value="paid">paid</option>
                <option value="pending">pending</option>
                <option value="unpaid">unpaid</option>
                <option value="failed">failed</option>
              </select>
            </div>
          </div>
          <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.5rem" }}>
            <div>
              <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Days until next installment</label>
              <input type="number" min="1" value=${cash.installmentIntervalDays} onInput=${(e) => setCash({ ...cash, installmentIntervalDays: e.target.value })} />
            </div>
            <div>
              <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Next due date (optional override)</label>
              <input type="date" value=${cash.nextDueDate} onInput=${(e) => setCash({ ...cash, nextDueDate: e.target.value })} />
            </div>
          </div>
          <div class="form-row"><label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Notes</label><input value=${cash.notes} onInput=${(e) => setCash({ ...cash, notes: e.target.value })} /></div>
          <div style=${{ display: "flex", gap: "0.5rem" }}>
            <button class="primary" type="submit">Save cash payment</button>
            <button type="button" class="ghost" onClick=${() => setPayTab("list")}>Cancel</button>
          </div>
        </form>
      ` : html`
        ${payTab === "incomplete" && incomplete.length ? html`
          <div class="card" style=${{ marginBottom: "1rem", borderColor: "#f59e0b" }}>
            <p style=${{ margin: 0, fontWeight: 600 }}>Incomplete / open payments: ${incomplete.length}</p>
            <p class="muted" style=${{ margin: "0.35rem 0 0", fontSize: "0.8rem" }}>${incomplete.slice(0, 8).map((r) => (r.fullName || r.email || r.reference || r.id) + " (" + installmentLabel(r) + ")").join(" · ")}${incomplete.length > 8 ? "…" : ""}</p>
          </div>
        ` : null}
        ${filter !== "all" ? html`<p class="muted" style=${{ marginBottom: "0.75rem", fontSize: "0.8rem" }}>Showing: <strong>${filter.replace(/-/g, " ")}</strong> · use ⋯ to change</p>` : null}
        ${listKeys.length === 0 ? html`<p class="muted">No payments in this filter.</p>` : null}
        ${listKeys.map((k) => {
          const rowsInGroup = payTab === "incomplete"
            ? (groups[k] || []).filter((r) => {
                const paid = Number(r.installmentsPaid || 0);
                const total = Number(r.installmentsTotal || 1);
                const st = String(r.status || r.paymentStatus || "").toLowerCase();
                return paid < total || st === "unpaid" || st === "pending" || st === "failed";
              })
            : (groups[k] || []);
          if (!rowsInGroup.length) return null;
          return html`
          <div key=${k} style=${{ marginBottom: "1.5rem" }}>
            <h2 style=${{ fontSize: "1rem", textTransform: "capitalize", marginBottom: "0.5rem" }}>${k.replace(/-/g, " ")}</h2>
            <div class="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Name / email</th>
                    <th>Method</th>
                    <th>Amount</th>
                    <th>Installments</th>
                    <th>Next due</th>
                    <th>Status</th>
                    <th>Reference</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  ${rowsInGroup.map((r) => html`
                    <tr key=${r.id}>
                      <td>${r.fullName || "—"}<br/><span class="muted" style=${{ fontSize: "0.7rem" }}>${r.email || r.applicationId || ""}${r.feeName || r.feeType ? " · " + (r.feeName || r.feeType) : ""}</span></td>
                      <td>${displayMethod(r)}</td>
                      <td>${displayAmount(r)}</td>
                      <td>${installmentLabel(r)}</td>
                      <td style=${{ fontSize: "0.75rem", color: dueInfo(r).defaulted ? "#b91c1c" : undefined }}>${dueInfo(r).text}</td>
                      <td><${Badge} status=${r.defaulted ? "failed" : (r.status || r.paymentStatus || "pending")} /></td>
                      <td><code style=${{ fontSize: "0.65rem" }}>${r.reference || r.id}</code></td>
                      <td style=${{ whiteSpace: "nowrap" }}>
                        <button class="ghost" type="button" onClick=${() => setStatus(r, "paid")}>Paid</button>
                        <button class="ghost" type="button" onClick=${() => setStatus(r, "unpaid")}>Unpaid</button>
                        <button class="ghost" type="button" onClick=${() => setStatus(r, "pending")}>Pending</button>
                        <button class="ghost" type="button" onClick=${() => setStatus(r, "failed")}>Failed</button>
                        ${r.email ? html`<button class="ghost" type="button" onClick=${() => sendReminder(r)}>Remind</button>` : null}
                      </td>
                    </tr>
                  `)}
                </tbody>
              </table>
            </div>
          </div>
        `;
        })}
      `}
    </div>
  `;
}



/** Custom fees (graduation, clinicals, internship, excursion, etc.) + payment links */
function FeesPanel() {
  const [feeTab, setFeeTab] = useState("types");
  const DOMAINS = PUBLIC_SITE_PRESETS;
  const FEE_TYPES = [
    { value: "certificate", label: "Certificate tuition" },
    { value: "diploma", label: "Diploma tuition" },
    { value: "higher-diploma", label: "Higher diploma tuition" },
    { value: "licensing", label: "Licensing fee" },
    { value: "graduation", label: "Graduation fee" },
    { value: "id-card", label: "Student ID card" },
    { value: "clinical", label: "Clinical / placement" },
    { value: "internship", label: "Internship" },
    { value: "excursion", label: "Excursion / trip" },
    { value: "custom", label: "Custom / other" }
  ];
  const emptyFee = {
    name: "",
    type: "graduation",
    amount: "",
    description: "",
    installmentsMax: "1",
    installmentIntervalDays: "30",
    active: true
  };
  const [fees, setFees] = useState([]);
  const [links, setLinks] = useState([]);
  const [err, setErr] = useState("");
  const [feeForm, setFeeForm] = useState({ ...emptyFee });
  const [editFeeId, setEditFeeId] = useState(null);
  const [showFeeForm, setShowFeeForm] = useState(false);
  const [linkFeeId, setLinkFeeId] = useState("");
  const [linkMode, setLinkMode] = useState("multi");
  const [linkWho, setLinkWho] = useState("student");
  const [linkPayerEmail, setLinkPayerEmail] = useState("");
  const [expireAmount, setExpireAmount] = useState("24");
  const [expireUnit, setExpireUnit] = useState("hours");
  const [domain, setDomain] = useState(getStoredPublicSite());
  const [lastLink, setLastLink] = useState("");
  const [lastToken, setLastToken] = useState("");

  async function load() {
    try {
      const api = await getDb();
      const [fs, ls] = await Promise.all([
        api.getDocs(api.collection(api.db, "feeDefinitions")),
        api.getDocs(api.collection(api.db, "feePaymentLinks"))
      ]);
      const flist = [];
      fs.forEach((d) => flist.push({ id: d.id, ...d.data() }));
      flist.sort((a, b) => String(a.name || "").localeCompare(String(b.name || "")));
      setFees(flist);
      const llist = [];
      ls.forEach((d) => { if (!isTrashed(d.data())) llist.push({ id: d.id, ...d.data() }); });
      llist.sort((a, b) => {
        const ta = a.createdAt?.seconds || 0;
        const tb = b.createdAt?.seconds || 0;
        return tb - ta;
      });
      setLinks(llist);
    } catch (e) {
      setErr(e.message || String(e));
    }
  }
  useEffect(() => { load(); }, []);

  function makeToken() {
    const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789";
    let tok = "";
    for (let i = 0; i < 28; i++) tok += alphabet[Math.floor(Math.random() * alphabet.length)];
    return tok;
  }

  function expiryMs() {
    const n = Math.max(1, parseInt(expireAmount, 10) || 1);
    return expireUnit === "days" ? n * 86400000 : n * 3600000;
  }

  async function saveFee(e) {
    e.preventDefault();
    if (!feeForm.name.trim()) { toast("Fee name required", "error"); return; }
    const amount = Number(feeForm.amount);
    if (!amount || amount < 100) { toast("Enter a valid amount (min ₦100)", "error"); return; }
    try {
      const api = await getDb();
      const id = editFeeId || ("fee_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 7));
      await api.setDoc(api.doc(api.db, "feeDefinitions", id), {
        name: feeForm.name.trim(),
        type: feeForm.type || "custom",
        amount: amount,
        description: (feeForm.description || "").trim(),
        installmentsMax: Math.min(3, Math.max(1, parseInt(feeForm.installmentsMax, 10) || 1)),
        installmentIntervalDays: Math.max(1, parseInt(feeForm.installmentIntervalDays, 10) || 30),
        active: feeForm.active !== false && feeForm.active !== 0,
        updatedAt: api.serverTimestamp(),
        ...(editFeeId ? {} : { createdAt: api.serverTimestamp() })
      }, { merge: true });
      toast(editFeeId ? "Fee updated" : "Fee created");
      setShowFeeForm(false);
      setEditFeeId(null);
      setFeeForm({ ...emptyFee });
      load();
    } catch (ex) {
      toast(ex.message || "Save failed", "error");
    }
  }

  function openEditFee(row) {
    setEditFeeId(row.id);
    setFeeForm({
      name: row.name || "",
      type: row.type || "custom",
      amount: String(row.amount || ""),
      description: row.description || "",
      installmentsMax: String(row.installmentsMax || 1),
      installmentIntervalDays: String(row.installmentIntervalDays || 30),
      active: row.active !== false
    });
    setShowFeeForm(true);
  }

  async function toggleFeeActive(row) {
    try {
      const api = await getDb();
      // Treat missing active as live (true). !undefined would wrongly keep it on.
      const currentlyOn = row.active !== false;
      const next = !currentlyOn;
      await api.setDoc(api.doc(api.db, "feeDefinitions", row.id), {
        active: next,
        updatedAt: api.serverTimestamp()
      }, { merge: true });
      toast(next ? "Fee turned on" : "Fee turned off");
      load();
    } catch (ex) {
      toast(ex.message || "Failed", "error");
    }
  }

  async function createPaymentLink(e) {
    e.preventDefault();
    const fee = fees.find((f) => f.id === linkFeeId);
    if (!fee) { toast("Select a fee first", "error"); return; }
    if (fee.active === false) { toast("Turn the fee on before creating a link", "error"); return; }
    if (linkWho === "email" && !linkPayerEmail.trim()) { toast("Enter the payer's email", "error"); return; }
    try {
      const api = await getDb();
      const token = makeToken();
      const expiresAt = new Date(Date.now() + expiryMs());
      const isSingle = linkMode === "single";
      await api.setDoc(api.doc(api.db, "feePaymentLinks", token), {
        feeId: fee.id,
        feeName: fee.name,
        feeType: fee.type || "custom",
        amount: Number(fee.amount),
        description: fee.description || "",
        installmentsMax: fee.installmentsMax || 1,
        installmentIntervalDays: fee.installmentIntervalDays || 30,
        mode: isSingle ? "single" : "multi",
        payerRule: linkWho,
        payerEmail: linkWho === "email" ? linkPayerEmail.trim().toLowerCase() : "",
        maxUses: isSingle ? 1 : null,
        usedCount: 0,
        active: true,
        expiresAt: expiresAt.toISOString(),
        domain: domain,
        createdAt: api.serverTimestamp()
      });
      const base = (domain || DOMAINS[0]).replace(/\/$/, "");
      const full = base + "/pay-fee?token=" + token;
      setLastLink(full);
      setLastToken(token);
      toast("Payment link created — copy it below");
      load();
    } catch (ex) {
      toast(ex.message || "Could not create link", "error");
    }
  }

  async function deletePaymentLink(id) {
    if (!(await askConfirm("Move this payment link to Trash?"))) return;
    try {
      await moveToTrash("feePaymentLinks", id);
      toast("Moved to Trash");
      load();
    } catch (ex) {
      toast(ex.message || "Failed", "error");
    }
  }

  async function revokeLink(id) {
    try {
      const api = await getDb();
      await api.setDoc(api.doc(api.db, "feePaymentLinks", id), {
        active: false,
        revoked: true,
        updatedAt: api.serverTimestamp()
      }, { merge: true });
      toast("Link revoked");
      load();
    } catch (ex) {
      toast(ex.message || "Failed", "error");
    }
  }

  function expLabel(row) {
    if (row.revoked || row.active === false) return "Revoked";
    const exp = row.expiresAt;
    let ms = null;
    if (exp && typeof exp.toDate === "function") ms = exp.toDate().getTime();
    else if (exp) ms = new Date(exp).getTime();
    if (ms && Date.now() > ms) return "Expired";
    if (ms) return "Expires " + new Date(ms).toLocaleString();
    return "—";
  }

  function linkFor(row) {
    const base = (row.domain || DOMAINS[0]).replace(/\/$/, "");
    return base + "/pay-fee?token=" + row.id;
  }

  const activeFees = fees.filter((f) => f.active !== false);

  return html`
    <div>
      <h1>Fees & payment links</h1>
      <p class="muted">Create fee types for each programme tuition (certificate, diploma, higher diploma) and extras (ID card, graduation, etc.). Application itself does not collect money — generate a payment link after you accept the applicant — single-use (one person) or multi-use (share in a group chat). Set how long the link stays valid (e.g. 24 hours). Students open the link, enter their school email (primary) and optional reg number, then pay via Paystack. Payments auto-link to the student record.</p>
      ${err ? html`<p class="error">${err}</p>` : null}

      <${SubTabs}
        tabs=${[{ id: "types", label: "Fee types" }, { id: "create", label: "Create link" }, { id: "links", label: "Links" }]}
        active=${feeTab}
        onChange=${setFeeTab}
        menu=${[{ label: "Refresh", run: () => window.dispatchEvent(new Event("cgtia:refresh")) }]} />
      ${feeTab === "types" ? html`
      <div style=${{ display: "flex", gap: "0.75rem", marginBottom: "1.25rem", flexWrap: "wrap" }}>
        <button class="primary" type="button" onClick=${() => { setShowFeeForm(true); setEditFeeId(null); setFeeForm({ ...emptyFee }); }}>New fee definition</button>
      </div>

      ${showFeeForm ? html`
        <form class="card" onSubmit=${saveFee} style=${{ marginBottom: "1.5rem" }}>
          <p class="muted">${editFeeId ? "Edit fee" : "New fee definition"}</p>
          <div class="form-row">
            <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Fee name</label>
            <input required value=${feeForm.name} onInput=${(e) => setFeeForm({ ...feeForm, name: e.target.value })} placeholder="Graduation Fee 2026" />
          </div>
          <div style=${{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.75rem" }}>
            <div>
              <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Type</label>
              <select value=${feeForm.type} onChange=${(e) => setFeeForm({ ...feeForm, type: e.target.value })}>
                ${FEE_TYPES.map((t) => html`<option key=${t.value} value=${t.value}>${t.label}</option>`)}
              </select>
            </div>
            <div>
              <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Amount (₦)</label>
              <input required type="number" min="100" step="100" value=${feeForm.amount} onInput=${(e) => setFeeForm({ ...feeForm, amount: e.target.value })} placeholder="50000" />
            </div>
          </div>
          <div class="form-row">
            <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Description (optional)</label>
            <input value=${feeForm.description} onInput=${(e) => setFeeForm({ ...feeForm, description: e.target.value })} placeholder="Payable by all graduating students" />
          </div>
          <div style=${{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.75rem" }}>
            <div>
              <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Max installments</label>
              <select value=${feeForm.installmentsMax} onChange=${(e) => setFeeForm({ ...feeForm, installmentsMax: e.target.value })}>
                <option value="1">Full payment only</option>
                <option value="2">Up to 2 installments</option>
                <option value="3">Up to 3 installments</option>
              </select>
            </div>
            <div>
              <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Days between installments</label>
              <input type="number" min="1" max="365" value=${feeForm.installmentIntervalDays} onInput=${(e) => setFeeForm({ ...feeForm, installmentIntervalDays: e.target.value })} />
            </div>
          </div>
          <div style=${{ display: "flex", gap: "0.5rem", marginTop: "0.75rem" }}>
            <button class="primary" type="submit">${editFeeId ? "Update fee" : "Create fee"}</button>
            <button type="button" class="ghost" onClick=${() => { setShowFeeForm(false); setEditFeeId(null); }}>Cancel</button>
          </div>
        </form>
      ` : null}

      <div class="card" style=${{ marginBottom: "1.5rem" }}>
        <h2 style=${{ fontSize: "1rem", marginBottom: "0.75rem" }}>Fee definitions</h2>
        <div class="table-wrap">
          <table>
            <thead>
              <tr><th>Name</th><th>Type</th><th>Amount</th><th>Installments</th><th>Interval</th><th>Status</th><th></th></tr>
            </thead>
            <tbody>
              ${fees.length === 0 ? html`<tr><td colspan="7" class="muted">No fees yet. Create one above.</td></tr>` : null}
              ${fees.map((r) => html`
                <tr key=${r.id}>
                  <td>${r.name}</td>
                  <td class="muted">${r.type || "custom"}</td>
                  <td>₦${Number(r.amount || 0).toLocaleString("en-NG")}</td>
                  <td>${r.installmentsMax || 1}</td>
                  <td>${r.installmentIntervalDays || 30} days</td>
                  <td><${Badge} status=${r.active === false ? "inactive" : "active"} /></td>
                  <td style=${{ whiteSpace: "nowrap" }}>
                    <button class="ghost" type="button" onClick=${() => openEditFee(r)}>Edit</button>
                    <button class="ghost" type="button" onClick=${() => toggleFeeActive(r)}>${r.active === false ? "Activate" : "Deactivate"}</button>
                  </td>
                </tr>
              `)}
            </tbody>
          </table>
        </div>
      </div>

      ` : null}
      ${feeTab === "create" ? html`
      <div class="card" style=${{ marginBottom: "1.5rem" }}>
        <h2 style=${{ fontSize: "1rem", marginBottom: "0.5rem" }}>Generate payment link</h2>
        <p class="muted" style=${{ marginBottom: "0.75rem" }}>Choose a fee, decide single-use (one person only) or multi-use (share with a group), set expiry, then copy the link into the group chat.</p>
        <form onSubmit=${createPaymentLink}>
          <div style=${{ marginBottom: "0.75rem" }}>
            <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Who can pay this link</label>
            <select value=${linkWho} onChange=${(e) => setLinkWho(e.target.value)}>
              <option value="student">Registered students only (email must match the school record)</option>
              <option value="email">One specific person (enter their email)</option>
              <option value="anyone">Anyone (no check — only for open fees)</option>
            </select>
            ${linkWho === "email" ? html`<input type="email" placeholder="payer@example.com" value=${linkPayerEmail} onInput=${(e) => setLinkPayerEmail(e.target.value)} style=${{ marginTop: "0.5rem" }} />` : null}
          </div>
          <div style=${{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.75rem" }}>
            <div>
              <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Fee</label>
              <select required value=${linkFeeId} onChange=${(e) => setLinkFeeId(e.target.value)}>
                <option value="">Select fee…</option>
                ${activeFees.map((f) => html`<option key=${f.id} value=${f.id}>${f.name} — ₦${Number(f.amount).toLocaleString("en-NG")}</option>`)}
              </select>
            </div>
            <div>
              <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Link type</label>
              <select value=${linkMode} onChange=${(e) => setLinkMode(e.target.value)}>
                <option value="multi">Multi-use (group share)</option>
                <option value="single">Single-use (one person only)</option>
              </select>
            </div>
            <div>
              <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Expires in</label>
              <input type="number" min="1" max="720" value=${expireAmount} onInput=${(e) => setExpireAmount(e.target.value)} />
            </div>
            <div>
              <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Unit</label>
              <select value=${expireUnit} onChange=${(e) => setExpireUnit(e.target.value)}>
                <option value="hours">hours</option>
                <option value="days">days</option>
              </select>
            </div>
            <div style=${{ gridColumn: "1 / -1" }}>
              <${PublicSiteDomainField} domain=${domain} setDomain=${setDomain} />
            </div>
          </div>
          <button class="primary" type="submit" style=${{ marginTop: "0.75rem" }}>Create payment link</button>
        </form>
        ${lastLink ? html`
          <div style=${{ marginTop: "1rem", padding: "0.75rem", background: "#ecfdf5", borderRadius: "8px" }}>
            <p class="muted" style=${{ marginBottom: "0.35rem" }}>Copy and share this link:</p>
            <code style=${{ wordBreak: "break-all", fontSize: "0.8rem" }}>${lastLink}</code>
            <div style=${{ marginTop: "0.5rem" }}>
              <button class="ghost" type="button" onClick=${() => { navigator.clipboard && navigator.clipboard.writeText(lastLink); toast("Link copied"); }}>Copy link</button>
            </div>
          </div>
        ` : null}
      </div>

      ` : null}
      ${feeTab === "links" ? html`
      <div class="card">
        <h2 style=${{ fontSize: "1rem", marginBottom: "0.75rem" }}>Recent payment links</h2>
        <div class="table-wrap">
          <table>
            <thead>
              <tr><th>Fee</th><th>Mode</th><th>Amount</th><th>Uses</th><th>Status / expiry</th><th></th></tr>
            </thead>
            <tbody>
              ${links.length === 0 ? html`<tr><td colspan="6" class="muted">No links created yet.</td></tr>` : null}
              ${links.slice(0, 40).map((r) => html`
                <tr key=${r.id}>
                  <td>
                    ${r.feeName || r.feeId}
                    ${(r.recentPayers && r.recentPayers.length) ? html`
                      <div class="muted" style=${{ fontSize: "0.7rem", marginTop: "0.25rem" }}>
                        ${r.recentPayers.slice(0, 5).map((p) => (p.fullName || p.email || "—") + (p.email ? " · " + p.email : "")).join(" · ")}
                        ${r.recentPayers.length > 5 ? " +" + (r.recentPayers.length - 5) + " more" : ""}
                      </div>
                    ` : null}
                  </td>
                  <td>${r.mode === "single" ? "Single-use" : "Multi-use"}</td>
                  <td>₦${Number(r.amount || 0).toLocaleString("en-NG")}</td>
                  <td>${r.usedCount || 0}${r.maxUses ? " / " + r.maxUses : ""}</td>
                  <td style=${{ fontSize: "0.75rem" }}>${expLabel(r)}</td>
                  <td style=${{ whiteSpace: "nowrap" }}>
                    ${r.active !== false && !r.revoked ? html`
                      <button class="ghost" type="button" onClick=${() => { setLastLink(linkFor(r)); setLastToken(r.id); toast("Link shown above"); }}>Show</button>
                      <button class="ghost" type="button" onClick=${() => revokeLink(r.id)}>Cancel link</button>
                    ` : null}
                    <button class="ghost" type="button" style=${{ color: "#dc2626" }} onClick=${() => deletePaymentLink(r.id)}>Delete</button>
                  </td>
                </tr>
              `)}
            </tbody>
          </table>
        </div>
      </div>` : null}
    </div>
  `;
}

function UsersPanel({ myProfile }) {
  const [rows, setRows] = useState([]);
  const [err, setErr] = useState("");
  const [msg, setMsg] = useState("");
  const [form, setForm] = useState({ uid: "", email: "", role: "admin", active: true });

  async function load() {
    try {
      const api = await getDb();
      const snap = await api.getDocs(api.collection(api.db, "users"));
      const list = [];
      snap.forEach((d) => list.push({ id: d.id, ...d.data() }));
      setRows(list);
    } catch (e) {
      setErr("Could not load users: " + (e.message || e));
    }
  }
  useEffect(() => { load(); }, []);

  async function save(e) {
    e.preventDefault();
    if (!form.uid.trim()) {
      setErr("Paste the user ID from the sign-in list.");
      return;
    }
    try {
      const api = await getDb();
      await api.setDoc(api.doc(api.db, "users", form.uid.trim()), {
        email: form.email.trim(),
        role: form.role,
        active: !!form.active,
        updatedAt: api.serverTimestamp()
      }, { merge: true });
      setMsg("Saved access for " + form.uid.trim());
      setErr("");
      load();
    } catch (ex) {
      setErr("Could not save access: " + (ex.message || ex));
    }
  }

  async function toggleActive(row) {
    try {
      const api = await getDb();
      await api.updateDoc(api.doc(api.db, "users", row.id), { active: row.active === false });
      load();
    } catch (e) {
      setErr(e.message || String(e));
    }
  }

  return html`
    <div>
      <h1>Staff access</h1>
      <p class="sub">
        You are the main admin. Assign roles to staff: <code>super-admin</code>, <code>admin</code>,
        <code>admissions</code>, <code>licensing-officer</code>, <code>registrar</code>, <code>instructor</code>, <code>student</code>.
      </p>
      <form class="card" onSubmit=${save} style=${{ marginBottom: "1rem" }}>
        <p class="muted">To find a person's ID: open the sign-in list, click their name, and copy the User ID.</p>
        <div class="form-row"><input placeholder="User ID (from the sign-in list)" value=${form.uid} onInput=${(e) => setForm({ ...form, uid: e.target.value })} required /></div>
        <div class="form-row"><input placeholder="Email" value=${form.email} onInput=${(e) => setForm({ ...form, email: e.target.value })} /></div>
        <div class="form-row">
          <select value=${form.role} onChange=${(e) => setForm({ ...form, role: e.target.value })}>
            <option value="super-admin">super-admin (full control)</option>
            <option value="admin">admin</option>
            <option value="admissions">admissions</option>
            <option value="licensing-officer">licensing-officer</option>
            <option value="registrar">registrar</option>
            <option value="training-officer">training-officer</option>
            <option value="instructor">instructor</option>
            <option value="student">student</option>
          </select>
        </div>
        <div style=${{ marginBottom: "0.75rem" }}>
          <${Toggle} checked=${form.active} label="Active" onChange=${(v) => setForm({ ...form, active: v })} />
        </div>
        <button class="primary">Save staff profile</button>
        ${msg ? html`<p class="muted">${msg}</p>` : null}
        ${err ? html`<p class="error">${err}</p>` : null}
      </form>
      <div class="table-wrap">
        <table>
          <thead><tr><th>User ID</th><th>Email</th><th>Role</th><th>Active</th><th></th></tr></thead>
          <tbody>
            ${rows.map((r) => html`
              <tr key=${r.id}>
                <td class="muted" style=${{ fontSize: "11px" }}>${r.id.slice(0, 12)}…</td>
                <td>${r.email || "—"}</td>
                <td>${r.role || "—"}</td>
                <td><${Badge} status=${r.active === false ? "inactive" : "active"} /></td>
                <td><button class="ghost" onClick=${() => toggleActive(r)}>${r.active === false ? "Activate" : "Hibernate"}</button></td>
              </tr>
            `)}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

const BELL_DESTS = [
  ["", "Choose where the button goes"],
  ["/tuition", "Tuition & fees page"],
  ["/", "Home page"],
  ["/contact", "Contact page"],
  ["/licensing", "Licensing page"],
  ["/verify", "Verify a credential"],
  ["apply", "Open the application form"],
  ["custom", "Another web address"]
];
function bellDestKey(url) {
  if (!url) return "";
  return ["/tuition", "/", "/contact", "/licensing", "/verify", "apply"].indexOf(url) >= 0 ? url : "custom";
}

function PromotionsPanel() {
  const [rows, setRows] = useState([]);
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");
  const [editing, setEditing] = useState(null); // full doc or null for new
  const [promoTab, setPromoTab] = useState("list"); // list | edit
  const [programOptions, setProgramOptions] = useState([]);
  useEffect(() => {
    (async () => {
      try {
        const api = await getDb();
        const snap = await api.getDocs(api.collection(api.db, "programs"));
        const list = [];
        snap.forEach((d) => { if (d.data().trashed !== true) list.push({ id: d.id, label: d.data().headline || d.data().name || d.id }); });
        setProgramOptions(list);
      } catch (e) { /* picker stays empty */ }
    })();
  }, []);
  const empty = {
    id: "",
    type: "tuition", // tuition | announcement
    title: "Early enrolment offer",
    description: "Limited-time offer",
    promoAmount: "100000",
    active: true,
    hibernated: false,
    programs: "certificate",
    badge: "Promo",
    requiresCode: false,
    code: "",
    endsAt: "",
    linkUrl: "",
    linkLabel: "Read more",
    imageMobile: "",
    imageDesktop: "",
    bgColor: "",
    bgGradient: "",
    textColor: "#ffffff",
    buttonColor: "#ffffff",
    buttonTextColor: "#0f172a",
    bellText: "",
    bellButtonLabel: "",
    bellButtonUrl: "",
    repeatHours: 0,
    installmentsMax: "1",
    imageUrl: "",
    ctaLabel: "Know more",
    showInPortal: false,
    showOnSite: true
  };
  const [form, setForm] = useState(empty);

  async function load() {
    try {
      const api = await getDb();
      const snap = await api.getDocs(api.collection(api.db, "promotions"));
      const list = [];
      const now = Date.now();
      snap.forEach((d) => {
        if (d.data().trashed === true && d.data().active !== true) return;
        const data = { id: d.id, ...d.data() };
        let status = "active";
        if (data.trashed === true) status = "in Trash but still live";
        else if (data.hibernated) status = "hibernated";
        else if (data.active === false) status = "stopped";
        else if (data.endsAt) {
          const end = data.endsAt.toMillis ? data.endsAt.toMillis() : new Date(data.endsAt).getTime();
          if (end && end < now) status = "stopped";
        }
        data._status = status;
        list.push(data);
      });
      setRows(list);
    } catch (e) {
      setErr("Could not load promotions: " + (e.message || e));
    }
  }
  useEffect(() => { load(); }, []);

  function openNew() {
    setEditing("new");
    setForm({ ...empty });
    setPromoTab("edit");
  }
  function openEdit(row) {
    setEditing(row.id);
    setPromoTab("edit");
    setForm({
      id: row.id,
      type: row.type || "tuition",
      title: row.title || "",
      description: row.description || "",
      promoAmount: String(row.promoAmount || ""),
      active: row.active !== false && !row.hibernated,
      hibernated: !!row.hibernated,
      programs: (row.programs || []).join ? (row.programs || []).join(",") : String(row.programs || ""),
      badge: row.badge || "",
      requiresCode: !!row.requiresCode,
      code: row.code || "",
      endsAt: row.endsAt ? (row.endsAt.toDate ? row.endsAt.toDate().toISOString().slice(0, 16) : "") : "",
      linkUrl: row.linkUrl || "",
      linkLabel: row.linkLabel || "Read more",
      bgColor: row.bgColor || "",
      bgGradient: row.bgGradient || "",
      textColor: row.textColor || "#ffffff",
      buttonColor: row.buttonColor || "#ffffff",
      buttonTextColor: row.buttonTextColor || "#0f172a",
      bellText: row.bellText || "",
      bellButtonLabel: row.bellButtonLabel || "",
      bellButtonUrl: row.bellButtonUrl || "",
      repeatHours: Number(row.repeatHours) || 0,
      installmentsMax: String(row.installmentsMax || row.maxInstallments || 1),
      imageUrl: row.imageUrl || row.graphicUrl || "",
      ctaLabel: row.ctaLabel || row.linkLabel || "Know more",
      imageMobile: row.imageMobile || "",
      imageDesktop: row.imageDesktop || "",
      showInPortal: row.showInPortal === true,
      showOnSite: row.showOnSite !== false
    });
  }

  async function save(e) {
    e.preventDefault();
    setErr("");
    try {
      const api = await getDb();
      const id = (form.id || form.title || "promo").toLowerCase().replace(/[^a-z0-9]+/g, "-").slice(0, 40) || "promo";
      const payload = {
        type: form.type || "tuition",
        title: form.title,
        description: form.description,
        promoAmount: form.type === "tuition" ? (Number(form.promoAmount) || 0) : 0,
        active: !!form.active && !form.hibernated,
        hibernated: !!form.hibernated,
        programs: form.type === "tuition"
          ? String(form.programs || "").split(",").map((s) => s.trim()).filter(Boolean)
          : [],
        badge: form.badge || "Promo",
        requiresCode: form.type === "tuition" ? !!form.requiresCode : false,
        code: form.requiresCode ? String(form.code || "").trim().toUpperCase() : "",
        endsAt: form.endsAt ? new Date(form.endsAt) : null,
        linkUrl: (form.type === "announcement" || form.type === "announcement_link") ? (form.linkUrl || "") : "",
        linkLabel: (form.type === "announcement" || form.type === "announcement_link") ? (form.linkLabel || "Read more") : "",
        bgColor: (form.type === "announcement" || form.type === "announcement_link") ? String(form.bgColor || "").trim() : "",
        bgGradient: (form.type === "announcement" || form.type === "announcement_link") ? String(form.bgGradient || "").trim() : "",
        textColor: (form.type === "announcement" || form.type === "announcement_link") ? String(form.textColor || "#ffffff").trim() : "",
        buttonColor: (form.type === "announcement" || form.type === "announcement_link") ? String(form.buttonColor || "#ffffff").trim() : "",
        buttonTextColor: (form.type === "announcement" || form.type === "announcement_link") ? String(form.buttonTextColor || "#0f172a").trim() : "",
        bellText: String(form.bellText || "").trim(),
        bellButtonLabel: String(form.bellButtonLabel || "").trim(),
        bellButtonUrl: String(form.bellButtonUrl || "").trim(),
        repeatHours: (form.type === "announcement" || form.type === "announcement_link") ? (Number(form.repeatHours) || 0) : 0,
        installmentsMax: form.type === "tuition" ? Math.min(3, Math.max(1, Number(form.installmentsMax) || 1)) : 1,
        imageUrl: String(form.imageUrl || "").trim(),
        ctaLabel: String(form.ctaLabel || form.linkLabel || "Know more").trim(),
        imageMobile: form.imageMobile || "",
        imageDesktop: form.imageDesktop || "",
        showInPortal: form.showInPortal === true,
        showOnSite: form.showOnSite !== false,
        updatedAt: api.serverTimestamp()
      };
            if (form.type === "announcement") {
        payload.linkUrl = "";
        payload.linkLabel = "";
        payload.bellButtonUrl = "";
        payload.bellButtonLabel = "";
      }
      if (form.type === "announcement_link" && !payload.linkUrl && form.bellButtonUrl) {
        payload.linkUrl = form.bellButtonUrl;
      }
      await api.setDoc(api.doc(api.db, "promotions", id), payload, { merge: true });
      setMsg("Saved and published. Public site updates on refresh.");
      toast("Promotion is live", "ok");
      setEditing(null);
      load();
    } catch (ex) {
      setErr("Could not save: " + (ex.message || ex));
      toast("Could not save promotion", "error");
    }
  }

  async function hibernate(row) {
    try {
      const api = await getDb();
      await api.updateDoc(api.doc(api.db, "promotions", row.id), {
        hibernated: true,
        active: false,
        updatedAt: api.serverTimestamp()
      });
      load();
    } catch (e) {
      setErr(e.message || String(e));
    }
  }
  async function activate(row) {
    try {
      const api = await getDb();
      await api.updateDoc(api.doc(api.db, "promotions", row.id), {
        hibernated: false,
        active: true,
        updatedAt: api.serverTimestamp()
      });
      load();
    } catch (e) {
      setErr(e.message || String(e));
    }
  }
  async function remove(id) {
    if (!(await askConfirm("Delete this promotion permanently?"))) return;
    try {
      const api = await getDb();
      await moveToTrash("promotions", id);
      setEditing(null);
      load();
    } catch (e) {
      setErr(e.message || String(e));
    }
  }

  function statusBadge(st) {
    if (st === "active") return html`<${Badge} status="active" />`;
    if (st === "hibernated") return html`<span class="badge paused">paused</span>`;
    return html`<span class="badge pending">stopped</span>`;
  }

  return html`
    <div>
      <h1>Promotions</h1>
      <p class="sub">
        <strong>Tuition promos</strong> change programme prices. <strong>Announcements</strong> are short notices (optional full message popup or link).
      </p>
      <${SubTabs}
        tabs=${[
          { id: "list", label: "Records" },
          { id: "edit", label: "Edit" }
        ]}
        active=${promoTab === "edit" ? "edit" : "list"}
        onChange=${(id) => {
          if (id === "list") { setPromoTab("list"); }
          else {
            setPromoTab("edit");
            if (!editing) { setEditing("new"); setForm({ ...empty }); }
          }
        }}
      />
      ${msg ? html`<p class="muted">${msg}</p>` : null}
      ${err ? html`<p class="error">${err}</p>` : null}

      ${promoTab === "edit" ? html`
        <form class="card" onSubmit=${save}>
          <h3>${editing === "new" || !editing ? "New promotion" : "Edit promotion"}</h3>
          <p class="muted" style=${{ marginBottom: "0.75rem" }}>
            <button type="button" class="ghost" onClick=${() => { setEditing("new"); setForm({ ...empty }); }}>Start blank</button>
          </p>
          <div class="form-row">
            <label class="muted">Type</label>
            <select value=${form.type} onChange=${(e) => setForm({ ...form, type: e.target.value })}>
              <option value="tuition">Tuition price promo</option>
              <option value="announcement">Announcement only</option>
              <option value="announcement_link">Announcement + link</option>
            </select>
          </div>
          <div class="form-row"><input placeholder="Title" value=${form.title} onInput=${(e) => setForm({ ...form, title: e.target.value })} required /></div>
          <div class="form-row"><textarea rows="3" placeholder="Short description (banner line)" value=${form.description} onInput=${(e) => setForm({ ...form, description: e.target.value })}></textarea></div>
          <div class="form-row">
            <label class="muted">Full message (shown in popup when user taps View)</label>
            <textarea rows="4" placeholder="Optional longer details for the popup…" value=${form.bellText || ""} onInput=${(e) => setForm({ ...form, bellText: e.target.value })}></textarea>
            <div class="muted" style=${{ fontSize: "0.75rem" }}>For tuition promos: View always opens a popup (title, price, this message). For announcements: Read more opens this text if set; otherwise goes to the link.</div>
          </div>
          ${form.type === "tuition" ? html`
            <div class="form-row"><label class="muted">Promo amount (NGN)</label><input type="number" value=${form.promoAmount} onInput=${(e) => setForm({ ...form, promoAmount: e.target.value })} /></div>
            <div class="form-row">
              <label class="muted">Programmes</label>
              <div style=${{ display: "flex", flexDirection: "column", gap: "0.5rem" }}>
                ${programOptions.map(({ id: key, label }) => html`
                  <${Toggle}
                    key=${key}
                    checked=${String(form.programs || "").split(",").map((s) => s.trim()).includes(key)}
                    label=${label}
                    onChange=${(v) => {
                      const set = new Set(String(form.programs || "").split(",").map((s) => s.trim()).filter(Boolean));
                      if (v) set.add(key); else set.delete(key);
                      setForm({ ...form, programs: Array.from(set).join(",") });
                    }}
                  />
                `)}
              </div>
            </div>
            <div class="card" style=${{ marginBottom: "0.75rem" }}>
              <p class="muted" style=${{ marginBottom: "0.5rem" }}>Button & destination (optional)</p>
              ${(form.type === "announcement" || form.type === "announcement_link") ? html`
                <div class="form-row"><label class="muted">Card colour (solid hex, optional)</label>
                  <input type="text" placeholder="#1e3a8a" value=${form.bgColor || ""} onInput=${(e) => setForm({ ...form, bgColor: e.target.value })} />
                </div>
                <div class="form-row"><label class="muted">Gradient (optional)</label>
                  <input type="text" placeholder="#1e3a8a, #0f172a or full CSS gradient" value=${form.bgGradient || ""} onInput=${(e) => setForm({ ...form, bgGradient: e.target.value })} />
                  <div class="muted" style=${{ fontSize: "0.75rem" }}>If set, gradient wins over solid. Example: <code>#7c3aed, #2563eb</code></div>
                </div>
                <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "0.5rem" }}>
                  <div><label class="muted">Text colour</label><input type="text" value=${form.textColor || "#ffffff"} onInput=${(e) => setForm({ ...form, textColor: e.target.value })} /></div>
                  <div><label class="muted">Button colour</label><input type="text" value=${form.buttonColor || "#ffffff"} onInput=${(e) => setForm({ ...form, buttonColor: e.target.value })} /></div>
                  <div><label class="muted">Button text</label><input type="text" value=${form.buttonTextColor || "#0f172a"} onInput=${(e) => setForm({ ...form, buttonTextColor: e.target.value })} /></div>
                </div>
              ` : null}
              ${(form.type === "announcement" || form.type === "announcement_link") ? html`
                <div class="form-row"><label class="muted">Card colour (solid hex, optional)</label>
                  <input type="text" placeholder="#1e3a8a" value=${form.bgColor || ""} onInput=${(e) => setForm({ ...form, bgColor: e.target.value })} />
                </div>
                <div class="form-row"><label class="muted">Gradient (optional)</label>
                  <input type="text" placeholder="#1e3a8a, #0f172a or full CSS gradient" value=${form.bgGradient || ""} onInput=${(e) => setForm({ ...form, bgGradient: e.target.value })} />
                  <div class="muted" style=${{ fontSize: "0.75rem" }}>If set, gradient wins over solid. Example: <code>#7c3aed, #2563eb</code></div>
                </div>
                <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "0.5rem" }}>
                  <div><label class="muted">Text colour</label><input type="text" value=${form.textColor || "#ffffff"} onInput=${(e) => setForm({ ...form, textColor: e.target.value })} /></div>
                  <div><label class="muted">Button colour</label><input type="text" value=${form.buttonColor || "#ffffff"} onInput=${(e) => setForm({ ...form, buttonColor: e.target.value })} /></div>
                  <div><label class="muted">Button text</label><input type="text" value=${form.buttonTextColor || "#0f172a"} onInput=${(e) => setForm({ ...form, buttonTextColor: e.target.value })} /></div>
                </div>
              ` : null}
              ${(form.type === "announcement" || form.type === "announcement_link") ? html`<div class="form-row">
                <label class="muted">Show the pop-up again after (hours)</label>
                <input type="number" min="0" step="1" placeholder="0 = only once until you edit it"
                  value=${form.repeatHours === 0 || form.repeatHours ? String(form.repeatHours) : "0"}
                  onInput=${(e) => setForm({ ...form, repeatHours: Math.max(0, Number(e.target.value) || 0) })} />
                <div class="muted" style=${{ fontSize: "0.75rem", marginTop: "0.25rem" }}>
                  0 = once per visitor until you change the announcement. Example: 24 = every day, 48 = every two days, 168 = weekly.
                </div>
              </div>` : null}
              <div class="form-row"><label class="muted">Button text</label><input value=${form.bellButtonLabel || ""} onInput=${(e) => setForm({ ...form, bellButtonLabel: e.target.value })} /></div>
              <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr", gap: "1rem" }}>
                <${MediaUploadField} kind="mobile" value=${form.imageMobile} folder=${(form.id || form.title || "promo").toLowerCase().replace(/[^a-z0-9]+/g, "-").slice(0, 40)} onChange=${(v) => setForm({ ...form, imageMobile: v })} />
                <${MediaUploadField} kind="desktop" value=${form.imageDesktop} folder=${(form.id || form.title || "promo").toLowerCase().replace(/[^a-z0-9]+/g, "-").slice(0, 40)} onChange=${(v) => setForm({ ...form, imageDesktop: v })} />
              </div>
              <div class="form-row"><label class="muted">Button goes to</label>
                <select value=${bellDestKey(form.bellButtonUrl)} onChange=${(e) => setForm({ ...form, bellButtonUrl: e.target.value === "custom" ? "https://" : e.target.value })}>
                  ${BELL_DESTS.map(([v, t]) => html`<option value=${v}>${t}</option>`)}
                </select>
                ${bellDestKey(form.bellButtonUrl) === "custom" ? html`<input style=${{ marginTop: "0.5rem" }} placeholder="https://…" value=${form.bellButtonUrl || ""} onInput=${(e) => setForm({ ...form, bellButtonUrl: e.target.value })} />` : null}
                <div class="muted" style=${{ fontSize: "0.75rem" }}>Leave both fields empty for an announcement to use its own link button.</div></div>
            </div>
            <div style=${{ marginBottom: "0.65rem" }}>
              <${Toggle} checked=${form.requiresCode} label="Requires promo code" onChange=${(v) => setForm({ ...form, requiresCode: v })} />
            </div>
            ${form.requiresCode ? html`<div class="form-row"><input placeholder="Code" value=${form.code} onInput=${(e) => setForm({ ...form, code: e.target.value })} /></div>` : null}
            <div class="form-row">
              <label class="muted">Payment plan options (1 = full only, up to 3 installments)</label>
              <select value=${form.installmentsMax} onChange=${(e) => setForm({ ...form, installmentsMax: e.target.value })}>
                <option value="1">Full payment only</option>
                <option value="2">Full or 2 installments</option>
                <option value="3">Full or 3 installments</option>
              </select>
            </div>
          ` : html`
          <div class="form-row">
            <label class="muted">Show the pop-up again after (hours)</label>
            <input type="number" min="0" step="0.5" placeholder="0 = only once until you edit it"
              value=${form.repeatHours === 0 || form.repeatHours ? String(form.repeatHours) : "0"}
              onInput=${(e) => setForm({ ...form, repeatHours: Math.max(0, Number(e.target.value) || 0) })} />
            <div class="muted" style=${{ fontSize: "0.75rem", marginTop: "0.25rem" }}>
              0 = once per visitor until you change it. Example: 24 = daily, 0.5 = every 30 minutes.
            </div>
          </div>
          <div class="form-row"><label class="muted">Card colour (solid hex, optional)</label>
            <input type="text" placeholder="#1e3a8a" value=${form.bgColor || ""} onInput=${(e) => setForm({ ...form, bgColor: e.target.value })} />
          </div>
          <div class="form-row"><label class="muted">Gradient (optional)</label>
            <input type="text" placeholder="#1e3a8a, #0f172a" value=${form.bgGradient || ""} onInput=${(e) => setForm({ ...form, bgGradient: e.target.value })} />
          </div>
          ${form.type === "announcement_link" ? html`
            <div class="card" style=${{ marginBottom: "0.75rem", marginTop: "0.5rem" }}>
              <p class="muted" style=${{ marginBottom: "0.5rem" }}>Link (visitor taps the button)</p>
              <div class="form-row"><label class="muted">Link URL</label><input placeholder="https://… or /contact" value=${form.linkUrl} onInput=${(e) => setForm({ ...form, linkUrl: e.target.value })} /></div>
              <div class="form-row"><label class="muted">Button text</label><input placeholder="Read more" value=${form.linkLabel} onInput=${(e) => setForm({ ...form, linkLabel: e.target.value })} /></div>
              <div class="form-row"><label class="muted">Or choose a page</label>
                <select value=${bellDestKey(form.bellButtonUrl || form.linkUrl)} onChange=${(e) => {
                  const v = e.target.value === "custom" ? "https://" : e.target.value;
                  setForm({ ...form, bellButtonUrl: v, linkUrl: v.indexOf("http") === 0 || v.indexOf("/") === 0 ? v : form.linkUrl });
                }}>
                  ${BELL_DESTS.map(([v, lab]) => html`<option value=${v}>${lab}</option>`)}
                </select>
              </div>
            </div>
          ` : html`
            <p class="muted" style=${{ fontSize: "0.8rem", marginBottom: "0.75rem" }}>Announcement only — no link button. Visitors read the card / full message popup.</p>
          `}
          `}
          <div class="form-row"><label class="muted">Ends on (optional — auto stops)</label><input type="datetime-local" value=${form.endsAt} onInput=${(e) => setForm({ ...form, endsAt: e.target.value })} /></div>
          <div style=${{ marginBottom: "0.85rem" }}>
            <div class="form-row"><label class="muted">Portal graphic URL (portrait/banner image)</label>
          <input value=${form.imageUrl || ""} onInput=${(e) => setForm({ ...form, imageUrl: e.target.value })} placeholder="https://…/announce.webp — recommended 1080×1350 or 16:10" /></div>
        <div class="form-row"><label class="muted">CTA button label</label>
          <input value=${form.ctaLabel || ""} onInput=${(e) => setForm({ ...form, ctaLabel: e.target.value })} placeholder="Know more" /></div>
        <div class="form-row"><${Toggle} checked=${form.showOnSite !== false} label="Show on main website" onChange=${(v) => setForm({ ...form, showOnSite: v })} /></div>
        <div class="form-row"><${Toggle} checked=${!!form.showInPortal} label="Show on student portal dashboard (separate from website)" onChange=${(v) => setForm({ ...form, showInPortal: v })} /></div>
        <${Toggle} checked=${form.active} label="Active (live when on)" onChange=${(v) => setForm({ ...form, active: v, hibernated: v ? false : form.hibernated })} />
          </div>
          <button class="primary" type="submit">Save and go live</button>
          <button class="ghost" type="button" onClick=${() => { setEditing(null); setPromoTab("list"); }}>Cancel</button>
          ${editing && editing !== "new" ? html`<button class="ghost" type="button" onClick=${() => remove(editing)}>Delete</button>` : null}
        </form>
      ` : html`
      <div style=${{ marginBottom: "0.75rem" }}>
        <button class="primary" type="button" onClick=${openNew}>New promotion</button>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Title</th><th>Type</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            ${rows.map((r) => html`
              <tr key=${r.id}>
                <td data-label="Title">${r.title}<div class="muted">${(r.description || "").slice(0, 60)}</div></td>
                <td data-label="Type" class="muted">${r.type === "announcement_link" ? "Announcement + link" : r.type === "announcement" ? "Announcement" : "Tuition"}</td>
                <td data-label="Status">${statusBadge(r._status)}</td>
                <td class="row-actions">
                  <button class="ghost" type="button" onClick=${() => openEdit(r)}>Edit</button>
                  ${r._status === "hibernated"
                    ? html`<button class="ghost" type="button" onClick=${() => activate(r)}>Activate</button>`
                    : html`<button class="ghost" type="button" onClick=${() => hibernate(r)}>Pause</button>`}
                  <button class="ghost" type="button" onClick=${() => remove(r.id)}>Delete</button>
                </td>
              </tr>
            `)}
          </tbody>
        </table>
      </div>
      `}
    </div>
  `;
}

function PartnersPanel() {
  const [rows, setRows] = useState([]);
  const [name, setName] = useState("");
  const [err, setErr] = useState("");
  const [msg, setMsg] = useState("");

  async function load() {
    try {
      const api = await getDb();
      const snap = await api.getDoc(api.doc(api.db, "siteContent", "partners"));
      if (snap.exists()) {
        const data = snap.data();
        // support names: string[] or [{name, active}]
        let list = data.items || data.names || [];
        if (list.length && typeof list[0] === "string") {
          list = list.map((n) => ({ name: n, active: true }));
        }
        setRows(list);
      } else {
        setRows([]);
      }
    } catch (e) {
      setErr("Could not load partners: " + (e.message || e));
    }
  }
  useEffect(() => { load(); }, []);

  async function persist(list) {
    const api = await getDb();
    await api.setDoc(api.doc(api.db, "siteContent", "partners"), {
      items: list,
      names: list.filter((x) => x.active !== false).map((x) => x.name),
      updatedAt: api.serverTimestamp()
    }, { merge: true });
  }

  async function add(e) {
    e.preventDefault();
    if (!name.trim()) return;
    const list = rows.concat([{ name: name.trim(), active: true }]);
    try {
      await persist(list);
      setRows(list);
      setName("");
      setMsg("Partner added");
    } catch (ex) {
      setErr(ex.message || String(ex));
    }
  }

  async function hibernate(i) {
    const list = rows.slice();
    list[i] = { ...list[i], active: list[i].active === false };
    try {
      await persist(list);
      setRows(list);
    } catch (e) {
      setErr(e.message || String(e));
    }
  }

  async function remove(i) {
    if (!(await askConfirm("Remove this partner?"))) return;
    const list = rows.slice();
    list.splice(i, 1);
    try {
      await persist(list);
      setRows(list);
    } catch (e) {
      setErr(e.message || String(e));
    }
  }

  return html`
    <div>
      <h1>Partners</h1>
      <p class="sub">Pause hides a partner from the public list without deleting. Delete removes them permanently.</p>
      <form class="card" onSubmit=${add} style=${{ marginBottom: "1rem" }}>
        <div class="form-row"><input placeholder="Partner name" value=${name} onInput=${(e) => setName(e.target.value)} /></div>
        <button class="primary">Add partner</button>
        ${msg ? html`<p class="muted">${msg}</p>` : null}
        ${err ? html`<p class="error">${err}</p>` : null}
      </form>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Name</th><th>Status</th><th></th></tr></thead>
          <tbody>
            ${rows.map((r, i) => html`
              <tr key=${i}>
                <td>${r.name}</td>
                <td><${Badge} status=${r.active === false ? "inactive" : "active"} /></td>
                <td>
                  <button class="ghost" onClick=${() => hibernate(i)}>${r.active === false ? "Activate" : "Hibernate"}</button>
                  <button class="ghost" onClick=${() => remove(i)}>Delete</button>
                </td>
              </tr>
            `)}
          </tbody>
        </table>
      </div>
    </div>
  `;
}


function InstitutionalPanel() {
  const [rows, setRows] = useState([]);
  const [err, setErr] = useState("");
  async function load() {
    try {
      const api = await getDb();
      let list = [];
      try {
        const snap = await api.getDocs(api.collection(api.db, "customInquiries"));
        snap.forEach((d) => list.push({ id: d.id, ...d.data(), _src: "custom" }));
      } catch (e) {}
      try {
        const snap2 = await api.getDocs(api.collection(api.db, "contactMessages"));
        snap2.forEach((d) => {
          const data = d.data();
          const typ = String(data.type || data.formType || data.source || "").toLowerCase();
          if (typ.includes("institut") || typ.includes("custom") || typ.includes("school") || typ.includes("org")) {
            list.push({ id: d.id, ...data, _src: "contact" });
          }
        });
      } catch (e) {}
      setRows(list);
    } catch (e) { setErr(e.message || String(e)); }
  }
  useEffect(() => { load(); }, []);
  return html`
    <div>
      <h1>Institutional inquiries</h1>
      <p class="muted">From the Custom / institutional page — separate from general Contact messages.</p>
      ${err ? html`<p class="error">${err}</p>` : null}
      <div class="table-wrap">
        <table>
          <thead><tr><th>Name</th><th>Email</th><th>Type</th><th>Org / school</th><th>Message</th></tr></thead>
          <tbody>
            ${rows.length === 0 ? html`<tr><td colspan="5" class="muted">No institutional inquiries yet.</td></tr>` : null}
            ${rows.map((r) => html`
              <tr key=${r.id}>
                <td>${r.name || r.fullName || "—"}</td>
                <td>${r.email || r.contactValue || "—"}</td>
                <td>${r.applicantType || r.type || "—"}</td>
                <td>${r.organization || r.schoolName || r.company || "—"}</td>
                <td style=${{ maxWidth: "200px", fontSize: "0.75rem" }}>${String(r.message || r.details || "").slice(0, 120)}</td>
              </tr>
            `)}
          </tbody>
        </table>
      </div>
    </div>
  `;
}


const LEGAL_SEED = {"terms": [{"heading": "1. Acceptance of Terms", "body": "By using this website or applying to any CGTIA program, you agree to these terms. If you don't agree, please don't use the site or submit an application."}, {"heading": "2. Eligibility", "body": "Our programs are open to applicants 18 years of age and older. Licensing specifically requires prior training, a valid lifesaving certification, and completed clinical hours as described on the Licensing page."}, {"heading": "3. Applications & Enrollment", "body": "Submitting an application does not guarantee admission. We review each application and will let you know whether you've been provisionally accepted. A seat in a program is only confirmed once payment has been made and verified — by card through Paystack, or by bank transfer confirmed by our team."}, {"heading": "4. Payments & Fees", "body": "• Program fees are as stated on the Tuition & Fees page at the time of your application.\n• Bank transfers are verified manually and may take some time to confirm.\n• Card payments are processed securely through Paystack; we don't store your card details.\n• The Licensing fee is non-refundable once payment has been verified, as stated on the Licensing page.\n• For other programs, refund requests are considered on a case-by-case basis — contact admissions to discuss."}, {"heading": "5. Documents You Submit", "body": "For Licensing applications, you confirm that any certificate, ID, or photo you upload is authentic, current, and genuinely yours. Submitting false or altered documents will result in disqualification, as stated on the Licensing page's rules and regulations."}, {"heading": "6. Student Portal Accounts", "body": "If you're issued a student portal login, you're responsible for keeping your password confidential and for anything done through your account. Let us know immediately if you suspect unauthorized access."}, {"heading": "7. Acceptable Use", "body": "Please don't use this site to submit false information, attempt to access accounts or data that aren't yours, or interfere with the site's normal operation."}, {"heading": "8. Intellectual Property", "body": "The content on this site — text, curriculum descriptions, images, and branding — belongs to Caregivers Training & Internship Academy Limited unless otherwise noted, and shouldn't be reused without permission."}, {"heading": "9. Disclaimer & Limitation of Liability", "body": "This site and its content are provided \"as is.\" While we work to keep information accurate and the site running smoothly, we don't guarantee it will be error-free or uninterrupted, and we're not liable for indirect or consequential losses arising from your use of the site, to the extent permitted by law."}, {"heading": "10. Governing Law", "body": "These terms are governed by the laws of the Federal Republic of Nigeria."}, {"heading": "11. Changes to These Terms", "body": "We may update these terms from time to time. We'll update the date at the top of this page when we do — continued use of the site after changes means you accept the updated terms."}, {"heading": "12. Contact", "body": "Questions about these terms can be sent through the Contact page or to admissions@cgtia.org."}], "privacy": [{"heading": "1. What We Collect", "body": "Depending on which form you use on this site, we may collect:\n• Your name, phone number, and email address\n• Program interest, application details, and any message you write to us\n• For Licensing applications specifically: a copy of your training certificate, a government ID (NIN slip or international passport), and a live selfie photo\n• Payment-related information processed through Paystack (we do not see or store your full card details — that's handled entirely by Paystack)\n• Basic technical information like your browser type and general location, for security and to keep the site working properly"}, {"heading": "2. Why We Collect It", "body": "• To process your application, admission, and enrollment\n• To verify your identity and qualifications for the Licensing program specifically\n• To process payments and confirm your seat in a program\n• To create and secure your student portal account, once payment is confirmed\n• To respond to questions sent through the Contact page or FAQ\n• To meet our own record-keeping and regulatory obligations as a training institution"}, {"heading": "3. Where It's Stored", "body": "Your data is stored on Google Firebase (Firestore and Cloud Storage), Google's cloud infrastructure. Login-code emails are sent through Gmail. Payments are processed by Paystack, a licensed Nigerian payment processor — we don't store your card or bank login details ourselves."}, {"heading": "4. Who Can See It", "body": "Your application and documents are visible only to authorized CGTIA staff reviewing admissions and licensing, plus the third-party processors above strictly for the purpose of doing their job (Paystack for payment, Google for hosting/email delivery). We do not sell your information, and we do not share it with advertisers."}, {"heading": "5. How Long We Keep It", "body": "We keep application and enrollment records for as long as needed for academic, regulatory, and accreditation purposes. If your application isn't approved or you don't proceed with payment, we'll retain your submission for a reasonable period for our own records before it's eligible for deletion on request."}, {"heading": "6. Your Rights", "body": "You can ask us to:\n• Show you what data we hold about you\n• Correct inaccurate information\n• Delete your data, where we're not required to keep it for legal or academic record-keeping reasons\nReach out through the Contact page to make any of these requests."}, {"heading": "7. Cookies", "body": "This site does not use advertising or tracking cookies. Any cookies set are strictly functional (for example, keeping you signed in to the student portal)."}, {"heading": "8. Children's Privacy", "body": "Our programs are intended for applicants 18 years of age and older. We don't knowingly collect information from anyone younger."}, {"heading": "9. Changes to This Policy", "body": "We may update this policy as the site and our programs evolve. We'll update the date at the top of this page when we do."}, {"heading": "10. Contact", "body": "Questions about this policy or your data can be sent through the Contact page or to admissions@cgtia.org."}]};

function LegalPagesEditor() {
  const [which, setWhich] = useState("terms");
  const [data, setData] = useState({ terms: { sections: LEGAL_SEED.terms }, privacy: { sections: LEGAL_SEED.privacy } });
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const api = await getDb();
        const snap = await api.getDoc(api.doc(api.db, "siteContent", "legalPages"));
        const d = snap && typeof snap.data === "function" ? snap.data() : null;
        if (d) {
          setData({
            terms: { sections: d.terms && Array.isArray(d.terms.sections) && d.terms.sections.length ? d.terms.sections : LEGAL_SEED.terms },
            privacy: { sections: d.privacy && Array.isArray(d.privacy.sections) && d.privacy.sections.length ? d.privacy.sections : LEGAL_SEED.privacy }
          });
        }
      } catch (e) {
        setErr(e.message || String(e));
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const list = data[which].sections;
  function setList(next) { setData({ ...data, [which]: { sections: next } }); }
  function move(i, dir) {
    const next = list.slice();
    const j = i + dir;
    if (j < 0 || j >= next.length) return;
    [next[i], next[j]] = [next[j], next[i]];
    setList(next);
  }

  async function save(e) {
    e.preventDefault();
    setErr("");
    const clean = (arr) => arr.map((x) => ({ heading: String(x.heading || "").trim(), body: String(x.body || "").trim() })).filter((x) => x.heading || x.body);
    try {
      const api = await getDb();
      await api.setDoc(api.doc(api.db, "siteContent", "legalPages"), {
        terms: { sections: clean(data.terms.sections) },
        privacy: { sections: clean(data.privacy.sections) },
        updatedAt: api.serverTimestamp()
      }, { merge: true });
      toast("Saved — refresh the public site to see it", "ok");
    } catch (ex) {
      setErr(ex.message || String(ex));
      toast("Save failed", "error");
    }
  }

  return html`
    <div>
      <h1>Terms & Privacy</h1>
      <p class="muted">Edit each section's heading and wording. Start a new line in a section to make a new paragraph. Begin a line with • for a bullet point.</p>
      ${loading ? html`<${Skeleton} rows=${4} />` : null}
      ${err ? html`<p class="error">${err}</p>` : null}
      <div style=${{ display: "flex", gap: "0.5rem", marginBottom: "1rem" }}>
        <button type="button" class=${which === "terms" ? "primary" : "ghost"} onClick=${() => setWhich("terms")}>Terms & Conditions</button>
        <button type="button" class=${which === "privacy" ? "primary" : "ghost"} onClick=${() => setWhich("privacy")}>Privacy Policy</button>
      </div>
      <form onSubmit=${save}>
        ${list.map((sec, i) => html`
          <div class="card" key=${which + "-" + i} style=${{ marginBottom: "0.75rem" }}>
            <div style=${{ display: "flex", gap: "0.5rem", alignItems: "center", marginBottom: "0.5rem" }}>
              <input style=${{ fontWeight: 600 }} value=${sec.heading || ""} placeholder="Section heading" onInput=${(e) => setList(list.map((x, j) => (j === i ? { ...x, heading: e.target.value } : x)))} />
              <button type="button" class="ghost" onClick=${() => move(i, -1)}>↑</button>
              <button type="button" class="ghost" onClick=${() => move(i, 1)}>↓</button>
              <button type="button" class="ghost" style=${{ color: "#dc2626" }} onClick=${() => setList(list.filter((_, j) => j !== i))}>Remove</button>
            </div>
            <textarea rows="5" value=${sec.body || ""} placeholder="Wording for this section" onInput=${(e) => setList(list.map((x, j) => (j === i ? { ...x, body: e.target.value } : x)))}></textarea>
          </div>
        `)}
        <div style=${{ display: "flex", gap: "0.5rem" }}>
          <button type="button" class="ghost" onClick=${() => setList([...list, { heading: "", body: "" }])}>+ Add a section</button>
          <button class="primary" type="submit">Save</button>
        </div>
      </form>
    </div>
  `;
}

const APPLY_TEXT_KEYS = [
  ["applyEyebrow", "Small label at the top", "Admissions"],
  ["applyTitle", "Form title", "Apply to CGTIA"],
  ["labelFullName", "Label: full name", "Full Name"],
  ["labelPhone", "Label: phone number", "Phone Number"],
  ["labelEmail", "Label: email", "Email Address"],
  ["labelProgram", "Label: programme", "Program of Interest"],
  ["labelStartDate", "Label: start date", "Program Start Date"],
  ["labelMessage", "Label: message box", "Tell us a little about you"],
  ["labelSubmit", "Submit button text", "Submit Application"]
];
const FIELD_TYPES = [
  ["text", "Short text"], ["phone", "Phone number"], ["email", "Email"],
  ["date", "Date (calendar)"], ["long", "Long text"], ["select", "Dropdown"]
];

function ApplyFormEditor() {
  const defaults = Object.fromEntries(APPLY_TEXT_KEYS.map(([k, , v]) => [k, v]));
  const [form, setForm] = useState({ ...defaults, customFields: [] });
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const api = await getDb();
        const snap = await api.getDoc(api.doc(api.db, "siteContent", "applyForm"));
        const d = snap && typeof snap.data === "function" ? snap.data() : null;
        if (d) setForm({ ...defaults, ...d, customFields: Array.isArray(d.customFields) ? d.customFields : [] });
      } catch (e) {
        setErr(e.message || String(e));
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const fields = form.customFields || [];
  function setFields(next) { setForm({ ...form, customFields: next }); }
  function moveField(i, dir) {
    const next = fields.slice();
    const j = i + dir;
    if (j < 0 || j >= next.length) return;
    [next[i], next[j]] = [next[j], next[i]];
    setFields(next);
  }
  function patchField(i, patch) { setFields(fields.map((f, j) => (j === i ? { ...f, ...patch } : f))); }

  async function save(e) {
    e.preventDefault();
    setErr("");
    const payload = {};
    APPLY_TEXT_KEYS.forEach(([k, , v]) => { payload[k] = String(form[k] || "").trim() || v; });
    payload.customFields = fields
      .map((f) => ({
        label: String(f.label || "").trim(),
        type: f.type || "text",
        required: !!f.required,
        options: f.type === "select" ? String(f.options || "").split(",").map((x) => x.trim()).filter(Boolean) : []
      }))
      .filter((f) => f.label);
    try {
      const api = await getDb();
      await api.setDoc(api.doc(api.db, "siteContent", "applyForm"), { ...payload, updatedAt: api.serverTimestamp() }, { merge: true });
      toast("Apply form saved — refresh the public site to see it", "ok");
    } catch (ex) {
      setErr(ex.message || String(ex));
      toast("Save failed", "error");
    }
  }

  return html`
    <div>
      <h1>Apply form</h1>
      <p class="muted">Change the wording of the application form, and add or remove questions. Questions appear after the built-in ones, in the order you set. Uploads are not available here yet.</p>
      ${loading ? html`<${Skeleton} rows=${4} />` : null}
      ${err ? html`<p class="error">${err}</p>` : null}
      <form onSubmit=${save}>
        <div class="card" style=${{ marginBottom: "1rem" }}>
          <p class="muted" style=${{ marginBottom: "0.5rem" }}>Wording</p>
          ${APPLY_TEXT_KEYS.map(([k, label]) => html`
            <div class="form-row"><label class="muted">${label}</label>
              <input value=${form[k] || ""} onInput=${(e) => setForm({ ...form, [k]: e.target.value })} /></div>
          `)}
        </div>
        <div class="card" style=${{ marginBottom: "1rem" }}>
          <p class="muted" style=${{ marginBottom: "0.5rem" }}>Extra questions</p>
          ${fields.length === 0 ? html`<p class="muted">No extra questions yet.</p>` : null}
          ${fields.map((f, i) => html`
            <div class="card" key=${"cf-" + i} style=${{ marginBottom: "0.5rem", padding: "0.75rem" }}>
              <div style=${{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: "0.5rem", marginBottom: "0.5rem" }}>
                <input placeholder="Question heading, e.g. Nest of King" value=${f.label || ""} onInput=${(e) => patchField(i, { label: e.target.value })} />
                <select value=${f.type || "text"} onChange=${(e) => patchField(i, { type: e.target.value })}>
                  ${FIELD_TYPES.map(([v, t]) => html`<option value=${v}>${t}</option>`)}
                </select>
              </div>
              ${f.type === "select" ? html`<input style=${{ marginBottom: "0.5rem" }} placeholder="Options, separated by commas" value=${(f.options || []).join(", ")} onInput=${(e) => patchField(i, { options: e.target.value.split(",") })} />` : null}
              <div style=${{ display: "flex", gap: "0.5rem", alignItems: "center", flexWrap: "wrap" }}>
                <${Toggle} checked=${!!f.required} label="Required" onChange=${(v) => patchField(i, { required: v })} />
                <button type="button" class="ghost" onClick=${() => moveField(i, -1)}>↑</button>
                <button type="button" class="ghost" onClick=${() => moveField(i, 1)}>↓</button>
                <button type="button" class="ghost" style=${{ color: "#dc2626" }} onClick=${() => setFields(fields.filter((_, j) => j !== i))}>Remove</button>
              </div>
            </div>
          `)}
          <button type="button" class="ghost" onClick=${() => setFields([...fields, { label: "", type: "text", required: false, options: [] }])}>+ Add a question</button>
        </div>
        <button class="primary" type="submit">Save apply form</button>
      </form>
    </div>
  `;
}

const PAGE_LIST = [
  ["home", "Home", "/"], ["about", "About", "/about"], ["programs", "Programmes", "/programs"],
  ["gallery", "Gallery", "/gallery"], ["tuition", "Tuition & Fees", "/tuition"], ["contact", "Contact", "/contact"],
  ["licensing", "Licensing", "/licensing"], ["custom", "Custom / institutional", "/custom"],
  ["privacy", "Privacy Policy", "/privacy"], ["terms", "Terms", "/terms"], ["verify", "Verify certificate", "/verify"],
  ["dashboard", "Student dashboard", "/dashboard"], ["wallOfFame", "Wall of fame", "/wall-of-fame"],
  ["faq", "FAQ", "/faq"], ["licensingComplete", "Licensing complete", "/licensing/complete"], ["payFee", "Fee payment", "/pay-fee"]
];
const PAGE_MODES = [
  ["live", "Live — show the page"],
  ["maintenance", "Maintenance — show a message"],
  ["notfound", "Not found — show a 'page not found' message"],
  ["hidden", "Hidden — show a blank page with a home link"]
];

const VERIFY_KINDS = [["certificate", "Certificate"], ["id-card", "ID card"], ["licence", "Licence"], ["student", "Student record"]];
const VERIFY_FIELDS = [
  ["name", "Full name"], ["regNumber", "Reg number"], ["program", "Programme"], ["cohort", "Cohort"], ["grade", "Grade"],
  ["category", "Category"], ["status", "Status"], ["issueDate", "Issue date"], ["expiryDate", "Expiry date"],
  ["renewedAt", "Renewed on"], ["code", "Certificate / card code"], ["licenceNumber", "Licence number"], ["photo", "Photo"]
];
const VERIFY_DEFAULTS = {
  certificate: ["name", "regNumber", "program", "issueDate", "code", "status"],
  "id-card": ["name", "regNumber", "program", "issueDate", "expiryDate", "code", "status", "photo"],
  licence: ["name", "licenceNumber", "category", "expiryDate", "renewedAt", "status"],
  student: ["name", "regNumber", "program", "cohort", "status", "photo"]
};

function VerifyFieldsPanel() {
  const [cfg, setCfg] = useState({});
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const api = await getDb();
        const snap = await api.getDoc(api.doc(api.db, "siteContent", "verifySettings"));
        const d = snap && typeof snap.data === "function" ? snap.data() : null;
        setCfg(d || {});
      } catch (e) {
        setErr(e.message || String(e));
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const shown = (kind) => (Array.isArray(cfg[kind]) ? cfg[kind] : VERIFY_DEFAULTS[kind]);
  function toggle(kind, key) {
    const list = shown(kind);
    setCfg({ ...cfg, [kind]: list.indexOf(key) >= 0 ? list.filter((k) => k !== key) : list.concat([key]) });
  }

  async function save() {
    setErr("");
    try {
      const api = await getDb();
      const payload = {};
      VERIFY_KINDS.forEach(([k]) => { payload[k] = shown(k); });
      await api.setDoc(api.doc(api.db, "siteContent", "verifySettings"), { ...payload, updatedAt: api.serverTimestamp() }, { merge: true });
      toast("Verification display saved", "ok");
    } catch (ex) {
      setErr(ex.message || String(ex));
      toast("Save failed", "error");
    }
  }

  return html`
    <div>
      <h1>Verification display</h1>
      <p class="muted">Tick what a visitor sees when they verify each kind of record. Anything not ticked stays hidden. Email, phone, ID number, date of birth and next of kin are never shown.</p>
      ${loading ? html`<${Skeleton} rows=${4} />` : null}
      ${err ? html`<p class="error">${err}</p>` : null}
      ${VERIFY_KINDS.map(([kind, label]) => html`
        <div class="card" key=${kind} style=${{ marginBottom: "0.75rem" }}>
          <strong>${label}</strong>
          <div style=${{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(12rem, 1fr))", gap: "0.4rem 1rem", marginTop: "0.5rem" }}>
            ${VERIFY_FIELDS.map(([key, text]) => html`
              <label key=${key} style=${{ display: "flex", gap: "0.4rem", alignItems: "center", fontSize: "0.9rem" }}>
                <${Toggle} checked=${shown(kind).indexOf(key) >= 0} label=${text} onChange=${() => toggle(kind, key)} />
              </label>`)}
          </div>
        </div>`)}
      <button class="primary" type="button" onClick=${save}>Save verification display</button>
    </div>
  `;
}

function PageControlPanel() {
  const [rules, setRules] = useState({});
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const api = await getDb();
        const snap = await api.getDoc(api.doc(api.db, "siteContent", "pageControl"));
        setRules(snap && typeof snap.data === "function" && snap.data() ? snap.data() : {});
      } catch (e) {
        setErr(e.message || String(e));
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  function patch(key, change) {
    setRules({ ...rules, [key]: { mode: "live", title: "", message: "", ...(rules[key] || {}), ...change } });
  }

  async function save() {
    setErr("");
    try {
      const api = await getDb();
      const clean = {};
      PAGE_LIST.forEach(([key]) => {
        const r = rules[key] || {};
        clean[key] = { mode: r.mode || "live", title: String(r.title || "").trim(), message: String(r.message || "").trim() };
      });
      await api.setDoc(api.doc(api.db, "siteContent", "pageControl"), { ...clean, updatedAt: api.serverTimestamp() }, { merge: true });
      toast("Page visibility saved — refresh the public site", "ok");
    } catch (ex) {
      setErr(ex.message || String(ex));
      toast("Save failed", "error");
    }
  }

  return html`
    <div>
      <h1>Page visibility</h1>
      <p class="muted">Switch any public page on or off. Maintenance and Not found show a message in place of the page. Hidden shows a blank page with a link home. Changes go live on the next page load.</p>
      ${loading ? html`<${Skeleton} rows=${4} />` : null}
      ${err ? html`<p class="error">${err}</p>` : null}
      ${PAGE_LIST.map(([key, label, path]) => {
        const r = rules[key] || { mode: "live" };
        const off = r.mode && r.mode !== "live";
        return html`
          <div class="card" key=${key} style=${{ marginBottom: "0.75rem" }}>
            <div style=${{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: "0.5rem", flexWrap: "wrap" }}>
              <div><strong>${label}</strong> <span class="muted" style=${{ fontSize: "0.8rem" }}>${path}</span></div>
              <span style=${{ fontSize: "0.75rem", padding: "0.2rem 0.6rem", borderRadius: "999px", background: off ? "#fee2e2" : "#dcfce7", color: off ? "#991b1b" : "#166534" }}>${off ? "Off" : "Live"}</span>
            </div>
            <div style=${{ display: "grid", gridTemplateColumns: "1fr", gap: "0.5rem", marginTop: "0.5rem" }}>
              <select value=${r.mode || "live"} onChange=${(e) => patch(key, { mode: e.target.value })}>
                ${PAGE_MODES.map(([v, t]) => html`<option value=${v}>${t}</option>`)}
              </select>
              ${off && r.mode !== "hidden" ? html`
                <input placeholder="Heading shown to visitors (optional)" value=${r.title || ""} onInput=${(e) => patch(key, { title: e.target.value })} />
                <textarea rows="2" placeholder="Message shown to visitors (optional)" value=${r.message || ""} onInput=${(e) => patch(key, { message: e.target.value })}></textarea>` : null}
            </div>
          </div>`;
      })}
      <button class="primary" type="button" onClick=${save}>Save page visibility</button>
    </div>
  `;
}

function TuitionPageEditor() {
  const empty = {
    eyebrow: "Admissions",
    headlineLead: "Tuition",
    headlineAccent: "& Fees",
    intro: "Clear, one-time program pricing \u2014 no hidden charges. Choose the track that matches where you are in your caregiving journey.",
    notesTitle: "Payment & Fees Notes",
    notesParagraphs: [
      "All program fees cover course materials, clinical lab access, and guided internship placement support. Fees are payable in full or in installments \u2014 speak with admissions for a payment plan that fits your schedule.",
      "Prices are current for the enrolling cohort and may be reviewed for future intakes."
    ],
    homeEyebrow: "Tuition Options",
    homeHeadline: "Straightforward Program Fees"
  };
  const [form, setForm] = useState(empty);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const api = await getDb();
        const snap = await api.getDoc(api.doc(api.db, "siteContent", "tuitionPage"));
        const d = snap && typeof snap.data === "function" ? snap.data() : null;
        if (d) {
          setForm({
            ...empty,
            ...d,
            notesParagraphs: Array.isArray(d.notesParagraphs) && d.notesParagraphs.length ? d.notesParagraphs : empty.notesParagraphs
          });
        }
      } catch (e) {
        setErr(e.message || String(e));
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  async function save(e) {
    e.preventDefault();
    setErr("");
    try {
      const api = await getDb();
      await api.setDoc(api.doc(api.db, "siteContent", "tuitionPage"), {
        eyebrow: form.eyebrow.trim(),
        headlineLead: form.headlineLead.trim(),
        headlineAccent: form.headlineAccent.trim(),
        intro: form.intro.trim(),
        notesTitle: form.notesTitle.trim(),
        notesParagraphs: (form.notesParagraphs || []).map((s) => String(s).trim()).filter(Boolean),
        homeEyebrow: form.homeEyebrow.trim(),
        homeHeadline: form.homeHeadline.trim(),
        updatedAt: api.serverTimestamp()
      }, { merge: true });
      toast("Tuition page saved — refresh the public site to see it", "ok");
    } catch (ex) {
      setErr(ex.message || String(ex));
      toast("Save failed", "error");
    }
  }

  const field = (label, key, multi) => html`
    <div class="form-row">
      <label class="muted">${label}</label>
      ${multi
        ? html`<textarea rows="3" value=${form[key] || ""} onInput=${(e) => setForm({ ...form, [key]: e.target.value })}></textarea>`
        : html`<input value=${form[key] || ""} onInput=${(e) => setForm({ ...form, [key]: e.target.value })} />`}
    </div>`;

  const paras = form.notesParagraphs || [];
  return html`
    <div>
      <h1>Tuition page</h1>
      <p class="muted">Every word on the Tuition page and the tuition heading on the home page. Programme prices and write-ups are edited in Programmes.</p>
      ${loading ? html`<${Skeleton} rows=${4} />` : null}
      ${err ? html`<p class="error">${err}</p>` : null}
      <form onSubmit=${save}>
        <div class="card" style=${{ marginBottom: "1rem" }}>
          <p class="muted" style=${{ marginBottom: "0.5rem" }}>Top of the Tuition page</p>
          ${field("Small label above the title", "eyebrow")}
          ${field("Title — first word", "headlineLead")}
          ${field("Title — italic part", "headlineAccent")}
          ${field("Intro paragraph", "intro", true)}
        </div>
        <div class="card" style=${{ marginBottom: "1rem" }}>
          <p class="muted" style=${{ marginBottom: "0.5rem" }}>Payment & Fees Notes</p>
          ${field("Section heading", "notesTitle")}
          ${paras.map((p, i) => html`
            <div key=${"np-" + i} style=${{ display: "flex", gap: "0.5rem", alignItems: "flex-start", marginBottom: "0.5rem" }}>
              <textarea rows="3" value=${p} onInput=${(e) => setForm({ ...form, notesParagraphs: paras.map((x, j) => (j === i ? e.target.value : x)) })}></textarea>
              <button type="button" class="ghost" onClick=${() => setForm({ ...form, notesParagraphs: paras.filter((_, j) => j !== i) })}>Remove</button>
            </div>
          `)}
          <button type="button" class="ghost" onClick=${() => setForm({ ...form, notesParagraphs: [...paras, ""] })}>+ Add a paragraph</button>
        </div>
        <div class="card" style=${{ marginBottom: "1rem" }}>
          <p class="muted" style=${{ marginBottom: "0.5rem" }}>Home page — tuition section heading</p>
          ${field("Small label", "homeEyebrow")}
          ${field("Heading", "homeHeadline")}
        </div>
        <button class="primary" type="submit">Save tuition page</button>
      </form>
    </div>
  `;
}


function ProgramsPageEditor() {
  const emptyCard = () => ({ badge: "", title: "", body: "", bullets: ["", "", ""] });
  const emptyDelivery = () => ({ label: "", title: "", body: "" });
  const emptyPathStep = () => ({ num: "", title: "", body: "" });
  const defaultPathSteps = () => [
    { num: "01", title: "Certificate", body: "Full caregiving curriculum across 16 course modules, with guided clinical placement." },
    { num: "02", title: "Diploma", body: "Advanced technique and nanny training, building on your Level 1 certification." },
    { num: "03", title: "Higher Diploma", body: "Proficiency and leadership skill for on-site staff training and coordination roles." },
    { num: "04", title: "Licensing", body: "For qualified individuals with prior training, lifesaving certification, and completed clinical hours." }
  ];
  const [form, setForm] = useState({
    eyebrow: "Institutional Offerings",
    title: "Academic Programs",
    intro: "",
    trackEyebrow: "Diploma Track",
    trackTitle: "Specialist Diplomas",
    trackCards: [emptyCard(), emptyCard(), emptyCard(), emptyCard()],
    deliveryEyebrow: "How It's Delivered",
    deliveryTitle: "Three Parts, One Program",
    deliveryCards: [emptyDelivery(), emptyDelivery(), emptyDelivery()],
    pathEyebrow: "Your Path",
    pathTitle: "From First Class to Certified Caregiver",
    pathSteps: defaultPathSteps(),
    pathCtaLabel: "View Tuition & Fees",
    ctaEyebrow: "Ready?",
    ctaTitle: "Apply for a programme",
    ctaBody: "",
    ctaLabel: "Apply Now"
  });
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [msg, setMsg] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const api = await getDb();
        const snap = await api.getDoc(api.doc(api.db, "siteContent", "programsPage"));
        if (snap.exists()) {
          const d = snap.data() || {};
          setForm((f) => ({
            ...f,
            ...d,
            trackCards: Array.isArray(d.trackCards) && d.trackCards.length ? d.trackCards : f.trackCards,
            deliveryCards: Array.isArray(d.deliveryCards) && d.deliveryCards.length ? d.deliveryCards : f.deliveryCards,
            pathSteps: Array.isArray(d.pathSteps) && d.pathSteps.length ? d.pathSteps : f.pathSteps
          }));
        }
      } catch (e) { setErr(e.message || String(e)); }
      setLoading(false);
    })();
  }, []);

  function setCard(listKey, i, patch) {
    setForm((f) => {
      const list = [...(f[listKey] || [])];
      list[i] = { ...(list[i] || {}), ...patch };
      return { ...f, [listKey]: list };
    });
  }
  function setBullet(ci, bi, val) {
    setForm((f) => {
      const list = [...(f.trackCards || [])];
      const card = { ...(list[ci] || emptyCard()) };
      const bullets = Array.isArray(card.bullets) ? [...card.bullets] : ["", "", ""];
      bullets[bi] = val;
      card.bullets = bullets;
      list[ci] = card;
      return { ...f, trackCards: list };
    });
  }
  function addCard(listKey, factory) {
    setForm((f) => ({ ...f, [listKey]: [...(f[listKey] || []), factory()] }));
  }
  function removeCard(listKey, i) {
    setForm((f) => ({ ...f, [listKey]: (f[listKey] || []).filter((_, idx) => idx !== i) }));
  }

  async function save(e) {
    e.preventDefault();
    setMsg(""); setErr("");
    try {
      const api = await getDb();
      const payload = {
        ...form,
        trackCards: (form.trackCards || []).map((c) => ({
          badge: String(c.badge || "").trim(),
          title: String(c.title || "").trim(),
          body: String(c.body || "").trim(),
          bullets: (c.bullets || []).map((b) => String(b || "").trim()).filter(Boolean)
        })).filter((c) => c.title || c.body),
        deliveryCards: (form.deliveryCards || []).map((c) => ({
          label: String(c.label || "").trim(),
          title: String(c.title || "").trim(),
          body: String(c.body || "").trim()
        })).filter((c) => c.title || c.body),
        pathSteps: (form.pathSteps || []).map((s, i) => ({
          num: String(s.num || String(i + 1).padStart(2, "0")).trim(),
          title: String(s.title || "").trim(),
          body: String(s.body || "").trim()
        })).filter((s) => s.title || s.body),
        updatedAt: api.serverTimestamp()
      };
      await api.setDoc(api.doc(api.db, "siteContent", "programsPage"), payload, { merge: true });
      setMsg("Programs page saved. Visitors will see it within about 30 seconds.");
      toast("Programs page saved", "ok");
    } catch (ex) {
      setErr(ex.message || String(ex));
      toast("Save failed", "error");
    }
  }

  if (loading) return html`<${PageSkeleton} />`;
  return html`
    <div>
      <h1>Programs page</h1>
      <p class="muted">Edit the public Programs page: hero, diploma track cards, delivery section, <strong>Your Path</strong> steps, and the bottom apply call-to-action. Add or remove cards as needed.</p>
      ${err ? html`<p class="error">${err}</p>` : null}
      ${msg ? html`<p class="muted">${msg}</p>` : null}
      <form onSubmit=${save}>
        <div class="card">
          <h2 class="card-title">Hero</h2>
          <div class="form-row"><label class="muted">Eyebrow</label><input value=${form.eyebrow || ""} onInput=${(e) => setForm({ ...form, eyebrow: e.target.value })} /></div>
          <div class="form-row"><label class="muted">Title</label><input value=${form.title || ""} onInput=${(e) => setForm({ ...form, title: e.target.value })} /></div>
          <div class="form-row"><label class="muted">Intro</label><textarea rows="3" value=${form.intro || ""} onInput=${(e) => setForm({ ...form, intro: e.target.value })}></textarea></div>
        </div>
        <div class="card">
          <div style=${{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: "0.5rem", flexWrap: "wrap" }}>
            <h2 class="card-title" style=${{ margin: 0 }}>Track section</h2>
            <button type="button" class="ghost" onClick=${() => addCard("trackCards", emptyCard)}>Add card</button>
          </div>
          <div class="form-row"><label class="muted">Section eyebrow</label><input value=${form.trackEyebrow || ""} onInput=${(e) => setForm({ ...form, trackEyebrow: e.target.value })} /></div>
          <div class="form-row"><label class="muted">Section title</label><input value=${form.trackTitle || ""} onInput=${(e) => setForm({ ...form, trackTitle: e.target.value })} /></div>
          ${(form.trackCards || []).map((c, i) => html`
            <div key=${"tc"+i} style=${{ border: "1px solid var(--line)", borderRadius: "12px", padding: "0.75rem", marginBottom: "0.75rem" }}>
              <div style=${{ display: "flex", justifyContent: "space-between", marginBottom: "0.5rem" }}>
                <strong>Card ${i + 1}</strong>
                <button type="button" class="ghost" style=${{ color: "#dc2626" }} onClick=${() => removeCard("trackCards", i)}>Remove</button>
              </div>
              <div class="form-row"><label class="muted">Badge</label><input value=${c.badge || ""} onInput=${(e) => setCard("trackCards", i, { badge: e.target.value })} /></div>
              <div class="form-row"><label class="muted">Title</label><input value=${c.title || ""} onInput=${(e) => setCard("trackCards", i, { title: e.target.value })} /></div>
              <div class="form-row"><label class="muted">Body</label><textarea rows="2" value=${c.body || ""} onInput=${(e) => setCard("trackCards", i, { body: e.target.value })}></textarea></div>
              <div class="form-row"><label class="muted">Bullet 1</label><input value=${(c.bullets && c.bullets[0]) || ""} onInput=${(e) => setBullet(i, 0, e.target.value)} /></div>
              <div class="form-row"><label class="muted">Bullet 2</label><input value=${(c.bullets && c.bullets[1]) || ""} onInput=${(e) => setBullet(i, 1, e.target.value)} /></div>
              <div class="form-row"><label class="muted">Bullet 3</label><input value=${(c.bullets && c.bullets[2]) || ""} onInput=${(e) => setBullet(i, 2, e.target.value)} /></div>
            </div>
          `)}
        </div>
        <div class="card">
          <div style=${{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: "0.5rem", flexWrap: "wrap" }}>
            <h2 class="card-title" style=${{ margin: 0 }}>Delivery section</h2>
            <button type="button" class="ghost" onClick=${() => addCard("deliveryCards", emptyDelivery)}>Add card</button>
          </div>
          <div class="form-row"><label class="muted">Section eyebrow</label><input value=${form.deliveryEyebrow || ""} onInput=${(e) => setForm({ ...form, deliveryEyebrow: e.target.value })} /></div>
          <div class="form-row"><label class="muted">Section title</label><input value=${form.deliveryTitle || ""} onInput=${(e) => setForm({ ...form, deliveryTitle: e.target.value })} /></div>
          ${(form.deliveryCards || []).map((c, i) => html`
            <div key=${"dc"+i} style=${{ border: "1px solid var(--line)", borderRadius: "12px", padding: "0.75rem", marginBottom: "0.75rem" }}>
              <div style=${{ display: "flex", justifyContent: "space-between", marginBottom: "0.5rem" }}>
                <strong>Card ${i + 1}</strong>
                <button type="button" class="ghost" style=${{ color: "#dc2626" }} onClick=${() => removeCard("deliveryCards", i)}>Remove</button>
              </div>
              <div class="form-row"><label class="muted">Label</label><input value=${c.label || ""} onInput=${(e) => setCard("deliveryCards", i, { label: e.target.value })} /></div>
              <div class="form-row"><label class="muted">Title</label><input value=${c.title || ""} onInput=${(e) => setCard("deliveryCards", i, { title: e.target.value })} /></div>
              <div class="form-row"><label class="muted">Body</label><textarea rows="2" value=${c.body || ""} onInput=${(e) => setCard("deliveryCards", i, { body: e.target.value })}></textarea></div>
            </div>
          `)}
        </div>
        <div class="card">
          <div style=${{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "0.75rem" }}>
            <h2 class="card-title" style=${{ margin: 0 }}>Your Path (progression steps)</h2>
            <button type="button" class="ghost" onClick=${() => addCard("pathSteps", emptyPathStep)}>+ Add step</button>
          </div>
          <p class="muted" style=${{ marginBottom: "0.75rem" }}>The numbered list: Certificate → Diploma → Higher Diploma → Licensing, and the “View Tuition” button.</p>
          <div class="form-row"><label class="muted">Section eyebrow</label><input value=${form.pathEyebrow || ""} onInput=${(e) => setForm({ ...form, pathEyebrow: e.target.value })} /></div>
          <div class="form-row"><label class="muted">Section title</label><input value=${form.pathTitle || ""} onInput=${(e) => setForm({ ...form, pathTitle: e.target.value })} /></div>
          ${(form.pathSteps || []).map((s, i) => html`
            <div key=${"ps"+i} style=${{ border: "1px solid var(--line)", borderRadius: "12px", padding: "0.75rem", marginBottom: "0.75rem" }}>
              <div style=${{ display: "flex", justifyContent: "space-between", marginBottom: "0.5rem" }}>
                <strong>Step ${i + 1}</strong>
                <button type="button" class="ghost" style=${{ color: "#dc2626" }} onClick=${() => removeCard("pathSteps", i)}>Remove</button>
              </div>
              <div class="form-row"><label class="muted">Number (e.g. 01)</label><input value=${s.num || ""} onInput=${(e) => setCard("pathSteps", i, { num: e.target.value })} /></div>
              <div class="form-row"><label class="muted">Title</label><input value=${s.title || ""} onInput=${(e) => setCard("pathSteps", i, { title: e.target.value })} /></div>
              <div class="form-row"><label class="muted">Description</label><textarea rows="2" value=${s.body || ""} onInput=${(e) => setCard("pathSteps", i, { body: e.target.value })}></textarea></div>
            </div>
          `)}
          <div class="form-row"><label class="muted">Button under the list</label><input value=${form.pathCtaLabel || ""} onInput=${(e) => setForm({ ...form, pathCtaLabel: e.target.value })} placeholder="View Tuition & Fees" /></div>
        </div>
        <div class="card">
          <h2 class="card-title">Bottom call-to-action</h2>
          <div class="form-row"><label class="muted">Eyebrow</label><input value=${form.ctaEyebrow || ""} onInput=${(e) => setForm({ ...form, ctaEyebrow: e.target.value })} /></div>
          <div class="form-row"><label class="muted">Title</label><input value=${form.ctaTitle || ""} onInput=${(e) => setForm({ ...form, ctaTitle: e.target.value })} /></div>
          <div class="form-row"><label class="muted">Body</label><textarea rows="2" value=${form.ctaBody || ""} onInput=${(e) => setForm({ ...form, ctaBody: e.target.value })}></textarea></div>
          <div class="form-row"><label class="muted">Button label</label><input value=${form.ctaLabel || ""} onInput=${(e) => setForm({ ...form, ctaLabel: e.target.value })} /></div>
        </div>
        <button class="primary" type="submit">Save programs page</button>
      </form>
    </div>
  `;
}


function SimpleSitePageEditor({ docId, title, blurb, fields, lists, cards, toggles }) {
  const empty = {};
  (fields || []).forEach((f) => { empty[f.key] = f.default || ""; });
  (lists || []).forEach((l) => { empty[l.key] = l.default || [""]; });
  (cards || []).forEach((c) => { empty[c.key] = c.default || [{ title: "", body: "" }]; });
  (toggles || []).forEach((tg) => { empty[tg.key] = tg.default !== false; });
  const [form, setForm] = useState(empty);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [msg, setMsg] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const api = await getDb();
        const snap = await api.getDoc(api.doc(api.db, "siteContent", docId));
        if (snap.exists()) {
          const d = snap.data() || {};
          const next = { ...empty };
          (fields || []).forEach((f) => { if (d[f.key] != null) next[f.key] = String(d[f.key]); });
          (lists || []).forEach((l) => {
            if (Array.isArray(d[l.key]) && d[l.key].length) next[l.key] = d[l.key].map(String);
          });
          (cards || []).forEach((c) => {
            if (Array.isArray(d[c.key]) && d[c.key].length) next[c.key] = d[c.key];
          });
          (toggles || []).forEach((tg) => {
            if (d[tg.key] === false) next[tg.key] = false;
            else if (d[tg.key] === true) next[tg.key] = true;
          });
          setForm(next);
        }
      } catch (e) { setErr(e.message || String(e)); }
      setLoading(false);
    })();
  }, [docId]);

  async function save(e) {
    e.preventDefault();
    setErr(""); setMsg("");
    try {
      const api = await getDb();
      const payload = { updatedAt: api.serverTimestamp() };
      (fields || []).forEach((f) => { payload[f.key] = String(form[f.key] || "").trim(); });
      (lists || []).forEach((l) => {
        payload[l.key] = (form[l.key] || []).map((s) => String(s || "").trim()).filter(Boolean);
      });
      (cards || []).forEach((c) => {
        payload[c.key] = (form[c.key] || []).map((row) => {
          const o = {};
          (c.fields || ["title", "body"]).forEach((fk) => { o[fk] = String(row[fk] || "").trim(); });
          return o;
        }).filter((row) => Object.values(row).some(Boolean));
      });
      (toggles || []).forEach((tg) => { payload[tg.key] = form[tg.key] !== false; });
      await api.setDoc(api.doc(api.db, "siteContent", docId), payload, { merge: true });
      setMsg("Saved. Public site updates within about 20 seconds (or on refresh).");
      toast(title + " saved", "ok");
    } catch (ex) {
      setErr(ex.message || String(ex));
      toast("Save failed", "error");
    }
  }

  if (loading) return html`<${PageSkeleton} />`;
  return html`
    <div>
      <h1>${title}</h1>
      <p class="muted">${blurb}</p>
      ${err ? html`<p class="error">${err}</p>` : null}
      ${msg ? html`<p class="muted">${msg}</p>` : null}
      <form onSubmit=${save}>
        ${(fields || []).map((f) => html`
          <div class="form-row" key=${f.key}>
            <label class="muted">${f.label}</label>
            ${f.rows
              ? html`<textarea rows=${f.rows} value=${form[f.key] || ""} onInput=${(e) => setForm({ ...form, [f.key]: e.target.value })}></textarea>`
              : html`<input value=${form[f.key] || ""} onInput=${(e) => setForm({ ...form, [f.key]: e.target.value })} />`}
          </div>
        `)}
        ${(lists || []).map((l) => html`
          <div class="card" key=${l.key} style=${{ marginBottom: "1rem" }}>
            <div style=${{ display: "flex", justifyContent: "space-between", marginBottom: "0.5rem" }}>
              <strong>${l.label}</strong>
              <button type="button" class="ghost" onClick=${() => setForm({ ...form, [l.key]: [...(form[l.key] || []), ""] })}>+ Add</button>
            </div>
            ${(form[l.key] || []).map((val, i) => html`
              <div key=${l.key+i} style=${{ display: "flex", gap: "0.5rem", marginBottom: "0.4rem" }}>
                <textarea rows="2" value=${val} onInput=${(e) => {
                  const arr = [...(form[l.key] || [])];
                  arr[i] = e.target.value;
                  setForm({ ...form, [l.key]: arr });
                }}></textarea>
                <button type="button" class="ghost" onClick=${() => {
                  const arr = [...(form[l.key] || [])];
                  arr.splice(i, 1);
                  setForm({ ...form, [l.key]: arr.length ? arr : [""] });
                }}>Remove</button>
              </div>
            `)}
          </div>
        `)}
        ${(cards || []).map((c) => html`
          <div class="card" key=${c.key} style=${{ marginBottom: "1rem" }}>
            <div style=${{ display: "flex", justifyContent: "space-between", marginBottom: "0.5rem" }}>
              <strong>${c.label}</strong>
              <button type="button" class="ghost" onClick=${() => {
                const blank = {};
                (c.fields || ["title", "body"]).forEach((fk) => { blank[fk] = ""; });
                setForm({ ...form, [c.key]: [...(form[c.key] || []), blank] });
              }}>+ Add</button>
            </div>
            ${(form[c.key] || []).map((row, i) => html`
              <div key=${c.key+i} style=${{ border: "1px solid var(--line)", borderRadius: "12px", padding: "0.75rem", marginBottom: "0.65rem" }}>
                <div style=${{ display: "flex", justifyContent: "space-between", marginBottom: "0.35rem" }}>
                  <span class="muted">Item ${i + 1}</span>
                  <button type="button" class="ghost" style=${{ color: "#dc2626" }} onClick=${() => {
                    const arr = [...(form[c.key] || [])];
                    arr.splice(i, 1);
                    setForm({ ...form, [c.key]: arr });
                  }}>Remove</button>
                </div>
                ${(c.fields || ["title", "body"]).map((fk) => html`
                  <div class="form-row" key=${fk}>
                    <label class="muted">${fk}</label>
                    ${fk === "body"
                      ? html`<textarea rows="2" value=${row[fk] || ""} onInput=${(e) => {
                          const arr = [...(form[c.key] || [])];
                          arr[i] = { ...arr[i], [fk]: e.target.value };
                          setForm({ ...form, [c.key]: arr });
                        }}></textarea>`
                      : html`<input value=${row[fk] || ""} onInput=${(e) => {
                          const arr = [...(form[c.key] || [])];
                          arr[i] = { ...arr[i], [fk]: e.target.value };
                          setForm({ ...form, [c.key]: arr });
                        }} />`}
                  </div>
                `)}
              </div>
            `)}
          </div>
        `)}
        ${(toggles || []).length ? html`<div class="card" style=${{ marginBottom: "1rem" }}>
          <h2 class="card-title">Show on this page</h2>
          <p class="muted" style=${{ marginBottom: "0.75rem" }}>Turn sections on or off without deleting their content — same idea as “Show on home / tuition” for programmes.</p>
          <div style=${{ display: "flex", flexDirection: "column", gap: "0.55rem" }}>
            ${(toggles || []).map((tg) => html`<${Toggle} key=${tg.key} checked=${form[tg.key] !== false} label=${tg.label} onChange=${(v) => setForm({ ...form, [tg.key]: v })} />`)}
          </div>
        </div>` : null}
        <button class="primary" type="submit">Save ${title}</button>
      </form>
    </div>
  `;
}

function HomePageEditor() {
  return html`<${SimpleSitePageEditor}
    docId="homePage"
    title="Home page"
    blurb=${html`Edit every wording block on the public home page. <strong>Programme fee cards</strong> still come from <em>Programmes & prices</em> (use “Show on home page” there). <strong>Partners</strong> names come from Partners; use the toggle below to show/hide that strip. Wall of Fame names come from Wall of Fame — the teaser text is edited here.`}
    fields=${[
      { key: "homeHeroTitle", label: "Hero title", default: "Compassionate care begins with real training.", rows: 2 },
      { key: "homeHeroBody", label: "Hero paragraph", default: "", rows: 3 },
      { key: "homeHeroCta", label: "Hero button label", default: "Apply for Admission" },
      { key: "homeApproachTitle", label: "Approach title", default: "Our Approach to Caregiving Education" },
      { key: "homeApproachBody", label: "Approach body", default: "", rows: 4 },
      { key: "homePracticeLabel", label: "Practice section eyebrow", default: "Why CGTIA" },
      { key: "homePracticeTitle", label: "Practice section title", default: "Built Around Real Practice" },
      { key: "homeEyebrow", label: "Tuition section eyebrow", default: "Tuition Options" },
      { key: "homeHeadline", label: "Tuition section title", default: "Straightforward Program Fees" },
      { key: "homePartnersLabel", label: "Partners eyebrow", default: "Clinical Network" },
      { key: "homePartnersTitle", label: "Partners title", default: "Internship & Placement Partners" },
      { key: "homeInsightsLabel", label: "Insights eyebrow", default: "Caregiver Resources" },
      { key: "homeInsightsTitle", label: "Insights title", default: "Insights & Training Notes" },
      { key: "homeGalleryLabel", label: "Home gallery teaser eyebrow", default: "Gallery" },
      { key: "homeGalleryTitle", label: "Home gallery teaser title", default: "Life at CGTIA" },
      { key: "homeOfferingsLabel", label: "Institutional offerings eyebrow", default: "Institutional Offerings" },
      { key: "homeOfferingsTitle", label: "Institutional offerings title", default: "Academic Programs" },
      { key: "homeVoicesLabel", label: "Graduate voices eyebrow", default: "Graduate Voices" },
      { key: "homeVoicesTitle", label: "Graduate voices title", default: "What graduates and partners say" },
      { key: "homeWallLabel", label: "Wall of Fame teaser eyebrow", default: "Honor Roll" },
      { key: "homeWallTitle", label: "Wall of Fame teaser title", default: "Meet our Wall of Fame" },
      { key: "homeWallBody", label: "Wall of Fame teaser body", default: "The best graduating students from every cohort, celebrated year after year.", rows: 2 }
    ]}
    cards=${[
      { key: "offerings", label: "Institutional offering cards (home carousel)", fields: ["badge", "title", "body"], default: [
        { badge: "Diploma I", title: "Caregiving Fundamentals", body: "" },
        { badge: "Diploma II", title: "Elderly & Dementia Care", body: "" },
        { badge: "Diploma III", title: "Home Health Aide Certification", body: "" },
        { badge: "Diploma IV", title: "Food Hygiene & Nutrition", body: "" }
      ]},
      { key: "testimonials", label: "Graduate voices (quotes)", fields: ["quote", "name", "role"], default: [
        { quote: "", name: "", role: "" }
      ]}
    ]}
    toggles=${[
      { key: "showPractice", label: "Show “Why CGTIA / Built Around Real Practice”", default: true },
      { key: "showTuition", label: "Show tuition / fee block on home", default: true },
      { key: "showPartners", label: "Show partners strip (names from Partners page)", default: true },
      { key: "showInsights", label: "Show Insights & Training Notes", default: true },
      { key: "showGalleryTeaser", label: "Show “Life at CGTIA” gallery teaser", default: true },
      { key: "showOfferings", label: "Show Institutional Offerings carousel", default: true },
      { key: "showVoices", label: "Show Graduate Voices", default: true },
      { key: "showWallTeaser", label: "Show Wall of Fame teaser", default: true }
    ]}
  />`;
}

function AboutPageEditor() {
  return html`<${SimpleSitePageEditor}
    docId="aboutPage"
    title="About page"
    blurb="Edit the public About page: hero, introduction, history steps, goals, and board cards."
    fields=${[
      { key: "aboutEyebrow", label: "Hero eyebrow", default: "About the Academy" },
      { key: "aboutTitle", label: "Hero title", default: "Training caregivers Nigeria can rely on.", rows: 2 },
      { key: "aboutIntro", label: "Hero intro", default: "", rows: 3 },
      { key: "aboutIntroLabel", label: "Introduction label", default: "01 — Introduction" },
      { key: "aboutIntroTitle", label: "Introduction title", default: "Who We Are" },
      { key: "aboutHistoryLabel", label: "History label", default: "02 — History" },
      { key: "aboutHistoryTitle", label: "History title", default: "How CGTIA Came To Be" },
      { key: "aboutGoalsLabel", label: "Goals label", default: "05 — Goals" },
      { key: "aboutGoalsTitle", label: "Goals title", default: "What We're Working Toward" },
      { key: "aboutBoardLabel", label: "Board label", default: "06 — Leadership" },
      { key: "aboutBoardTitle", label: "Board title", default: "Academy Board" },
      { key: "aboutMission", label: "Mission quote", default: "", rows: 3 },
      { key: "aboutVision", label: "Vision quote", default: "", rows: 3 }
    ]}
    lists=${[
      { key: "aboutIntroParas", label: "Introduction paragraphs", default: ["", ""] }
    ]}
    cards=${[
      { key: "historySteps", label: "History steps", fields: ["title", "body"], default: [
        { title: "The Gap", body: "" },
        { title: "The Founding", body: "" },
        { title: "Going Mobile", body: "" },
        { title: "Today", body: "" }
      ]},
      { key: "goals", label: "Goals", fields: ["title", "body"], default: [
        { title: "Raise the Standard of Care", body: "" },
        { title: "Widen Access to Training", body: "" },
        { title: "Grow the Placement Network", body: "" },
        { title: "Build Toward Certification", body: "" }
      ]},
      { key: "board", label: "Board members", fields: ["title", "role", "body"], default: [
        { title: "Board Chair", role: "Governance", body: "" },
        { title: "Academic Director", role: "Curriculum", body: "" },
        { title: "Clinical Placement Lead", role: "Internships", body: "" },
        { title: "Student Affairs", role: "Admissions", body: "" }
      ]}
    ]}
  />`;
}

function GalleryPageEditor() {
  return html`<${SimpleSitePageEditor}
    docId="galleryPage"
    title="Gallery page"
    blurb="Edit the public Gallery page text. Photo grid items are still managed via Media / assets; graduation photos load from the graduates collection."
    fields=${[
      { key: "galleryEyebrow", label: "Hero eyebrow", default: "Life at CGTIA" },
      { key: "galleryTitle", label: "Hero title", default: "Gallery." },
      { key: "galleryIntro", label: "Hero intro", default: "", rows: 3 },
      { key: "galleryGradLabel", label: "Graduation section eyebrow", default: "Graduation" },
      { key: "galleryGradTitle", label: "Graduation section title", default: "Every Graduating Class" },
      { key: "galleryGradBody", label: "Graduation section body", default: "", rows: 2 }
    ]}
  />`;
}


function ContactPageEditor() {
  const empty = {
    formTitle: "Send Us a Message",
    officeHours: [
      { label: "Monday – Friday", time: "8:00 AM – 5:00 PM" },
      { label: "Saturday", time: "9:00 AM – 1:00 PM" },
      { label: "Sunday", time: "Closed" }
    ],
    formIntro: "Prefer to apply instead of just asking a question? Use the Apply button up top and our admissions team will pick it up from there.",
    phones: ["+2349164712004"],
    whatsapps: ["2349164712004"],
    emails: ["admissions@cgtia.org"],
    mapLat: "5.485",
    mapLng: "7.035",
    faqs: [
      { q: "How long is the certificate programme?", a: "Contact the academy for current programme lengths and intake dates." },
      { q: "Do I need prior experience?", a: "No prior caregiving experience is required for entry-level tracks." }
    ]
  };
  const [form, setForm] = useState(empty);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [msg, setMsg] = useState("");

  async function load() {
    setLoading(true);
    setErr("");
    try {
      const api = await getDb();
      const snap = await api.getDoc(api.doc(api.db, "siteContent", "contactPage"));
      const data = snap && (typeof snap.data === "function" ? snap.data() : null);
      if (data) {
        setForm({
          formTitle: data.formTitle || empty.formTitle,
          officeHours: Array.isArray(data.officeHours) && data.officeHours.length ? data.officeHours : empty.officeHours,
          formIntro: data.formIntro || empty.formIntro,
          phones: Array.isArray(data.phones) && data.phones.length ? data.phones : empty.phones,
          whatsapps: Array.isArray(data.whatsapps) && data.whatsapps.length ? data.whatsapps : empty.whatsapps,
          emails: Array.isArray(data.emails) && data.emails.length ? data.emails : empty.emails,
          mapLat: data.mapLat != null ? String(data.mapLat) : empty.mapLat,
          mapLng: data.mapLng != null ? String(data.mapLng) : empty.mapLng,
          faqs: Array.isArray(data.faqs) && data.faqs.length ? data.faqs.map((f) => ({ q: f.q || f.question || "", a: f.a || f.answer || "" })) : empty.faqs
        });
        setMsg("Loaded");
      } else {
        setMsg("No saved contact page yet — defaults shown. Save to publish.");
      }
    } catch (e) {
      setErr(e.message || String(e));
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { load(); }, []);

  function setList(key, idx, value) {
    setForm((prev) => {
      const arr = [...(prev[key] || [])];
      arr[idx] = value;
      return { ...prev, [key]: arr };
    });
  }
  function addList(key) {
    setForm((prev) => ({ ...prev, [key]: [...(prev[key] || []), ""] }));
  }
  function removeList(key, idx) {
    setForm((prev) => {
      const arr = [...(prev[key] || [])];
      arr.splice(idx, 1);
      return { ...prev, [key]: arr.length ? arr : [""] };
    });
  }
  function setFaq(idx, field, value) {
    setForm((prev) => {
      const faqs = prev.faqs.map((f, i) => i === idx ? { ...f, [field]: value } : f);
      return { ...prev, faqs };
    });
  }
  function addFaq() {
    setForm((prev) => ({ ...prev, faqs: [...(prev.faqs || []), { q: "", a: "" }] }));
  }
  function removeFaq(idx) {
    setForm((prev) => {
      const faqs = [...(prev.faqs || [])];
      faqs.splice(idx, 1);
      return { ...prev, faqs: faqs.length ? faqs : [{ q: "", a: "" }] };
    });
  }

  async function save(e) {
    e.preventDefault();
    setErr("");
    try {
      const api = await getDb();
      const payload = {
        formTitle: String(form.formTitle || "").trim(),
        officeHours: (form.officeHours || []).map((h) => ({ label: String(h.label || "").trim(), time: String(h.time || "").trim() })).filter((h) => h.label || h.time),
        formIntro: String(form.formIntro || "").trim(),
        phones: (form.phones || []).map((s) => String(s).trim()).filter(Boolean),
        whatsapps: (form.whatsapps || []).map((s) => String(s).trim()).filter(Boolean),
        emails: (form.emails || []).map((s) => String(s).trim()).filter(Boolean),
        mapLat: String(form.mapLat || "").trim(),
        mapLng: String(form.mapLng || "").trim(),
        faqs: (form.faqs || []).map((f) => ({ q: String(f.q || "").trim(), a: String(f.a || "").trim() })).filter((f) => f.q || f.a),
        updatedAt: api.serverTimestamp()
      };
      await api.setDoc(api.doc(api.db, "siteContent", "contactPage"), payload, { merge: true });
      toast("Contact page saved — live site will use this");
      setMsg("Saved");
    } catch (ex) {
      setErr(ex.message || String(ex));
      toast(ex.message || "Save failed", "error");
    }
  }

  function listEditor(label, key, placeholder) {
    return html`
      <div class="card" style=${{ marginBottom: "1rem" }}>
        <p class="muted" style=${{ marginBottom: "0.5rem" }}>${label}</p>
        ${(form[key] || []).map((val, idx) => html`
          <div key=${key + "-" + idx} style=${{ display: "flex", gap: "0.5rem", marginBottom: "0.4rem" }}>
            <input value=${val} placeholder=${placeholder} onInput=${(e) => setList(key, idx, e.target.value)} />
            <button type="button" class="ghost" onClick=${() => removeList(key, idx)}>Remove</button>
          </div>
        `)}
        <button type="button" class="ghost" onClick=${() => addList(key)}>+ Add</button>
      </div>
    `;
  }

  return html`
    <div>
      <h1>Contact page</h1>
      <p class="muted">Edit everything shown on the public Contact page: phones (opens dialer), WhatsApp numbers, emails, FAQs, and map pin. Saved to the website <code>siteContent/contactPage</code>.</p>
      ${loading ? html`<${Skeleton} rows=${4} />` : null}
      ${err ? html`<p class="error">${err}</p>` : null}
      ${msg ? html`<p class="muted">${msg}</p>` : null}
      <form onSubmit=${save}>
        <div class="card" style=${{ marginBottom: "1rem" }}>
          <p class="muted" style=${{ marginBottom: "0.5rem" }}>Office hours (shown next to the contact form)</p>
          ${(form.officeHours || []).map((h, i) => html`
            <div key=${"oh-" + i} style=${{ display: "grid", gridTemplateColumns: "1fr 1fr auto", gap: "0.5rem", marginBottom: "0.4rem" }}>
              <input placeholder="Days (e.g. Monday – Friday)" value=${h.label} onInput=${(e) => setForm({ ...form, officeHours: form.officeHours.map((x, j) => (j === i ? { ...x, label: e.target.value } : x)) })} />
              <input placeholder="Hours (e.g. 8:00 AM – 5:00 PM)" value=${h.time} onInput=${(e) => setForm({ ...form, officeHours: form.officeHours.map((x, j) => (j === i ? { ...x, time: e.target.value } : x)) })} />
              <button type="button" class="ghost" onClick=${() => setForm({ ...form, officeHours: form.officeHours.filter((_, j) => j !== i) })}>Remove</button>
            </div>
          `)}
          <button type="button" class="ghost" onClick=${() => setForm({ ...form, officeHours: [...(form.officeHours || []), { label: "", time: "" }] })}>+ Add a row</button>
        </div>
        <div class="card" style=${{ marginBottom: "1rem" }}>
          <p class="muted" style=${{ marginBottom: "0.5rem" }}>Contact form wording</p>
          <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Heading</label>
          <input value=${form.formTitle || ""} onInput=${(e) => setForm({ ...form, formTitle: e.target.value })} />
          <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Short note under the heading</label>
          <textarea rows="3" value=${form.formIntro || ""} onInput=${(e) => setForm({ ...form, formIntro: e.target.value })}></textarea>
        </div>
        ${listEditor("Call numbers (tel: — use +234…)", "phones", "+2349164712004")}
        ${listEditor("WhatsApp numbers (digits or +234…)", "whatsapps", "2349164712004")}
        ${listEditor("Emails", "emails", "admissions@cgtia.org")}

        <div class="card" style=${{ marginBottom: "1rem" }}>
          <p class="muted" style=${{ marginBottom: "0.5rem" }}>Map coordinates</p>
          <div style=${{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.5rem" }}>
            <div>
              <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Latitude</label>
              <input value=${form.mapLat} onInput=${(e) => setForm({ ...form, mapLat: e.target.value })} placeholder="5.485" />
            </div>
            <div>
              <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Longitude</label>
              <input value=${form.mapLng} onInput=${(e) => setForm({ ...form, mapLng: e.target.value })} placeholder="7.035" />
            </div>
          </div>
        </div>

        <div class="card" style=${{ marginBottom: "1rem" }}>
          <p class="muted" style=${{ marginBottom: "0.5rem" }}>Frequently asked questions</p>
          ${(form.faqs || []).map((f, idx) => html`
            <div key=${"faq-" + idx} style=${{ borderTop: "1px solid #243044", paddingTop: "0.75rem", marginTop: "0.75rem" }}>
              <div class="form-row">
                <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Question</label>
                <input value=${f.q} onInput=${(e) => setFaq(idx, "q", e.target.value)} />
              </div>
              <div class="form-row">
                <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Answer</label>
                <textarea rows="3" value=${f.a} onInput=${(e) => setFaq(idx, "a", e.target.value)} />
              </div>
              <button type="button" class="ghost" style=${{ color: "#dc2626" }} onClick=${() => removeFaq(idx)}>Remove FAQ</button>
            </div>
          `)}
          <button type="button" class="ghost" style=${{ marginTop: "0.75rem" }} onClick=${addFaq}>+ Add FAQ</button>
        </div>

        <button class="primary" type="submit">Save contact page</button>
        <button class="ghost" type="button" onClick=${load}>Reload</button>
      </form>
    </div>
  `;
}


function ContactPanel() {
  const [rows, setRows] = useState([]);
  const [err, setErr] = useState("");
  const [msgTab, setMsgTab] = useState("new");
  const [openId, setOpenId] = useState("");
  async function load() {
    try {
      const api = await getDb();
      const snap = await api.getDocs(api.collection(api.db, "contactMessages"));
      const list = [];
      snap.forEach((d) => list.push({ id: d.id, ...d.data() }));
      list.sort((a, b) => {
        const ta = a.createdAt?.seconds || a.createdAt?._seconds || 0;
        const tb = b.createdAt?.seconds || b.createdAt?._seconds || 0;
        return tb - ta;
      });
      setRows(list);
    } catch (e) {
      setErr(e.message || String(e));
    }
  }
  useEffect(() => { load(); }, []);
  function isNew(r) {
    const s = String(r.status || "new").toLowerCase();
    return s === "new" || s === "unread" || s === "open" || s === "" || s === "pending";
  }
  function isReplied(r) {
    const s = String(r.status || "").toLowerCase();
    return s === "replied" || s === "answered" || s === "closed" || s === "done";
  }
  async function setMsgStatus(row, status) {
    try {
      const api = await getDb();
      await api.setDoc(api.doc(api.db, "contactMessages", row.id), { status, updatedAt: api.serverTimestamp() }, { merge: true });
      toast("Marked " + status);
      load();
    } catch (e) {
      toast(e.message || "Update failed", "error");
    }
  }
  const shown = rows.filter((r) => {
    if (msgTab === "new") return isNew(r);
    if (msgTab === "replied") return isReplied(r);
    return true;
  });
  return html`
    <div>
      <h1>Messages</h1>
      <p class="sub">General contact form messages from the public site (not licensing).</p>
      ${err ? html`<p class="error">${err}</p>` : null}
      <${SubTabs}
        tabs=${[
          { id: "new", label: "New (" + rows.filter(isNew).length + ")" },
          { id: "replied", label: "Replied (" + rows.filter(isReplied).length + ")" },
          { id: "all", label: "All (" + rows.length + ")" }
        ]}
        active=${msgTab}
        onChange=${setMsgTab}
        menu=${null} />
      <div class="table-wrap">
        <table>
          <thead><tr><th>Contact</th><th>Topic</th><th>Message</th><th>Status</th><th></th></tr></thead>
          <tbody>
            ${shown.length === 0 ? html`<tr><td colspan="5" class="muted">Nothing in this tab.</td></tr>` : null}
            ${shown.map((r) => html`
              <tr key=${r.id}>
                <td>${r.contactValue || r.email || r.name || "—"}</td>
                <td>${r.faqTopic || r.subject || "—"}</td>
                <td class="muted" style=${{ maxWidth: "220px" }}>${(r.message || "").slice(0, 100)}${(r.message || "").length > 100 ? "…" : ""}</td>
                <td><${Badge} status=${r.status || "new"} /></td>
                <td style=${{ whiteSpace: "nowrap" }}>
                  <button class="ghost" type="button" onClick=${() => setOpenId(openId === r.id ? "" : r.id)}>${openId === r.id ? "Hide" : "Open"}</button>
                  ${isNew(r) ? html`<button class="ghost" type="button" onClick=${() => setMsgStatus(r, "replied")}>Mark replied</button>` : html`<button class="ghost" type="button" onClick=${() => setMsgStatus(r, "new")}>Mark new</button>`}
                </td>
              </tr>
            `)}
          </tbody>
        </table>
      </div>
      ${rows.filter((r) => r.id === openId).map((r) => html`
        <div class="card" style=${{ marginTop: "1rem" }} key=${"open-" + r.id}>
          <h3 style=${{ marginBottom: "0.5rem" }}>${r.name || r.contactValue || r.email || r.id}</h3>
          <p class="muted" style=${{ margin: "0 0 0.5rem", fontSize: "0.8rem" }}>${r.email || r.contactValue || ""} · ${r.faqTopic || r.subject || "—"}</p>
          <div style=${{ whiteSpace: "pre-wrap", lineHeight: 1.5 }}>${r.message || "—"}</div>
          <div style=${{ marginTop: "0.75rem", display: "flex", gap: "0.5rem" }}>
            ${isNew(r) ? html`<button class="primary" type="button" onClick=${() => setMsgStatus(r, "replied")}>Mark as replied</button>` : html`<button class="ghost" type="button" onClick=${() => setMsgStatus(r, "new")}>Mark as new</button>`}
          </div>
        </div>
      `)}
    </div>
  `;
}

const PROGRAM_SEEDS = [
    {
      id: "orientation",
      name: "Orientation",
      headline: "Orientation",
      subtitle: "Free intro session",
      amount: 0,
      priceNote: "Free session",
      levelLabel: "INTRO",
      badge: "INTRO",
      feature1: "Academy Overview",
      feature2: "Program Walkthrough",
      feature3: "Clinical Practice Access",
      feature4: "",
      ctaLabel: "Reserve a Seat",
      ctaAction: "apply",
      ribbon: "",
      showOnHome: true,
      showOnTuition: true,
      active: true,
      sortOrder: 0,
      startDate: "To be announced",
      modality: "Online and in person"
    },
    {
      id: "certificate",
      name: "CGTIA Certificate",
      headline: "Certificate",
      subtitle: "Beginners training + Clinical placement",
      amount: 300000,
      priceNote: "/ FULL PROGRAMME",
      levelLabel: "CORE",
      badge: "CORE",
      feature1: "Full Caregiving Curriculum",
      feature2: "16 Course Modules",
      feature3: "Guided Clinical Placement",
      feature4: "CGTIA Certificate",
      ctaLabel: "Apply for This Program",
      ctaAction: "apply",
      ribbon: "Most Popular",
      showOnHome: true,
      showOnTuition: true,
      active: true,
      sortOrder: 1,
      startDate: "To be announced",
      modality: "Online and in person"
    },
    {
      id: "diploma",
      name: "CGTIA Diploma",
      headline: "Diploma",
      subtitle: "Advanced + Nanny training",
      amount: 350000,
      priceNote: "/ ADVANCED PATHWAY",
      levelLabel: "LEVEL 2",
      badge: "LEVEL 2",
      feature1: "Level 1 Certification",
      feature2: "12 Course Modules",
      feature3: "Nanny Training",
      feature4: "",
      ctaLabel: "Apply for This Program",
      ctaAction: "apply",
      ribbon: "",
      showOnHome: true,
      showOnTuition: true,
      active: true,
      sortOrder: 2,
      startDate: "To be announced",
      modality: "Online and in person"
    },
    {
      id: "higher-diploma",
      name: "CGTIA Higher Diploma",
      headline: "Higher Diploma",
      subtitle: "Leadership pathway",
      amount: 400000,
      priceNote: "/ AGENCY FOCUSED",
      levelLabel: "LEVEL 3",
      badge: "LEVEL 3",
      feature1: "On-Site Staff Training",
      feature2: "Bulk Enrolment Pricing",
      feature3: "Dedicated Program Coordinator",
      feature4: "",
      ctaLabel: "Apply for This Program",
      ctaAction: "apply",
      ribbon: "",
      showOnHome: true,
      showOnTuition: true,
      active: true,
      sortOrder: 3,
      startDate: "To be announced",
      modality: "Online and in person"
    },
    {
      id: "licensing",
      name: "Licensing",
      headline: "Licensing",
      subtitle: "For qualified individuals",
      amount: 150000,
      priceNote: "Requirements apply",
      levelLabel: "LICENSE",
      badge: "LICENSE",
      feature1: "Prior basic caregiver training",
      feature2: "Lifesaving certification",
      feature3: "72 hours clinical placement",
      feature4: "",
      ctaLabel: "Apply for Licensing",
      ctaAction: "licensing",
      ribbon: "",
      showOnHome: true,
      showOnTuition: true,
      active: true,
      sortOrder: 4,
      startDate: "To be announced",
      modality: "As scheduled"
    },
    {
      id: "institutional",
      name: "Institutional Training",
      headline: "Institutional Training",
      subtitle: "For care homes & clinics",
      amount: 0,
      priceNote: "Custom quote",
      levelLabel: "CUSTOM",
      badge: "CUSTOM",
      feature1: "On-Site Staff Training",
      feature2: "Bulk Enrolment Pricing",
      feature3: "Dedicated Coordinator",
      feature4: "",
      ctaLabel: "Contact Admissions",
      ctaAction: "apply",
      ribbon: "",
      showOnHome: true,
      showOnTuition: true,
      active: true,
      sortOrder: 5,
      startDate: "To be announced",
      modality: "As scheduled"
    }
  ];

const PRICE_HINT = "Type a number (e.g. 100000) to show ₦100,000, or type words such as Free or Custom.";

function parsePrice(raw) {
  const t = String(raw || "").trim();
  if (!t) return { amount: 0, priceText: "Free" };
  const digits = t.replace(/[₦,\s]/g, "");
  if (/^\d+(\.\d+)?$/.test(digits)) return { amount: Number(digits), priceText: "" };
  return { amount: 0, priceText: t };
}
function priceToInput(p) {
  if (p.priceText) return p.priceText;
  if (Number(p.amount) > 0) return String(Number(p.amount));
  return "Free";
}
function priceLabel(p) {
  if (p.priceText) return p.priceText;
  if (Number(p.amount) > 0) return "₦" + Number(p.amount).toLocaleString("en-NG");
  return "Free";
}
function newProgramId(name) {
  const slug = String(name || "programme").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 30) || "programme";
  return slug + "-" + Math.random().toString(36).slice(2, 6);
}

function ProgramsPanel() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(null);
  const [isNew, setIsNew] = useState(false);
  const [err, setErr] = useState("");
  const [progTab, setProgTab] = useState("list");

  async function load() {
    setLoading(true);
    try {
      const api = await getDb();
      const snap = await api.getDocs(api.collection(api.db, "programs"));
      const list = [];
      snap.forEach((d) => { if (d.data().trashed !== true) list.push({ id: d.id, ...d.data() }); });
      list.sort((a, b) => (Number(a.sortOrder) || 0) - (Number(b.sortOrder) || 0));
      setRows(list);
      setErr("");
    } catch (e) {
      setErr(e.message || String(e));
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { load(); }, []);

  async function loadStandardSix() {
    try {
      const api = await getDb();
      for (let i = 0; i < PROGRAM_SEEDS.length; i++) {
        const s = PROGRAM_SEEDS[i];
        await api.setDoc(api.doc(api.db, "programs", s.id), { ...s, sortOrder: i + 1, updatedAt: api.serverTimestamp() }, { merge: true });
      }
      toast("Standard programmes added", "ok");
      load();
    } catch (ex) {
      setErr(ex.message || String(ex));
    }
  }

  function openNew() {
    setIsNew(true);
    setProgTab("edit");
    setForm({ id: "", headline: "", subtitle: "", body: "", priceInput: "Free", priceNote: "", badge: "", ribbon: "", ctaLabel: "Apply for This Program", ctaAction: "apply", features: [], startDate: "To be announced", modality: "Online and in person", showOnHome: true, showOnTuition: true, active: true });
  }
  function openEdit(row) {
    setIsNew(false);
    setProgTab("edit");
    setForm({
      ...row,
      active: row.active !== false,
      showOnHome: row.showOnHome !== false,
      showOnTuition: row.showOnTuition !== false,
      priceInput: priceToInput(row),
      features: Array.isArray(row.features) ? row.features : [row.feature1, row.feature2, row.feature3, row.feature4].filter(Boolean)
    });
  }
  function closeForm() { setForm(null); setIsNew(false); setProgTab("list"); }

  async function save(e) {
    e.preventDefault();
    setErr("");
    if (!String(form.headline || "").trim()) { toast("Give the card a title", "error"); return; }
    const price = parsePrice(form.priceInput);
    const data = {
      name: form.headline.trim(),
      headline: form.headline.trim(),
      subtitle: String(form.subtitle || "").trim(),
      body: String(form.body || "").trim(),
      amount: price.amount,
      priceText: price.priceText,
      priceNote: String(form.priceNote || "").trim(),
      badge: String(form.badge || "").trim(),
      levelLabel: String(form.badge || "").trim(),
      ribbon: String(form.ribbon || "").trim(),
      ctaLabel: String(form.ctaLabel || "").trim() || "Apply for This Program",
      ctaAction: form.ctaAction || "apply",
      ctaAction: form.ctaAction || "apply",
      features: (form.features || []).map((x) => String(x || "").trim()).filter(Boolean),
      startDate: String(form.startDate || "").trim() || "To be announced",
      modality: String(form.modality || "").trim() || "Online and in person",
      showOnHome: form.showOnHome !== false,
      showOnTuition: form.showOnTuition !== false,
      active: form.active !== false
    };
    // Force real booleans into Firestore (never leave undefined)
    data.showOnHome = data.showOnHome === true;
    data.showOnTuition = data.showOnTuition === true;
    data.active = data.active === true;
    try {
      const api = await getDb();
      if (isNew) {
        const id = newProgramId(form.headline);
        const sortOrder = rows.reduce((m, r) => Math.max(m, Number(r.sortOrder) || 0), 0) + 1;
        await api.setDoc(api.doc(api.db, "programs", id), { ...data, sortOrder, createdAt: api.serverTimestamp(), updatedAt: api.serverTimestamp() }, { merge: true });
      } else {
        await api.setDoc(api.doc(api.db, "programs", form.id), { ...data, updatedAt: api.serverTimestamp() }, { merge: true });
      }
      toast("Programme saved", "ok");
      setProgTab("list");
      closeForm();
      load();
    } catch (ex) {
      setErr(ex.message || String(ex));
      toast("Save failed", "error");
    }
  }

  async function move(index, dir) {
    const j = index + dir;
    if (j < 0 || j >= rows.length) return;
    const next = rows.slice();
    [next[index], next[j]] = [next[j], next[index]];
    setRows(next);
    try {
      const api = await getDb();
      await Promise.all(next.map((r, i) => api.setDoc(api.doc(api.db, "programs", r.id), { sortOrder: i + 1 }, { merge: true })));
      toast("Order saved", "ok");
    } catch (ex) {
      toast("Could not save the order", "error");
      load();
    }
  }

  async function toggleProgramActive(row) {
    try {
      const api = await getDb();
      const currentlyOn = row.active !== false;
      const next = !currentlyOn;
      await api.setDoc(api.doc(api.db, "programs", row.id), {
        active: next,
        updatedAt: api.serverTimestamp()
      }, { merge: true });
      toast(next ? "Programme is live" : "Programme deactivated — hidden on the public site");
      load();
    } catch (ex) {
      toast(ex.message || "Could not update", "error");
    }
  }

  async function remove(id) {
    if (!(await askConfirm("Move this programme to Trash?"))) return;
    try {
      await moveToTrash("programs", id);
      toast("Moved to Trash", "ok");
      closeForm();
      load();
    } catch (ex) {
      toast(ex.message || "Failed", "error");
    }
  }

  const f = form || {};
  const set = (k, v) => setForm({ ...form, [k]: v });
  const feats = f.features || [];

  return html`
    <div>
      <h1>Programmes & prices</h1>
      <p class="muted">These cards appear on the Tuition page and the home page, in the order shown here. Use ↑ and ↓ to reorder.</p>
      <${SubTabs}
        tabs=${[{ id: "list", label: "Records" }, { id: "edit", label: "Edit" }]}
        active=${progTab}
        onChange=${(id) => {
          if (id === "list") setProgTab("list");
          else {
            setProgTab("edit");
            if (!form) openNew();
          }
        }}
      />
      ${err ? html`<p class="error">${err}</p>` : null}
      ${progTab === "list" ? html`
        <div style=${{ display: "flex", gap: "0.5rem", flexWrap: "wrap", marginBottom: "0.75rem" }}>
          ${!loading && rows.length === 0 ? html`<button class="ghost" type="button" onClick=${loadStandardSix}>Add the standard six</button>` : null}
          <button class="primary" type="button" onClick=${openNew}>+ New programme</button>
        </div>
        ${loading ? html`<${Skeleton} rows=${4} />` : null}
        ${!loading && rows.length === 0 ? html`<p class="muted">No programmes yet. Click "+ New programme" to add one.</p>` : null}
        ${rows.map((r, i) => html`
          <div class="card" key=${r.id} style=${{ marginBottom: "0.5rem", display: "flex", alignItems: "center", gap: "0.75rem", flexWrap: "wrap" }}>
            <span style=${{ fontWeight: 700, width: "2rem", color: "#64748b" }}>${i + 1}</span>
            <div style=${{ flex: 1, minWidth: "12rem" }}>
              <strong>${r.headline || r.name || r.id}</strong>
              <div class="muted" style=${{ fontSize: "0.8rem" }}>${r.subtitle || ""}</div>
            </div>
            <div style=${{ minWidth: "8rem", fontWeight: 600 }}>${priceLabel(r)}</div>
            <div class="muted" style=${{ fontSize: "0.8rem", minWidth: "8rem" }}>
              ${r.showOnHome !== false ? "Home " : ""}${r.showOnTuition !== false ? "Tuition " : ""}
              <${Badge} status=${r.active === false ? "inactive" : "active"} />
            </div>
            <div class="row-actions">
              <button class="ghost" type="button" disabled=${i === 0} onClick=${() => move(i, -1)}>↑</button>
              <button class="ghost" type="button" disabled=${i === rows.length - 1} onClick=${() => move(i, 1)}>↓</button>
              <button class="ghost" type="button" onClick=${() => openEdit(r)}>Edit</button>
              <button class="ghost" type="button" onClick=${() => toggleProgramActive(r)}>${r.active === false ? "Activate" : "Deactivate"}</button>
            </div>
          </div>
        `)}
      ` : null}
      ${progTab === "edit" && form ? html`
        <form class="card" onSubmit=${save} style=${{ marginTop: "0.5rem" }}>
          <h3 style=${{ marginBottom: "0.75rem" }}>${isNew ? "New programme" : "Edit: " + (f.headline || f.id)}</h3>
          <div class="form-row"><label class="muted">Title</label><input value=${f.headline || ""} onInput=${(e) => set("headline", e.target.value)} /></div>
          <div class="form-row"><label class="muted">Subtitle (under the title)</label><input value=${f.subtitle || ""} onInput=${(e) => set("subtitle", e.target.value)} /></div>
          <div class="form-row"><label class="muted">Write-up (paragraph on the card)</label><textarea rows="3" value=${f.body || ""} onInput=${(e) => set("body", e.target.value)}></textarea></div>
          <div class="form-row"><label class="muted">Price</label><input value=${f.priceInput || ""} onInput=${(e) => set("priceInput", e.target.value)} /><div class="muted" style=${{ fontSize: "0.75rem" }}>${PRICE_HINT}</div></div>
          <div class="form-row"><label class="muted">Under the price (e.g. / full programme)</label><input value=${f.priceNote || ""} onInput=${(e) => set("priceNote", e.target.value)} /></div>
          <div class="form-row"><label class="muted">Level label (e.g. CORE)</label><input value=${f.badge || ""} onInput=${(e) => set("badge", e.target.value)} /></div>
          <div class="form-row"><label class="muted">Ribbon (e.g. Most Popular — blank for none)</label><input value=${f.ribbon || ""} onInput=${(e) => set("ribbon", e.target.value)} /></div>
          <div class="form-row"><label class="muted">Points on the card</label>
            ${feats.map((v, i) => html`
              <div key=${"ft-" + i} style=${{ display: "flex", gap: "0.5rem", marginBottom: "0.4rem" }}>
                <input value=${v} onInput=${(e) => set("features", feats.map((x, j) => (j === i ? e.target.value : x)))} />
                <button type="button" class="ghost" onClick=${() => set("features", feats.filter((_, j) => j !== i))}>Remove</button>
              </div>`)}
            <button type="button" class="ghost" onClick=${() => set("features", [...feats, ""])}>+ Add a point</button>
          </div>
          <div class="form-row"><label class="muted">Button text</label><input value=${f.ctaLabel || ""} onInput=${(e) => set("ctaLabel", e.target.value)} /></div>
          <div class="form-row"><label class="muted">What the button does</label>
            <select value=${f.ctaAction || "apply"} onChange=${(e) => set("ctaAction", e.target.value)}>
              <option value="apply">Opens the application form</option>
              <option value="licensing">Opens the licensing page</option>
              <option value="pay">Takes payment for this card (uses the price above)</option>
            </select>
          </div>
          <div class="form-row"><label class="muted">Start date</label><input value=${f.startDate || ""} placeholder="e.g. 15 January 2027" onInput=${(e) => set("startDate", e.target.value)} /></div>
          <div class="form-row"><label class="muted">Modality</label><input value=${f.modality || ""} onInput=${(e) => set("modality", e.target.value)} /></div>
          <div style=${{ display: "flex", flexDirection: "column", gap: "0.55rem", margin: "0.75rem 0" }}>
            <${Toggle} checked=${!!f.showOnHome} label="Show on home page" onChange=${(v) => set("showOnHome", v)} />
            <${Toggle} checked=${!!f.showOnTuition} label="Show on Tuition page" onChange=${(v) => set("showOnTuition", v)} />
            <${Toggle} checked=${f.active !== false} label="Live" onChange=${(v) => set("active", v)} />
          </div>
          <div style=${{ display: "flex", gap: "0.5rem", flexWrap: "wrap" }}>
            <button class="primary" type="submit">Save programme</button>
            <button class="ghost" type="button" onClick=${closeForm}>Cancel</button>
            ${!isNew ? html`<button class="ghost" type="button" style=${{ color: "#dc2626" }} onClick=${() => remove(f.id)}>Move to Trash</button>` : null}
          </div>
        </form>
      ` : null}
    </div>
  `;
}


function SimpleCrud({ title, collection, fields, pathHint }) {
  const [rows, setRows] = useState([]);
  const [form, setForm] = useState(() => Object.fromEntries(fields.map((f) => [f, ""])));
  const [editId, setEditId] = useState(null);
  const [err, setErr] = useState("");
  const [crudTab, setCrudTab] = useState("list");
  async function load() {
    try {
      const api = await getDb();
      const snap = await api.getDocs(api.collection(api.db, collection));
      const list = [];
      snap.forEach((d) => list.push({ id: d.id, ...d.data() }));
      setRows(list);
    } catch (e) {
      setErr(e.message || String(e));
    }
  }
  useEffect(() => { load(); }, []);
  function openNew() {
    setEditId(null);
    setForm(Object.fromEntries(fields.map((f) => [f, ""])));
    setCrudTab("edit");
  }
  function openEdit(row) {
    setEditId(row.id);
    const next = {};
    fields.forEach((f) => { next[f] = row[f] != null ? String(row[f]) : ""; });
    setForm(next);
    setCrudTab("edit");
  }
  function cancelEdit() {
    setEditId(null);
    setForm(Object.fromEntries(fields.map((f) => [f, ""])));
    setCrudTab("list");
  }
  async function save(e) {
    e.preventDefault();
    try {
      const api = await getDb();
      const id = editId || ((form.studentName || form.name || "item").toLowerCase().replace(/[^a-z0-9]+/g, "-") + "-" + Date.now().toString(36));
      await api.setDoc(api.doc(api.db, collection, id), { ...form, updatedAt: api.serverTimestamp() }, { merge: true });
      cancelEdit();
      load();
      toast(editId ? "Updated" : "Saved");
    } catch (ex) {
      setErr(ex.message || String(ex));
      toast(ex.message || "Save failed", "error");
    }
  }
  async function remove(id) {
    if (!(await askConfirm("Delete this item permanently?"))) return;
    try {
      const api = await getDb();
      await api.deleteDoc(api.doc(api.db, collection, id));
      toast("Deleted", "ok");
      if (editId === id) cancelEdit();
      load();
    } catch (ex) {
      toast(ex.message || "Delete failed", "error");
    }
  }
  const placeholders = {
    photoUrl: "graduates/2025/A/name.webp  (base: cgtia-assets.netlify.app)",
    studentName: "Full name",
    program: "certificate | diploma | higher-diploma",
    year: "2025",
    rank: "1",
    quote: "Optional quote",
    activity: "What they are doing now"
  };
  return html`
    <div>
      <h1>${title}</h1>
      ${pathHint ? html`<p class="muted" style=${{ marginBottom: "0.75rem" }}>${pathHint}</p>` : null}
      ${err ? html`<p class="error">${err}</p>` : null}
      <${SubTabs}
        tabs=${[{ id: "list", label: "Records" }, { id: "edit", label: editId ? "Edit" : "Add" }]}
        active=${crudTab}
        onChange=${(id) => {
          if (id === "list") cancelEdit();
          else openNew();
        }}
      />
      ${crudTab === "edit" ? html`
      <form class="card" onSubmit=${save} style=${{ marginBottom: "1rem" }}>
        <p class="muted" style=${{ marginBottom: "0.5rem" }}>${editId ? "Editing: " + editId : "Add new"}</p>
        ${fields.map((f) => html`<div class="form-row" key=${f}><label style=${{ fontSize: "0.75rem", color: "#64748b" }}>${f}</label><input placeholder=${placeholders[f] || f} value=${form[f] || ""} onInput=${(e) => setForm({ ...form, [f]: e.target.value })} /></div>`)}
        <div style=${{ display: "flex", gap: "0.5rem" }}>
          <button class="primary" type="submit">${editId ? "Update" : "Save"}</button>
          <button type="button" class="ghost" onClick=${cancelEdit}>Cancel</button>
        </div>
      </form>
      ` : html`
      <div style=${{ marginBottom: "0.75rem" }}>
        <button class="primary" type="button" onClick=${openNew}>+ Add new</button>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr>${fields.map((f) => html`<th key=${f}>${f}</th>`)}<th></th></tr></thead>
          <tbody>
            ${rows.map((r) => html`
              <tr key=${r.id}>
                ${fields.map((f) => html`<td key=${f}>${f === "photoUrl" && r[f] ? html`<a href=${r[f]} target="_blank" rel="noopener">${String(r[f]).slice(0, 40)}</a>` : (r[f] || "—")}</td>`)}
                <td style=${{ whiteSpace: "nowrap" }}>
                  <button class="ghost" onClick=${() => openEdit(r)}>Edit</button>
                  <button class="ghost" onClick=${() => remove(r.id)}>Delete</button>
                </td>
              </tr>
            `)}
          </tbody>
        </table>
      </div>
      `}
    </div>
  `;
}


/** Certificate code: CGTIA + issue date + mixed name fragment + random (not obvious) */
function yearYY(y) {
  if (y == null || y === "") return String(new Date().getFullYear()).slice(-2);
  const s = String(y);
  return s.length >= 2 ? s.slice(-2) : s.padStart(2, "0");
}
function randCodeChars(n) {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let out = "";
  for (let i = 0; i < n; i++) out += alphabet[Math.floor(Math.random() * alphabet.length)];
  return out;
}
/** ID card: IDC + last4(reg) + YY + 4 random — student must have regNumber */
function genIdCardCode(regNumber, year) {
  const reg = String(regNumber || "").replace(/[^a-zA-Z0-9]/g, "");
  if (reg.length < 4) throw new Error("Student needs a registration number first");
  const frag = reg.slice(-4).toUpperCase();
  return "IDC" + frag + yearYY(year) + randCodeChars(4);
}

/** Licence: LIC + 4 rand + YY + 4 rand */
function genLicenceCode(year) {
  return "LIC" + randCodeChars(4) + yearYY(year) + randCodeChars(4);
}

/** Certificate: CRT + 4 rand + YY + 4 rand (year conscious — not always current) */
function genCertCode(studentName, issueDate, year) {
  let y = year;
  if (y == null || y === "") {
    if (issueDate && String(issueDate).length >= 4) y = String(issueDate).slice(0, 4);
    else y = new Date().getFullYear();
  }
  return "CRT" + randCodeChars(4) + yearYY(y) + randCodeChars(4);
}

/**
 * Same format as profile-invite / submit-student-profile Cloud Function:
 *   YY/CG/######   e.g. 26/CG/492999
 * Year = last two digits. CG is fixed. Six random digits. Not sequential.
 * Cohort is stored separately — not part of the reg number.
 */
function toEmbedVideoUrl(url) {
  const u = String(url || "").trim();
  if (!u) return "";
  // youtu.be/ID or youtube.com/watch?v=ID → embed
  let m = u.match(/youtu\.be\/([\w-]{6,})/i);
  if (m) return "https://www.youtube.com/embed/" + m[1];
  m = u.match(/[?&]v=([\w-]{6,})/i);
  if (m) return "https://www.youtube.com/embed/" + m[1];
  m = u.match(/youtube\.com\/embed\/([\w-]{6,})/i);
  if (m) return "https://www.youtube.com/embed/" + m[1];
  m = u.match(/vimeo\.com\/(?:video\/)?(\d+)/i);
  if (m) return "https://player.vimeo.com/video/" + m[1];
  return u;
}

function genRegNumber(program, year, existingRegs) {
  const set = new Set((existingRegs || []).map((r) => String(r || "").trim().toUpperCase()));
  let y = String(year || new Date().getFullYear());
  if (y.length >= 4) y = y.slice(-2);
  else if (y.length === 1) y = "0" + y;
  function digits(n) {
    let s = "";
    for (let i = 0; i < n; i++) s += Math.floor(Math.random() * 10);
    return s;
  }
  for (let attempt = 0; attempt < 30; attempt++) {
    const candidate = y + "/CG/" + digits(6);
    if (!set.has(candidate.toUpperCase())) return candidate;
  }
  return y + "/CG/" + digits(4) + String(Date.now()).slice(-4);
}


function InvitesPanel() {
  const DOMAINS = PUBLIC_SITE_PRESETS;
  const [rows, setRows] = useState([]);
  const [err, setErr] = useState("");
  const [email, setEmail] = useState("");
  const [fullName, setFullName] = useState("");
  const [program, setProgram] = useState("certificate");
  const [expireAmount, setExpireAmount] = useState("24");
  const [expireUnit, setExpireUnit] = useState("hours"); // hours | days
  const [domain, setDomain] = useState(getStoredPublicSite());
  const [lastLink, setLastLink] = useState("");
  const [inviteTab, setInviteTab] = useState("create");

  async function load() {
    try {
      const api = await getDb();
      const snap = await api.getDocs(api.collection(api.db, "studentInvites"));
      const list = [];
      snap.forEach((d) => { if (!isTrashed(d.data())) list.push({ id: d.id, ...d.data() }); });
      list.sort((a, b) => {
        const ta = a.createdAt && a.createdAt.toDate ? a.createdAt.toDate().getTime() : 0;
        const tb = b.createdAt && b.createdAt.toDate ? b.createdAt.toDate().getTime() : 0;
        return tb - ta;
      });
      setRows(list);
    } catch (e) {
      setErr(e.message || String(e));
    }
  }
  useEffect(() => { load(); }, []);

  function makeToken() {
    const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789";
    let tok = "";
    for (let i = 0; i < 24; i++) tok += alphabet[Math.floor(Math.random() * alphabet.length)];
    return tok;
  }

  function expiryMs() {
    const n = Math.max(1, parseInt(expireAmount, 10) || 1);
    if (expireUnit === "days") return n * 24 * 60 * 60 * 1000;
    return n * 60 * 60 * 1000; // hours
  }

  async function createInvite(e) {
    e.preventDefault();
    try {
      const api = await getDb();
      const token = makeToken();
      const expiresAt = new Date(Date.now() + expiryMs());
      await api.setDoc(api.doc(api.db, "studentInvites", token), {
        email: (email || "").trim().toLowerCase(),
        fullName: (fullName || "").trim(),
        program: program || "",
        used: false,
        expiresAt: expiresAt.toISOString(),
        domain: domain,
        createdAt: api.serverTimestamp()
      });
      const base = (domain || DOMAINS[0]).replace(/\/$/, "");
      const full = base + "/field-check/confirm?token=" + token;
      setLastLink(full);
      setEmail("");
      setFullName("");
      toast("Invite created — copy the full link below");
      load();
    } catch (ex) {
      setErr(ex.message || String(ex));
      toast(ex.message || "Failed", "error");
    }
  }

  async function revoke(id) {
    if (!(await askConfirm("Revoke this invite?"))) return;
    const api = await getDb();
    await api.setDoc(api.doc(api.db, "studentInvites", id), { used: true, revoked: true, updatedAt: api.serverTimestamp() }, { merge: true });
    load();
  }

  async function deleteInvite(id) {
    if (!(await askConfirm("Move this profile invite to Trash?"))) return;
    try {
      await moveToTrash("studentInvites", id);
      toast("Moved to Trash");
      load();
    } catch (ex) {
      toast(ex.message || "Failed", "error");
    }
  }

  function expLabel(row) {
    const exp = row.expiresAt;
    if (!exp) return "—";
    const d = typeof exp === "string" ? new Date(exp) : (exp.toDate ? exp.toDate() : new Date(exp));
    if (isNaN(d.getTime())) return "—";
    if (row.used) return "Used";
    if (Date.now() > d.getTime()) return "Expired";
    return d.toLocaleString();
  }

  function linkFor(row) {
    const base = (row.domain || domain || DOMAINS[0]).replace(/\/$/, "");
    return base + "/field-check/confirm?token=" + row.id;
  }

  return html`
    <div>
      <h1>Profile invites</h1>
      <p class="muted">Create a one-time, expiring link. Choose the website address, set expiry in hours or days, then send only to that student.</p>
      ${err ? html`<p class="error">${err}</p>` : null}
      <${SubTabs}
        tabs=${[{ id: "create", label: "Create invite" }, { id: "list", label: "Invites (" + rows.length + ")" }]}
        active=${inviteTab}
        onChange=${setInviteTab}
        menu=${[{ label: "Refresh", run: () => window.dispatchEvent(new Event("cgtia:refresh")) }]} />
      ${inviteTab === "create" ? html`
      <form class="card" onSubmit=${createInvite} style=${{ marginBottom: "1rem" }}>
        <div class="form-row">
          <${PublicSiteDomainField} domain=${domain} setDomain=${setDomain} />
        </div>
        <div class="form-row">
          <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Email (optional — lock invite to this email if set)</label>
          <input type="email" value=${email} onInput=${(e) => setEmail(e.target.value)} placeholder="Leave blank for walk-ins" />
        </div>
        <div class="form-row">
          <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Name hint (optional)</label>
          <input value=${fullName} onInput=${(e) => setFullName(e.target.value)} placeholder="Pre-fill legal name on form" />
        </div>
        <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "0.5rem" }}>
          <div>
            <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Programme</label>
            <select value=${program} onChange=${(e) => setProgram(e.target.value)}>
              <option value="certificate">certificate</option>
              <option value="diploma">diploma</option>
              <option value="higher-diploma">higher-diploma</option>
              <option value="licensing">licensing</option>
            </select>
          </div>
          <div>
            <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Expires in</label>
            <input type="number" min="1" max="720" value=${expireAmount} onInput=${(e) => setExpireAmount(e.target.value)} />
          </div>
          <div>
            <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Unit</label>
            <select value=${expireUnit} onChange=${(e) => setExpireUnit(e.target.value)}>
              <option value="hours">hours</option>
              <option value="days">days</option>
            </select>
          </div>
        </div>
        <button class="primary" type="submit">Create invite link</button>
      </form>
      ${lastLink ? html`
        <div class="card" style=${{ marginBottom: "1rem", background: "#ecfdf5" }}>
          <p class="muted" style=${{ marginBottom: "0.35rem" }}>Copy and send this full link:</p>
          <code style=${{ wordBreak: "break-all", fontSize: "0.8rem" }}>${lastLink}</code>
          <button class="ghost" style=${{ marginTop: "0.5rem" }} type="button" onClick=${() => { navigator.clipboard && navigator.clipboard.writeText(lastLink); toast("Link copied"); }}>Copy link</button>
        </div>
      ` : null}
      ` : null}
      ${inviteTab === "list" ? html`
      <div class="table-wrap">
        <table>
          <thead>
            <tr><th>Token</th><th>Email</th><th>Name</th><th>Program</th><th>Expires / status</th><th></th></tr>
          </thead>
          <tbody>
            ${rows.length === 0 ? html`<tr><td colspan="6" class="muted">No invites yet.</td></tr>` : null}
            ${rows.map((r) => html`
              <tr key=${r.id}>
                <td><code style=${{ fontSize: "0.65rem" }}>${String(r.id).slice(0, 10)}…</code></td>
                <td>${r.email || "— any —"}</td>
                <td>${r.fullName || "—"}</td>
                <td>${r.program || "—"}</td>
                <td>${expLabel(r)}${r.used && r.regNumber ? " · " + r.regNumber : ""}</td>
                <td>
                  ${!r.used ? html`<button class="ghost" onClick=${() => { setLastLink(linkFor(r)); toast("Link shown above"); }}>Show link</button>` : null}
                  ${!r.used ? html`<button class="ghost" onClick=${() => revoke(r.id)}>Cancel link</button>` : null}
                  <button class="ghost" style=${{ color: "#dc2626" }} onClick=${() => deleteInvite(r.id)}>Delete</button>
                </td>
              </tr>
            `)}
          </tbody>
        </table>
      </div>
      ` : null}
    </div>
  `;
}




function LicensingRequestsPanel() {
  const [rows, setRows] = useState([]);
  const [err, setErr] = useState("");
  async function load() {
    try {
      const api = await getDb();
      const snap = await api.getDocs(api.collection(api.db, "licensingRequests"));
      const list = [];
      snap.forEach((d) => list.push({ id: d.id, ...d.data() }));
      list.sort((a, b) => String(b.createdAt || "").localeCompare(String(a.createdAt || "")));
      setRows(list);
    } catch (e) { setErr(e.message || String(e)); }
  }
  useEffect(() => { load(); }, []);
  async function setStatus(id, status) {
    const api = await getDb();
    await api.setDoc(api.doc(api.db, "licensingRequests", id), { status, updatedAt: api.serverTimestamp() }, { merge: true });
    load();
  }
  return html`
    <div>
      <h1>Licensing requests</h1>
      <p class="muted">From the public licensing form. CGTIA students and outside applicants are marked. After interview, use <strong>Licensing invites</strong> to send a one-time document link to external applicants.</p>
      ${err ? html`<p class="error">${err}</p>` : null}
      <div class="table-wrap">
        <table>
          <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>CGTIA student?</th><th>Background</th><th>Status</th><th></th></tr></thead>
          <tbody>
            ${rows.length === 0 ? html`<tr><td colspan="7" class="muted">No requests yet.</td></tr>` : null}
            ${rows.map((r) => html`
              <tr key=${r.id}>
                <td>${r.fullName || "—"}</td>
                <td>${r.email || "—"}</td>
                <td>${r.phone || "—"}</td>
                <td>${r.isCgtiaStudent ? "Yes" + (r.regNumber ? " · " + r.regNumber : "") : "No (external)"}</td>
                <td style=${{ maxWidth: "180px", fontSize: "0.75rem" }}>${(r.trainingBackground || "").slice(0, 80)}</td>
                <td><${Badge} status=${r.status || "new"} /></td>
                <td style=${{ whiteSpace: "nowrap" }}>
                  <button class="ghost" onClick=${() => setStatus(r.id, "reviewing")}>Reviewing</button>
                  <button class="ghost" onClick=${() => setStatus(r.id, "qualified")}>Qualified</button>
                  <button class="ghost" onClick=${() => setStatus(r.id, "rejected")}>Reject</button>
                </td>
              </tr>
            `)}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function LicensingInvitesPanel() {
  const DOMAINS = PUBLIC_SITE_PRESETS;
  const [rows, setRows] = useState([]);
  const [email, setEmail] = useState("");
  const [fullName, setFullName] = useState("");
  const [isStudent, setIsStudent] = useState("no");
  const [hours, setHours] = useState("48");
  const [domain, setDomain] = useState(getStoredPublicSite());
  const [lastLink, setLastLink] = useState("");
  const [err, setErr] = useState("");

  async function load() {
    try {
      const api = await getDb();
      const snap = await api.getDocs(api.collection(api.db, "licensingInvites"));
      const list = [];
      snap.forEach((d) => list.push({ id: d.id, ...d.data() }));
      setRows(list.filter((r) => !isTrashed(r) && !r.purged));
    } catch (e) { setErr(e.message || String(e)); }
  }
  useEffect(() => { load(); }, []);

  function tok() {
    const a = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789";
    let s = "";
    for (let i = 0; i < 24; i++) s += a[Math.floor(Math.random() * a.length)];
    return s;
  }

  async function create(e) {
    e.preventDefault();
    try {
      const api = await getDb();
      const token = tok();
      const expiresAt = new Date(Date.now() + Math.max(1, parseInt(hours, 10) || 48) * 3600000).toISOString();
      await api.setDoc(api.doc(api.db, "licensingInvites", token), {
        email: email.trim().toLowerCase(),
        fullName: fullName.trim(),
        isCgtiaStudent: isStudent === "yes",
        used: false,
        expiresAt,
        createdAt: api.serverTimestamp()
      });
      setLastLink(domain.replace(/\/$/, "") + "/licensing/complete?token=" + token);
      setEmail(""); setFullName("");
      toast("Licensing invite created");
      load();
    } catch (ex) {
      setErr(ex.message || String(ex));
    }
  }

  async function deleteLicInvite(id) {
    if (!(await askConfirm("Move this licensing invite to Trash?"))) return;
    try {
      await moveToTrash("licensingInvites", id);
      toast("Moved to Trash");
      load();
    } catch (ex) {
      toast(ex.message || "Failed", "error");
    }
  }


  return html`
    <div>
      <h1>Licensing invites</h1>
      <p class="muted">One-time links for <strong>external</strong> (or invited) applicants to upload documents after interview. Each link is unique to one applicant. CGTIA students usually only need request + payment once credentials are on file.</p>
      ${err ? html`<p class="error">${err}</p>` : null}
      <form class="card" onSubmit=${create} style=${{ marginBottom: "1rem" }}>
        <div class="form-row"><label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Domain</label>
          <${PublicSiteDomainField} domain=${domain} setDomain=${setDomain} />
        </div>
        <div class="form-row"><label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Email</label><input type="email" required value=${email} onInput=${(e) => setEmail(e.target.value)} /></div>
        <div class="form-row"><label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Name</label><input value=${fullName} onInput=${(e) => setFullName(e.target.value)} /></div>
        <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.5rem" }}>
          <div><label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Applicant type</label>
            <select value=${isStudent} onChange=${(e) => setIsStudent(e.target.value)}>
              <option value="no">External</option>
              <option value="yes">CGTIA student</option>
            </select>
          </div>
          <div><label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Expires (hours)</label>
            <input type="number" min="1" value=${hours} onInput=${(e) => setHours(e.target.value)} />
          </div>
        </div>
        <button class="primary" type="submit">Create invite link</button>
      </form>
      ${lastLink ? html`<div class="card" style=${{ background: "#ecfdf5", marginBottom: "1rem" }}><code style=${{ wordBreak: "break-all", fontSize: "0.8rem" }}>${lastLink}</code>
        <button class="ghost" type="button" onClick=${() => { navigator.clipboard && navigator.clipboard.writeText(lastLink); toast("Copied"); }}>Copy</button></div>` : null}
      <div class="table-wrap">
        <table>
          <thead><tr><th>Token</th><th>Email</th><th>Type</th><th>Used</th><th></th></tr></thead>
          <tbody>
            ${rows.map((r) => html`<tr key=${r.id}><td><code style=${{ fontSize: "0.65rem" }}>${String(r.id).slice(0, 12)}…</code></td><td>${r.email}</td><td>${r.isCgtiaStudent ? "Student" : "External"}</td><td>${r.used ? "Yes" : "No"}</td><td><button class="ghost" style=${{ color: "#dc2626" }} type="button" onClick=${() => deleteLicInvite(r.id)}>Delete</button></td></tr>`)}
          </tbody>
        </table>
      </div>
    </div>
  `;
}


function IdCardsPanel() {
  const [rows, setRows] = useState([]);
  const [students, setStudents] = useState([]);
  const [err, setErr] = useState("");
  const [studentId, setStudentId] = useState("");
  const [expiryDate, setExpiryDate] = useState("");
  const [idTab, setIdTab] = useState("issued");
  const [statusFilter, setStatusFilter] = useState("all");

  async function load() {
    try {
      const api = await getDb();
      const snap = await api.getDocs(api.collection(api.db, "idCards"));
      const list = [];
      snap.forEach((d) => list.push({ id: d.id, ...d.data() }));
      setRows(list);
      const ss = await api.getDocs(api.collection(api.db, "students"));
      const sl = [];
      ss.forEach((d) => { if (d.data().trashed !== true) sl.push({ id: d.id, ...d.data() }); });
      setStudents(sl);
    } catch (e) {
      setErr(e.message || String(e));
    }
  }
  useEffect(() => { load(); }, []);

  async function issue(e) {
    e.preventDefault();
    const st = students.find((s) => s.id === studentId);
    if (!st) { toast("Select a student", "error"); return; }
    try {
      const api = await getDb();
      if (!st.regNumber) { toast("Student must have a reg number first", "error"); return; }
      const yearEl = document.getElementById("idCardYear");
      const idYear = (yearEl && yearEl.value) || st.year || st.gradYear || new Date().getFullYear();
      let code = genIdCardCode(st.regNumber, idYear);
      for (let i = 0; i < 5; i++) {
        const ex = await api.getDoc(api.doc(api.db, "idCards", code));
        if (!ex.exists()) break;
        code = genIdCardCode(st.regNumber, idYear);
      }
      const issueDate = new Date().toISOString().slice(0, 10);
      await api.setDoc(api.doc(api.db, "idCards", code), {
        code,
        studentId: st.id,
        studentName: st.fullLegalName || st.fullName || "",
        regNumber: st.regNumber || "",
        program: st.program || "",
        cohort: st.cohort || "",
        email: st.email || "",
        photoUrl: st.photoUrl || "",
        issueDate,
        expiryDate: expiryDate || "",
        status: "valid",
        renewable: false,
        createdAt: api.serverTimestamp(),
        updatedAt: api.serverTimestamp()
      });
      await api.setDoc(api.doc(api.db, "students", st.id), { idCardCode: code, updatedAt: api.serverTimestamp() }, { merge: true });
      toast("ID card issued: " + code);
      setStudentId("");
      load();
    } catch (ex) {
      toast(ex.message || "Failed", "error");
    }
  }

  async function setStatus(row, status) {
    const api = await getDb();
    await api.setDoc(api.doc(api.db, "idCards", row.id), { status, updatedAt: api.serverTimestamp() }, { merge: true });
    load();
    toast("Status → " + status);
  }

  const visible = rows.filter((r) => {
    if (statusFilter === "all") return true;
    const s = String(r.status || "valid").toLowerCase();
    if (statusFilter === "valid") return s === "valid" || s === "active";
    return s === statusFilter;
  });

  return html`
    <div>
      <h1>ID cards</h1>
      <p class="muted">Issue a student ID card (code uses part of reg number + random). Not renewable for now — set expiry when classes end. Public verify: <code>/verify</code> → ID card.</p>
      ${err ? html`<p class="error">${err}</p>` : null}
      <${SubTabs}
        tabs=${[
          { id: "issued", label: "Issued (" + rows.length + ")" },
          { id: "issue", label: "Issue ID card" }
        ]}
        active=${idTab}
        onChange=${setIdTab}
        menu=${idTab === "issued" ? [
          { label: "All statuses", checked: statusFilter === "all", run: () => setStatusFilter("all") },
          { label: "Valid / active", checked: statusFilter === "valid", run: () => setStatusFilter("valid") },
          { label: "Expired", checked: statusFilter === "expired", run: () => setStatusFilter("expired") },
          { label: "Revoked", checked: statusFilter === "revoked", run: () => setStatusFilter("revoked") }
        ] : null} />
      ${idTab === "issue" ? html`
      <form class="card" onSubmit=${async (e) => { await issue(e); setIdTab("issued"); }} style=${{ marginBottom: "1rem" }}>
        <div class="form-row">
          <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Student</label>
          <select required value=${studentId} onChange=${(e) => setStudentId(e.target.value)}>
            <option value="">Select…</option>
            ${students.map((s) => html`<option key=${s.id} value=${s.id}>${s.fullLegalName || s.fullName || s.email} · ${s.regNumber || "no reg"}</option>`)}
          </select>
        </div>
        <div class="form-row">
          <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Year in ID number</label>
          <input type="number" min="2015" max="2099" id="idCardYear" defaultValue=${new Date().getFullYear()} />
        </div>
        <div class="form-row">
          <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Expiry date (end of classes)</label>
          <input type="date" value=${expiryDate} onInput=${(e) => setExpiryDate(e.target.value)} />
        </div>
        <div style=${{ display: "flex", gap: "0.5rem" }}>
          <button class="primary" type="submit">Issue ID card</button>
          <button type="button" class="ghost" onClick=${() => setIdTab("issued")}>Cancel</button>
        </div>
      </form>
      ` : html`
      <div class="table-wrap">
        <table>
          <thead><tr><th>Code</th><th>Student</th><th>Reg</th><th>Expires</th><th>Status</th><th></th></tr></thead>
          <tbody>
            ${visible.length === 0 ? html`<tr><td colspan="6" class="muted">Nothing in this filter.</td></tr>` : null}
            ${visible.map((r) => html`
              <tr key=${r.id}>
                <td><code style=${{ fontSize: "0.7rem" }}>${r.code || r.id}</code></td>
                <td>${r.studentName || "—"}</td>
                <td><code style=${{ fontSize: "0.65rem" }}>${r.regNumber || "—"}</code></td>
                <td>${r.expiryDate || "—"}</td>
                <td><${Badge} status=${r.status} /></td>
                <td>
                  ${r.status !== "expired" ? html`<button class="ghost" onClick=${() => setStatus(r, "expired")}>Mark expired</button>` : null}
                  ${r.status !== "revoked" ? html`<button class="ghost" onClick=${() => setStatus(r, "revoked")}>Cancel link</button>` : null}
                  ${r.status === "revoked" || r.status === "expired" ? html`<button class="ghost" onClick=${() => setStatus(r, "valid")}>Restore</button>` : null}
                </td>
              </tr>
            `)}
          </tbody>
        </table>
      </div>
      `}
    </div>
  `;
}

function LicencesPanel() {
  const empty = { code: "", holderName: "", studentId: "", category: "caregiver", issueDate: "", expiryDate: "", status: "valid", notes: "", codeYear: String(new Date().getFullYear()) };
  const [rows, setRows] = useState([]);
  const [form, setForm] = useState({ ...empty });
  const [editId, setEditId] = useState(null);
  const [err, setErr] = useState("");
  const [licTab, setLicTab] = useState("issued");
  const [statusFilter, setStatusFilter] = useState("all");

  async function load() {
    try {
      const api = await getDb();
      const snap = await api.getDocs(api.collection(api.db, "licences"));
      const list = [];
      snap.forEach((d) => list.push({ id: d.id, ...d.data() }));
      setRows(list);
    } catch (e) {
      setErr(e.message || String(e));
    }
  }
  useEffect(() => { load(); }, []);

  function openNew() {
    setEditId(null);
    const y = new Date().getFullYear();
    setForm({ ...empty, code: genLicenceCode(y), issueDate: y + "-01-01".replace("-01-01", "-" + String(new Date().getMonth()+1).padStart(2,"0") + "-" + String(new Date().getDate()).padStart(2,"0")), codeYear: String(y) });
    setLicTab("issue");
  }

  async function save(e) {
    e.preventDefault();
    const code = (form.code || "").trim().toUpperCase();
    if (!code || !form.holderName.trim()) { toast("Code and holder name required", "error"); return; }
    try {
      const api = await getDb();
      const id = editId || code;
      await api.setDoc(api.doc(api.db, "licences", id), {
        code,
        holderName: form.holderName.trim(),
        studentId: form.studentId || "",
        category: form.category || "",
        issueDate: form.issueDate || "",
        expiryDate: form.expiryDate || "",
        status: form.status || "valid",
        notes: form.notes || "",
        renewable: true,
        updatedAt: api.serverTimestamp(),
        ...(editId ? {} : { createdAt: api.serverTimestamp() })
      }, { merge: true });
      toast(editId ? "Updated" : "Licence issued");
      setEditId(null);
      setForm({ ...empty });
      setLicTab("issued");
      load();
    } catch (ex) {
      toast(ex.message || "Failed", "error");
    }
  }

  async function setStatus(row, status) {
    const api = await getDb();
    const extra = {};
    if (status === "valid" && row.status === "suspended") extra.notes = (row.notes || "") + " [restored]";
    if (status === "valid" && String(row.status).toLowerCase() === "expired") {
      extra.renewedAt = new Date().toISOString().slice(0, 10);
    }
    await api.setDoc(api.doc(api.db, "licences", row.id), { status, ...extra, updatedAt: api.serverTimestamp() }, { merge: true });
    load();
    toast("Licence → " + status);
  }

  async function renew(row) {
    const months = prompt("Extend expiry by how many months?", "12");
    const m = parseInt(months, 10);
    if (!m || m < 1) return;
    const base = row.expiryDate ? new Date(row.expiryDate) : new Date();
    if (base < new Date()) base.setTime(Date.now());
    base.setMonth(base.getMonth() + m);
    const expiryDate = base.toISOString().slice(0, 10);
    const api = await getDb();
    await api.setDoc(api.doc(api.db, "licences", row.id), {
      status: "valid",
      expiryDate,
      renewedAt: new Date().toISOString().slice(0, 10),
      updatedAt: api.serverTimestamp()
    }, { merge: true });
    load();
    toast("Renewed until " + expiryDate);
  }

  const visible = rows.filter((r) => {
    if (statusFilter === "all") return true;
    const s = String(r.status || "valid").toLowerCase();
    if (statusFilter === "valid") return s === "valid" || s === "active";
    return s === statusFilter;
  });

  return html`
    <div>
      <h1>Licences</h1>
      <p class="muted">Issue, renew, suspend, revoke, or ban professional licences. Renewable. Public verify: <code>/verify</code> → Licence.</p>
      ${err ? html`<p class="error">${err}</p>` : null}
      <${SubTabs}
        tabs=${[
          { id: "issued", label: "Issued (" + rows.length + ")" },
          { id: "issue", label: editId ? "Edit licence" : "Issue licence" }
        ]}
        active=${licTab}
        onChange=${(id) => { setLicTab(id); if (id === "issue" && !form.code && !editId) openNew(); if (id === "issued") { setEditId(null); setForm({ ...empty }); } }}
        menu=${licTab === "issued" ? [
          { label: "All statuses", checked: statusFilter === "all", run: () => setStatusFilter("all") },
          { label: "Valid / active", checked: statusFilter === "valid", run: () => setStatusFilter("valid") },
          { label: "Suspended", checked: statusFilter === "suspended", run: () => setStatusFilter("suspended") },
          { label: "Revoked", checked: statusFilter === "revoked", run: () => setStatusFilter("revoked") },
          { label: "Banned", checked: statusFilter === "banned", run: () => setStatusFilter("banned") },
          { label: "Expired", checked: statusFilter === "expired", run: () => setStatusFilter("expired") }
        ] : null} />
      ${licTab === "issue" ? html`
        <form class="card" onSubmit=${save} style=${{ marginBottom: "1rem" }}>
          <div class="form-row"><label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Year in licence number</label>
            <input type="number" min="2015" max="2099" value=${form.codeYear || new Date().getFullYear()} onInput=${(e) => {
              const y = e.target.value;
              setForm({ ...form, codeYear: y, code: genLicenceCode(y) });
            }} />
          </div>
          <div class="form-row"><label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Licence number</label><input required value=${form.code} onInput=${(e) => setForm({ ...form, code: e.target.value.toUpperCase() })} /></div>
          <div class="form-row"><label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Holder full name</label><input required value=${form.holderName} onInput=${(e) => setForm({ ...form, holderName: e.target.value })} /></div>
          <div class="form-row"><label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Category</label>
            <select value=${form.category} onChange=${(e) => setForm({ ...form, category: e.target.value })}>
              <option value="caregiver">caregiver</option>
              <option value="nanny">nanny</option>
              <option value="other">other</option>
            </select>
          </div>
          <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.5rem" }}>
            <div><label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Issue date</label><input type="date" value=${form.issueDate} onInput=${(e) => setForm({ ...form, issueDate: e.target.value })} /></div>
            <div><label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Expiry</label><input type="date" value=${form.expiryDate} onInput=${(e) => setForm({ ...form, expiryDate: e.target.value })} /></div>
          </div>
          <div class="form-row"><label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Status</label>
            <select value=${form.status} onChange=${(e) => setForm({ ...form, status: e.target.value })}>
              <option value="valid">valid</option>
              <option value="suspended">suspended</option>
              <option value="revoked">revoked</option>
              <option value="banned">banned</option>
              <option value="expired">expired</option>
            </select>
          </div>
          <div class="form-row"><label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Notes</label><input value=${form.notes} onInput=${(e) => setForm({ ...form, notes: e.target.value })} /></div>
          <button class="primary" type="submit">Save</button>
          <button type="button" class="ghost" onClick=${() => { setEditId(null); setForm({ ...empty }); setLicTab("issued"); }}>Cancel</button>
        </form>
      ` : html`
      <div class="table-wrap">
        <table>
          <thead><tr><th>Number</th><th>Holder</th><th>Category</th><th>Expires</th><th>Status</th><th></th></tr></thead>
          <tbody>
            ${visible.length === 0 ? html`<tr><td colspan="6" class="muted">Nothing in this filter.</td></tr>` : null}
            ${visible.map((r) => html`
              <tr key=${r.id}>
                <td><code style=${{ fontSize: "0.7rem" }}>${r.code || r.id}</code></td>
                <td>${r.holderName || "—"}</td>
                <td>${r.category || "—"}</td>
                <td>${r.expiryDate || "—"}</td>
                <td><${Badge} status=${r.status} /></td>
                <td style=${{ whiteSpace: "nowrap" }}>
                  <button class="ghost" onClick=${() => renew(r)}>Renew</button>
                  <button class="ghost" onClick=${() => setStatus(r, "suspended")}>Suspend</button>
                  <button class="ghost" onClick=${() => setStatus(r, "revoked")}>Cancel link</button>
                  <button class="ghost" onClick=${() => setStatus(r, "banned")}>Ban</button>
                  <button class="ghost" onClick=${() => setStatus(r, "valid")}>Restore</button>
                </td>
              </tr>
            `)}
          </tbody>
        </table>
      </div>
      `}
    </div>
  `;
}


function CertificatesPanel() {
  const empty = {
    code: "",
    studentName: "",
    studentId: "",
    program: "certificate",
    issueDate: "",
    expiryDate: "",
    status: "valid",
    grade: "",
    notes: "",
    photoUrl: "",
    codeYear: String(new Date().getFullYear())
  };
  const [rows, setRows] = useState([]);
  const [form, setForm] = useState({ ...empty });
  const [editId, setEditId] = useState(null);
  const [err, setErr] = useState("");
  const [filter, setFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [certTab, setCertTab] = useState("issued");

  async function load() {
    try {
      const api = await getDb();
      const snap = await api.getDocs(api.collection(api.db, "certificates"));
      const list = [];
      snap.forEach((d) => { if (d.data().trashed !== true) list.push({ id: d.id, ...d.data() }); });
      list.sort((a, b) => String(b.issueDate || "").localeCompare(String(a.issueDate || "")));
      setRows(list);
    } catch (e) {
      setErr(e.message || String(e));
    }
  }
  useEffect(() => { load(); }, []);

  function openNew() {
    setEditId(null);
    setForm({ ...empty, code: genCertCode("", new Date().toISOString().slice(0, 10), new Date().getFullYear()), issueDate: new Date().toISOString().slice(0, 10) });
    setCertTab("issue");
  }
  function openEdit(row) {
    setEditId(row.id);
    setForm({
      code: row.code || row.id || "",
      studentName: row.studentName || "",
      studentId: row.studentId || "",
      program: row.program || "certificate",
      issueDate: row.issueDate || "",
      expiryDate: row.expiryDate || "",
      status: row.status || "valid",
      grade: row.grade || "",
      notes: row.notes || "",
      photoUrl: row.photoUrl || ""
    });
    setCertTab("issue");
  }
  function cancel() {
    setEditId(null);
    setForm({ ...empty });
    setCertTab("issued");
  }

  async function save(e) {
    e.preventDefault();
    const code = (form.code || "").trim().toUpperCase();
    if (!code) { toast("Certificate code required", "error"); return; }
    if (!form.studentName.trim()) { toast("Student name required", "error"); return; }
    try {
      const api = await getDb();
      const id = editId || code;
      const payload = {
        code,
        studentName: form.studentName.trim(),
        studentId: (form.studentId || "").trim(),
        program: form.program,
        issueDate: form.issueDate || "",
        expiryDate: form.expiryDate || "",
        status: form.status || "valid",
        grade: form.grade || "",
        notes: form.notes || "",
        photoUrl: form.photoUrl || "",
        updatedAt: api.serverTimestamp()
      };
      if (!editId) payload.createdAt = api.serverTimestamp();
      await api.setDoc(api.doc(api.db, "certificates", id), payload, { merge: true });
      // Optionally mirror onto student record if studentId set
      if (payload.studentId) {
        try {
          await api.setDoc(api.doc(api.db, "students", payload.studentId), {
            certificateCode: code,
            certificateStatus: payload.status,
            updatedAt: api.serverTimestamp()
          }, { merge: true });
        } catch (_) {}
      }
      toast(editId ? "Certificate updated" : "Certificate issued");
      cancel();
      load();
    } catch (ex) {
      setErr(ex.message || String(ex));
      toast(ex.message || "Save failed", "error");
    }
  }

  async function remove(id) {
    if (!(await askConfirm("Delete this certificate?"))) return;
    try {
      const api = await getDb();
      await moveToTrash("certificates", id);
      toast("Moved to Trash", "ok");
      if (editId === id) cancel();
      load();
    } catch (ex) {
      toast(ex.message || "Delete failed", "error");
    }
  }

  async function setStatus(row, status) {
    const api = await getDb();
    await api.setDoc(api.doc(api.db, "certificates", row.id), { status, updatedAt: api.serverTimestamp() }, { merge: true });
    load();
    toast("Status → " + status);
  }

  const q = filter.trim().toLowerCase();
  const byStatus = (r) => {
    if (statusFilter === "all") return true;
    const s = String(r.status || "valid").toLowerCase();
    if (statusFilter === "valid") return s === "valid" || s === "active";
    return s === statusFilter;
  };
  const visible = rows.filter((r) => {
    if (!byStatus(r)) return false;
    if (!q) return true;
    return [r.code, r.studentName, r.program, r.studentId].some((x) => String(x || "").toLowerCase().includes(q));
  });

  return html`
    <div>
      <h1>Certificates</h1>
      <p class="muted">Generate verification codes, assign them to students, and manage validity. Public verify page reads the <code>certificates</code> collection by code.</p>
      ${err ? html`<p class="error">${err}</p>` : null}
      <${SubTabs}
        tabs=${[
          { id: "issued", label: "Issued (" + rows.length + ")" },
          { id: "issue", label: editId ? "Edit certificate" : "Issue certificate" }
        ]}
        active=${certTab}
        onChange=${(id) => { setCertTab(id); if (id === "issue" && !form.code && !editId) openNew(); if (id === "issued") cancel(); }}
        menu=${certTab === "issued" ? [
          { label: "All statuses", checked: statusFilter === "all", run: () => setStatusFilter("all") },
          { label: "Valid / active", checked: statusFilter === "valid", run: () => setStatusFilter("valid") },
          { label: "Revoked", checked: statusFilter === "revoked", run: () => setStatusFilter("revoked") },
          { label: "Expired", checked: statusFilter === "expired", run: () => setStatusFilter("expired") },
          { label: "Withheld", checked: statusFilter === "withheld", run: () => setStatusFilter("withheld") }
        ] : null} />
      ${certTab === "issue" ? html`
        <form class="card" onSubmit=${async (e) => { await save(e); }} style=${{ marginBottom: "1rem" }}>
          <p class="muted">${editId ? "Edit certificate" : "New certificate"}</p>
          <div class="form-row">
            <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Certificate code</label>
            <div style=${{ display: "flex", gap: "0.5rem" }}>
              <input required value=${form.code} onInput=${(e) => setForm({ ...form, code: e.target.value.toUpperCase() })} placeholder="CGTIA-2026-XXXX-1234" style=${{ flex: 1 }} />
              <button type="button" class="ghost" onClick=${() => setForm({ ...form, code: genCertCode(form.studentName, form.issueDate, form.codeYear) })}>Regenerate</button>
            </div>
          </div>
          <div class="form-row">
            <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Student full name</label>
            <input required value=${form.studentName} onInput=${(e) => setForm({ ...form, studentName: e.target.value })} placeholder="Ada Okonkwo" />
          </div>
          <div class="form-row">
            <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Student record (optional — links to Students)</label>
            <input value=${form.studentId} onInput=${(e) => setForm({ ...form, studentId: e.target.value })} placeholder="Leave empty if not linked" />
          </div>
          <div class="form-row">
            <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Programme</label>
            <select value=${form.program} onChange=${(e) => setForm({ ...form, program: e.target.value })}>
              <option value="certificate">certificate</option>
              <option value="diploma">diploma</option>
              <option value="higher-diploma">higher-diploma</option>
              <option value="licensing">licensing</option>
            </select>
          </div>
          <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.5rem" }}>
            <div>
              <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Issue date</label>
              <input type="date" value=${form.issueDate} onInput=${(e) => setForm({ ...form, issueDate: e.target.value })} />
            </div>
            <div>
              <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Expiry date (optional)</label>
              <input type="date" value=${form.expiryDate} onInput=${(e) => setForm({ ...form, expiryDate: e.target.value })} />
            </div>
          </div>
          <div class="form-row">
            <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Status</label>
            <select value=${form.status} onChange=${(e) => setForm({ ...form, status: e.target.value })}>
              <option value="valid">valid</option>
              <option value="revoked">revoked</option>
              <option value="expired">expired</option>
            </select>
          </div>
          <div class="form-row">
            <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Grade / result (optional)</label>
            <input value=${form.grade} onInput=${(e) => setForm({ ...form, grade: e.target.value })} placeholder="Pass / Distinction" />
          </div>
          <div class="form-row">
            <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Photo URL / path (optional)</label>
            <input value=${form.photoUrl} onInput=${(e) => setForm({ ...form, photoUrl: e.target.value })} placeholder="/assets/images/graduates/name.webp" />
          </div>
          <div class="form-row">
            <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Notes</label>
            <input value=${form.notes} onInput=${(e) => setForm({ ...form, notes: e.target.value })} placeholder="Internal notes" />
          </div>
          <div style=${{ display: "flex", gap: "0.5rem" }}>
            <button class="primary" type="submit">${editId ? "Update" : "Issue certificate"}</button>
            <button type="button" class="ghost" onClick=${cancel}>Cancel</button>
          </div>
        </form>
      ` : html`
        <div style=${{ display: "flex", gap: "0.5rem", marginBottom: "1rem", flexWrap: "wrap" }}>
          <input style=${{ flex: "1", minWidth: "180px" }} placeholder="Search code, name, program…" value=${filter} onInput=${(e) => setFilter(e.target.value)} />
        </div>
        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Code</th>
                <th>Student</th>
                <th>Program</th>
                <th>Issued</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              ${visible.length === 0 ? html`<tr><td colspan="6" class="muted">No certificates yet. Use the Issue certificate tab.</td></tr>` : null}
              ${visible.map((r) => html`
                <tr key=${r.id}>
                  <td><code>${r.code || r.id}</code></td>
                  <td>${r.studentName || "—"}</td>
                  <td>${r.program || "—"}</td>
                  <td>${r.issueDate || "—"}</td>
                  <td><${Badge} status=${r.status || "valid"} /></td>
                  <td style=${{ whiteSpace: "nowrap" }}>
                    <button class="ghost" onClick=${() => openEdit(r)}>Edit</button>
                    ${r.status !== "revoked" ? html`<button class="ghost" onClick=${() => setStatus(r, "revoked")}>Cancel link</button>` : html`<button class="ghost" onClick=${() => setStatus(r, "valid")}>Restore</button>`}
                    <button class="ghost" onClick=${() => remove(r.id)}>Delete</button>
                  </td>
                </tr>
              `)}
            </tbody>
          </table>
        </div>
      `}
    </div>
  `;
}




function PortalSettingsPanel() {
  const [form, setForm] = useState({
    showFees: true,
    showCourses: true,
    showResults: true,
    showProfile: true,
    welcomeNote: ""
  });
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const api = await getDb();
        const snap = await api.getDoc(api.doc(api.db, "siteContent", "portalSettings"));
        if (snap.exists()) setForm((f) => ({ ...f, ...snap.data() }));
      } catch (e) {}
    })();
  }, []);

  async function save(e) {
    e.preventDefault();
    try {
      const api = await getDb();
      await api.setDoc(api.doc(api.db, "siteContent", "portalSettings"), {
        showFees: form.showFees !== false,
        showCourses: form.showCourses !== false,
        showResults: form.showResults !== false,
        showProfile: form.showProfile !== false,
        welcomeNote: (form.welcomeNote || "").trim(),
        updatedAt: api.serverTimestamp()
      }, { merge: true });
      setSaved(true);
      toast("Portal settings saved");
      setTimeout(() => setSaved(false), 2000);
    } catch (ex) {
      toast(ex.message || "Save failed", "error");
    }
  }

  return html`
    <div>
      <h1>Student portal</h1>
      <p class="muted">Default visibility for all students. You can also turn sections off on an individual student record (Students → edit).</p>
      <form class="card" onSubmit=${save}>
        <div style=${{ display: "flex", flexDirection: "column", gap: "0.65rem", marginBottom: "1rem" }}>
          <${Toggle} checked=${form.showFees !== false} label="Show Fees section" onChange=${(v) => setForm({ ...form, showFees: v })} />
          <${Toggle} checked=${form.showCourses !== false} label="Show Courses section" onChange=${(v) => setForm({ ...form, showCourses: v })} />
          <${Toggle} checked=${form.showResults !== false} label="Show Results section" onChange=${(v) => setForm({ ...form, showResults: v })} />
        </div>
        <div class="form-row">
          <label class="muted">Optional welcome note (future use)</label>
          <textarea rows="2" value=${form.welcomeNote || ""} onInput=${(e) => setForm({ ...form, welcomeNote: e.target.value })}></textarea>
        </div>
        <button class="primary" type="submit">Save portal settings</button>
        ${saved ? html`<span class="muted" style=${{ marginLeft: "0.75rem" }}>Saved</span>` : null}
      </form>
      <div class="card" style=${{ marginTop: "1rem" }}>
        <h2 class="card-title">Teachers & grades</h2>
        <p class="muted">Users with role <code>instructor</code> can open <strong>Results / grades</strong> and enter marks. Students only see rows marked <strong>Published</strong>. Link each student’s email exactly to their Firebase login email so the portal can load their record.</p>
      </div>
    </div>
  `;
}



/** Best-effort PDF → lesson text (headers / body). Browser-side via pdf.js CDN. */
async function extractPdfToLessonText(file) {
  const buf = await file.arrayBuffer();
  const pdfjs = await import("https://cdn.jsdelivr.net/npm/pdfjs-dist@4.4.168/build/pdf.min.mjs");
  pdfjs.GlobalWorkerOptions.workerSrc = "https://cdn.jsdelivr.net/npm/pdfjs-dist@4.4.168/build/pdf.worker.min.mjs";
  const doc = await pdfjs.getDocument({ data: buf }).promise;
  const lines = [];
  for (let p = 1; p <= doc.numPages; p++) {
    const page = await doc.getPage(p);
    const tc = await page.getTextContent();
    let row = "";
    let lastY = null;
    tc.items.forEach((it) => {
      const y = it.transform ? it.transform[5] : 0;
      if (lastY != null && Math.abs(y - lastY) > 6) {
        if (row.trim()) lines.push(row.trim());
        row = "";
      }
      row += (it.str || "") + " ";
      lastY = y;
    });
    if (row.trim()) lines.push(row.trim());
    lines.push("");
  }
  // Heuristic structure
  const out = [];
  lines.forEach((ln) => {
    const t = ln.trim();
    if (!t) { out.push(""); return; }
    if (t.length < 80 && (t === t.toUpperCase() || /^\d+[\).\s]/.test(t))) {
      out.push("# " + t);
    } else if (t.length < 100 && /:$/.test(t)) {
      out.push("## " + t.replace(/:$/, ""));
    } else {
      out.push(t);
    }
  });
  return out.join("\n").replace(/\n{3,}/g, "\n\n");
}

function CoursesPanel() {
  const empty = {
    code: "", title: "", program: "certificate", sortOrder: "1", description: "", active: true, lessons: [],
    coverUrl: "", moduleQuizPassPercent: "90", moduleQuizQuestions: []
  };
  const [rows, setRows] = useState([]);
  const [form, setForm] = useState({ ...empty });
  const [editId, setEditId] = useState(null);
  const [tab, setTab] = useState("list");
  const [err, setErr] = useState("");
  const [filterProg, setFilterProg] = useState("all");

  async function load() {
    try {
      const api = await getDb();
      const snap = await api.getDocs(api.collection(api.db, "courses"));
      const list = [];
      snap.forEach((d) => list.push({ id: d.id, ...d.data() }));
      list.sort((a, b) => (Number(a.sortOrder) || 0) - (Number(b.sortOrder) || 0) || String(a.code || "").localeCompare(String(b.code || "")));
      setRows(list);
    } catch (e) { setErr(e.message || String(e)); }
  }
  useEffect(() => { load(); }, []);

  function openNew() {
    setEditId(null);
    setForm({ ...empty });
    setTab("edit");
  }
  function openEdit(row) {
    setEditId(row.id);
    setForm({
      code: row.code || "",
      title: row.title || "",
      program: row.program || "certificate",
      sortOrder: String(row.sortOrder != null ? row.sortOrder : 1),
      description: row.description || "",
      active: row.active !== false,
      coverUrl: row.coverUrl || "",
      moduleQuizPassPercent: String(row.moduleQuizPassPercent != null ? row.moduleQuizPassPercent : 90),
      moduleQuizQuestions: Array.isArray(row.moduleQuizQuestions) ? row.moduleQuizQuestions.map((q) => ({
        prompt: q.prompt || "",
        options: Array.isArray(q.options) ? q.options.slice() : ["", "", "", ""],
        correct: q.correct != null ? q.correct : 0
      })) : [],
      lessons: Array.isArray(row.lessons) ? row.lessons.map((l, i) => ({
        id: l.id || ("l" + i),
        title: l.title || "",
        header: l.header || "",
        subheader: l.subheader || "",
        type: l.type || "text",
        body: l.body || "",
        videoUrl: l.videoUrl || "",
        ttsText: l.ttsText || "",
        duration: l.duration || "",
        order: l.order != null ? l.order : i + 1,
        checkQuestions: Array.isArray(l.checkQuestions) ? l.checkQuestions.map((q) => ({
          prompt: q.prompt || "",
          options: Array.isArray(q.options) ? q.options.slice() : ["", "", "", ""],
          correct: q.correct != null ? q.correct : 0
        })) : []
      })) : []
    });
    setTab("edit");
  }
  function cancel() { setEditId(null); setForm({ ...empty }); setTab("list"); }

  async function save(e) {
    e.preventDefault();
    const code = (form.code || "").trim().toUpperCase();
    const title = (form.title || "").trim();
    if (!code || !title) { toast("Code and title required", "error"); return; }
    try {
      const api = await getDb();
      const id = editId || code.toLowerCase().replace(/[^a-z0-9]+/g, "-");
      const mapQ = (q) => ({
        prompt: (q.prompt || "").trim(),
        options: (q.options || []).map((o) => String(o || "").trim()).filter(Boolean),
        correct: Number(q.correct) || 0
      });
      const lessons = (form.lessons || []).map((l, i) => ({
        id: l.id || ("l" + Date.now().toString(36) + i),
        title: (l.title || "").trim() || ("Lesson " + (i + 1)),
        header: (l.header || "").trim(),
        subheader: (l.subheader || "").trim(),
        type: l.type || "text",
        body: (l.body || "").trim(),
        videoUrl: toEmbedVideoUrl(l.videoUrl || ""),
        ttsText: (l.ttsText || "").trim(),
        duration: (l.duration || "").trim(),
        order: Number(l.order) || (i + 1),
        checkQuestions: (l.checkQuestions || []).map(mapQ).filter((q) => q.prompt)
      }));
      const moduleQuizQuestions = (form.moduleQuizQuestions || []).map(mapQ).filter((q) => q.prompt);
      await api.setDoc(api.doc(api.db, "courses", id), {
        code,
        title,
        program: form.program || "certificate",
        sortOrder: Number(form.sortOrder) || 0,
        description: (form.description || "").trim(),
        coverUrl: (form.coverUrl || "").trim(),
        moduleQuizPassPercent: Math.min(100, Math.max(50, Number(form.moduleQuizPassPercent) || 90)),
        moduleQuizQuestions,
        lessons,
        active: form.active !== false,
        updatedAt: api.serverTimestamp(),
        ...(editId ? {} : { createdAt: api.serverTimestamp() })
      }, { merge: true });
      toast(editId ? "Course updated — live on the student portal" : "Course added — live on the student portal");
      cancel();
      load();
    } catch (ex) { toast(ex.message || "Save failed", "error"); }
  }

  async function remove(id) {
    if (!(await askConfirm("Delete this course? Existing grades stay linked by id."))) return;
    try {
      const api = await getDb();
      await api.deleteDoc(api.doc(api.db, "courses", id));
      toast("Course deleted");
      if (editId === id) cancel();
      load();
    } catch (ex) { toast(ex.message || "Delete failed", "error"); }
  }

  async function seedCertificateEighteen() {
    if (!(await askConfirm("Add 18 standard Certificate modules? Existing codes will be updated."))) return;
    const seeds = [
      "Introduction to Caregiving", "Professional Ethics & Conduct", "Infection Prevention & Control",
      "Personal Care & Hygiene", "Mobility & Safe Handling", "Nutrition & Feeding Support",
      "Vital Signs Basics", "Medication Awareness", "First Aid Awareness",
      "Communication with Clients & Families", "Dementia & Elderly Support Basics", "Mental Health Awareness",
      "Household Safety", "Documentation & Reporting", "Clinical Placement Orientation",
      "Care Planning Fundamentals", "End-of-Life Sensitivity", "Professional Practice Review"
    ];
    try {
      const api = await getDb();
      for (let i = 0; i < seeds.length; i++) {
        const code = "CERT-" + String(i + 1).padStart(2, "0");
        const id = code.toLowerCase();
        await api.setDoc(api.doc(api.db, "courses", id), {
          code, title: seeds[i], program: "certificate", sortOrder: i + 1,
          description: "", active: true, updatedAt: api.serverTimestamp(), createdAt: api.serverTimestamp()
        }, { merge: true });
      }
      toast("18 certificate modules saved");
      load();
    } catch (ex) { toast(ex.message || "Seed failed", "error"); }
  }

  const visible = rows.filter((r) => filterProg === "all" || r.program === filterProg);

  return html`
    <div>
      <h1>Modules</h1>
      <p class="muted">Programme modules students see under Courses. Hibernate a module to hide it from students without deleting grades. Certificate tracks often have many modules (e.g. 18).</p>
      ${err ? html`<p class="error">${err}</p>` : null}
      <${SubTabs}
        tabs=${[{ id: "list", label: "Records (" + rows.length + ")" }, { id: "edit", label: editId ? "Edit course" : "Add course" }]}
        active=${tab}
        onChange=${(id) => { if (id === "list") cancel(); else openNew(); }}
        menu=${tab === "list" ? [
          { label: "All programmes", checked: filterProg === "all", run: () => setFilterProg("all") },
          { label: "Certificate", checked: filterProg === "certificate", run: () => setFilterProg("certificate") },
          { label: "Diploma", checked: filterProg === "diploma", run: () => setFilterProg("diploma") },
          { label: "Higher diploma", checked: filterProg === "higher-diploma", run: () => setFilterProg("higher-diploma") },
          { label: "Seed 18 certificate modules", run: seedCertificateEighteen }
        ] : null}
      />
      ${tab === "edit" ? html`
        <form class="card" onSubmit=${save}>
          <div class="form-row"><label class="muted">Code</label><input required value=${form.code} onInput=${(e) => setForm({ ...form, code: e.target.value.toUpperCase() })} placeholder="CERT-01" /></div>
          <div class="form-row"><label class="muted">Title</label><input required value=${form.title} onInput=${(e) => setForm({ ...form, title: e.target.value })} /></div>
          <div class="form-row"><label class="muted">Programme</label>
            <select value=${form.program} onChange=${(e) => setForm({ ...form, program: e.target.value })}>
              <option value="certificate">certificate</option>
              <option value="diploma">diploma</option>
              <option value="higher-diploma">higher-diploma</option>
              <option value="licensing">licensing</option>
            </select>
          </div>
          <div class="form-row"><label class="muted">Sort order</label><input type="number" value=${form.sortOrder} onInput=${(e) => setForm({ ...form, sortOrder: e.target.value })} /></div>
          <div class="form-row"><label class="muted">Description (optional)</label><textarea rows="2" value=${form.description} onInput=${(e) => setForm({ ...form, description: e.target.value })}></textarea></div>
          <div class="form-row"><label class="muted">Cover image URL (.webp recommended)</label>
            <input value=${form.coverUrl || ""} onInput=${(e) => setForm({ ...form, coverUrl: e.target.value })} placeholder="https://…/module-cover.webp" />
            <p class="muted" style=${{ fontSize: "0.7rem", marginTop: "0.25rem" }}>Host a .webp (or png) and paste the link. Shows on the student module overview.</p>
          </div>
          <div class="form-row"><${Toggle} checked=${form.active !== false} label="Live (turn off to hibernate — hidden from students)" onChange=${(v) => setForm({ ...form, active: v })} /></div>
          <div class="card" style=${{ margin: "0.75rem 0", padding: "0.75rem" }}>
            <div style=${{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "0.5rem" }}>
              <strong style=${{ fontSize: "0.9rem" }}>Lessons (videos & reading)</strong>
              <button type="button" class="ghost" onClick=${() => setForm({
                ...form,
                lessons: [...(form.lessons || []), { id: "l" + Date.now().toString(36), title: "", type: "text", body: "", videoUrl: "", ttsText: "", duration: "", order: (form.lessons || []).length + 1 }]
              })}>+ Add lesson</button>
            </div>
            <p class="muted" style=${{ fontSize: "0.7rem", marginBottom: "0.5rem" }}>Students open the module, then each lesson. Video = paste YouTube/Vimeo embed URL. Text can use Listen (browser speech).</p>
            ${(form.lessons || []).map((l, i) => html`<div key=${l.id || i} style=${{ borderTop: "1px solid #e2e8f0", paddingTop: "0.5rem", marginTop: "0.5rem" }}>
              <div class="form-row"><label class="muted">Lesson title (list name)</label>
                <input value=${l.title} onInput=${(e) => {
                  const lessons = form.lessons.slice();
                  lessons[i] = { ...lessons[i], title: e.target.value };
                  setForm({ ...form, lessons });
                }} placeholder="Week 1 — Infection control" /></div>
              <div class="form-row"><label class="muted">Chapter header</label>
                <input value=${l.header || ""} onInput=${(e) => {
                  const lessons = form.lessons.slice();
                  lessons[i] = { ...lessons[i], header: e.target.value };
                  setForm({ ...form, lessons });
                }} placeholder="Main heading students see in the reading" /></div>
              <div class="form-row"><label class="muted">Subheader</label>
                <input value=${l.subheader || ""} onInput=${(e) => {
                  const lessons = form.lessons.slice();
                  lessons[i] = { ...lessons[i], subheader: e.target.value };
                  setForm({ ...form, lessons });
                }} placeholder="Section title under the header" /></div>
              <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.5rem" }}>
                <div><label class="muted">Type</label>
                  <select value=${l.type || "text"} onChange=${(e) => {
                    const lessons = form.lessons.slice();
                    lessons[i] = { ...lessons[i], type: e.target.value };
                    setForm({ ...form, lessons });
                  }}>
                    <option value="text">Reading / text</option>
                    <option value="video">Video</option>
                  </select></div>
                <div><label class="muted">Duration (optional)</label>
                  <input value=${l.duration || ""} onInput=${(e) => {
                    const lessons = form.lessons.slice();
                    lessons[i] = { ...lessons[i], duration: e.target.value };
                    setForm({ ...form, lessons });
                  }} placeholder="12 min" /></div>
              </div>
              ${l.type === "video" ? html`<div class="form-row"><label class="muted">Video URL (embed)</label>
                <input value=${l.videoUrl || ""} onInput=${(e) => {
                  const lessons = form.lessons.slice();
                  lessons[i] = { ...lessons[i], videoUrl: e.target.value };
                  setForm({ ...form, lessons });
                }} placeholder="https://www.youtube.com/embed/..." /></div>` : null}
              <div class="form-row"><label class="muted">Body (WhatsApp-style + structure)</label>
                <p class="muted" style=${{ fontSize: "0.72rem", margin: "0 0 0.35rem" }}>
                  Use <code># Heading</code> and <code>## Subheading</code> on their own lines.
                  Format: <code>*bold*</code> <code>_italic_</code> <code>~strike~</code>.
                  Tables: <code>| Col A | Col B |</code> rows. Add as many lessons as you need with “Add lesson”.
                </p>
                <textarea rows="8" value=${l.body || ""} onInput=${(e) => {
                  const lessons = form.lessons.slice();
                  lessons[i] = { ...lessons[i], body: e.target.value };
                  setForm({ ...form, lessons });
                }} placeholder=${`# Infection control
## Hand hygiene
Wash with *soap* for 20 seconds.

| Step | Action |
| 1 | Wet hands |
| 2 | Apply soap |`}></textarea></div>
              <div class="form-row"><label class="muted">Import from PDF (optional)</label>
                <input type="file" accept="application/pdf,.pdf" onChange=${async (e) => {
                  const file = e.target.files && e.target.files[0];
                  e.target.value = "";
                  if (!file) return;
                  try {
                    toast("Reading PDF…");
                    const text = await extractPdfToLessonText(file);
                    const lessons = form.lessons.slice();
                    const prev = lessons[i].body ? lessons[i].body + "\n\n" : "";
                    lessons[i] = { ...lessons[i], body: prev + text };
                    // first # line → header if empty
                    const hm = text.match(/^#\s+(.+)$/m);
                    const sm = text.match(/^##\s+(.+)$/m);
                    if (hm && !lessons[i].header) lessons[i].header = hm[1].trim();
                    if (sm && !lessons[i].subheader) lessons[i].subheader = sm[1].trim();
                    setForm({ ...form, lessons });
                    toast("PDF text added — review headings and tables", "ok");
                  } catch (err) {
                    console.warn(err);
                    toast("Could not read that PDF in the browser. Paste the text, or simplify the file.", "error");
                  }
                }} />
                <p class="muted" style=${{ fontSize: "0.7rem", marginTop: "0.25rem" }}>Best effort: text PDFs work better than scanned images. Always review after import.</p>
              </div>
              <div style=${{ background: "#f8fafc", borderRadius: "10px", padding: "0.5rem", marginTop: "0.35rem" }}>
                <div style=${{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <strong style=${{ fontSize: "0.8rem" }}>Quick check (optional, 3–5 Q)</strong>
                  <button type="button" class="ghost" onClick=${() => {
                    const lessons = form.lessons.slice();
                    const qs = (lessons[i].checkQuestions || []).slice();
                    if (qs.length >= 5) { toast("Max 5 questions per lesson", "error"); return; }
                    qs.push({ prompt: "", options: ["", "", "", ""], correct: 0 });
                    lessons[i] = { ...lessons[i], checkQuestions: qs };
                    setForm({ ...form, lessons });
                  }}>+ Question</button>
                </div>
                <p class="muted" style=${{ fontSize: "0.65rem" }}>Pass ≈70%. Student must pass to mark the lesson done.</p>
                ${(l.checkQuestions || []).map((q, qi) => html`<div key=${qi} class="mcq-block">
                  <label class="muted" style=${{ fontSize: "0.72rem", fontWeight: 600 }}>Question ${qi + 1}</label>
                  <input class="mcq-prompt" placeholder="Type the question students will see" value=${q.prompt || ""} onInput=${(e) => {
                    const lessons = form.lessons.slice();
                    const qs = (lessons[i].checkQuestions || []).slice();
                    qs[qi] = { ...qs[qi], prompt: e.target.value };
                    lessons[i] = { ...lessons[i], checkQuestions: qs };
                    setForm({ ...form, lessons });
                  }} />
                  <p class="muted" style=${{ fontSize: "0.68rem", margin: "0.4rem 0 0.25rem" }}>Answer choices — select the circle next to the <strong>correct</strong> answer</p>
                  ${(q.options || ["", "", "", ""]).map((opt, oi) => html`<label class="mcq-option" key=${oi}>
                    <input type="radio" name=${"lq-" + i + "-" + qi} checked=${Number(q.correct) === oi} onChange=${() => {
                      const lessons = form.lessons.slice();
                      const qs = (lessons[i].checkQuestions || []).slice();
                      qs[qi] = { ...qs[qi], correct: oi };
                      lessons[i] = { ...lessons[i], checkQuestions: qs };
                      setForm({ ...form, lessons });
                    }} />
                    <span class="mcq-letter">${String.fromCharCode(65 + oi)}</span>
                    <input class="mcq-option-input" placeholder=${"Choice " + String.fromCharCode(65 + oi)} value=${opt} onInput=${(e) => {
                      const lessons = form.lessons.slice();
                      const qs = (lessons[i].checkQuestions || []).slice();
                      const options = (qs[qi].options || ["", "", "", ""]).slice();
                      options[oi] = e.target.value;
                      qs[qi] = { ...qs[qi], options };
                      lessons[i] = { ...lessons[i], checkQuestions: qs };
                      setForm({ ...form, lessons });
                    }} />
                    ${Number(q.correct) === oi ? html`<span class="mcq-correct-tag">Correct</span>` : null}
                  </label>`)}
                  <button type="button" class="ghost" style=${{ color: "#dc2626", fontSize: "0.75rem", marginTop: "0.35rem" }} onClick=${() => {
                    const lessons = form.lessons.slice();
                    const qs = (lessons[i].checkQuestions || []).slice();
                    qs.splice(qi, 1);
                    lessons[i] = { ...lessons[i], checkQuestions: qs };
                    setForm({ ...form, lessons });
                  }}>Remove question</button>
                </div>`)}
              </div>
              <button type="button" class="ghost" style=${{ color: "#dc2626" }} onClick=${() => {
                const lessons = form.lessons.slice();
                lessons.splice(i, 1);
                setForm({ ...form, lessons });
              }}>Remove lesson</button>
            </div>`)}
          </div>
          <div class="card" style=${{ margin: "0.75rem 0", padding: "0.75rem" }}>
            <div style=${{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <strong style=${{ fontSize: "0.9rem" }}>Module quiz (end of module)</strong>
              <button type="button" class="ghost" onClick=${() => {
                const qs = (form.moduleQuizQuestions || []).slice();
                qs.push({ prompt: "", options: ["", "", "", ""], correct: 0 });
                setForm({ ...form, moduleQuizQuestions: qs });
              }}>+ Question</button>
            </div>
            <p class="muted" style=${{ fontSize: "0.7rem" }}>Required after all lessons. High pass mark (default 90%).</p>
            <div class="form-row"><label class="muted">Pass mark %</label>
              <input type="number" min="50" max="100" value=${form.moduleQuizPassPercent || "90"}
                onInput=${(e) => setForm({ ...form, moduleQuizPassPercent: e.target.value })} /></div>
            ${(form.moduleQuizQuestions || []).map((q, qi) => html`<div key=${qi} class="mcq-block">
              <label class="muted" style=${{ fontSize: "0.72rem", fontWeight: 600 }}>Module question ${qi + 1}</label>
              <input class="mcq-prompt" placeholder="Type the question" value=${q.prompt || ""} onInput=${(e) => {
                const qs = form.moduleQuizQuestions.slice();
                qs[qi] = { ...qs[qi], prompt: e.target.value };
                setForm({ ...form, moduleQuizQuestions: qs });
              }} />
              <p class="muted" style=${{ fontSize: "0.68rem", margin: "0.4rem 0 0.25rem" }}>Select the circle next to the correct answer</p>
              ${(q.options || ["", "", "", ""]).map((opt, oi) => html`<label class="mcq-option" key=${oi}>
                <input type="radio" name=${"mq-" + qi} checked=${Number(q.correct) === oi} onChange=${() => {
                  const qs = form.moduleQuizQuestions.slice();
                  qs[qi] = { ...qs[qi], correct: oi };
                  setForm({ ...form, moduleQuizQuestions: qs });
                }} />
                <span class="mcq-letter">${String.fromCharCode(65 + oi)}</span>
                <input class="mcq-option-input" placeholder=${"Choice " + String.fromCharCode(65 + oi)} value=${opt} onInput=${(e) => {
                  const qs = form.moduleQuizQuestions.slice();
                  const options = (qs[qi].options || ["", "", "", ""]).slice();
                  options[oi] = e.target.value;
                  qs[qi] = { ...qs[qi], options };
                  setForm({ ...form, moduleQuizQuestions: qs });
                }} />
                ${Number(q.correct) === oi ? html`<span class="mcq-correct-tag">Correct</span>` : null}
              </label>`)}
              <button type="button" class="ghost" style=${{ color: "#dc2626", fontSize: "0.75rem", marginTop: "0.35rem" }} onClick=${() => {
                const qs = form.moduleQuizQuestions.slice();
                qs.splice(qi, 1);
                setForm({ ...form, moduleQuizQuestions: qs });
              }}>Remove question</button>
            </div>`)}
          </div>
          <div style=${{ display: "flex", gap: "0.5rem", flexWrap: "wrap" }}>
            <button class="primary" type="submit">Save course</button>
            <button class="ghost" type="button" onClick=${cancel}>Cancel</button>
            ${editId ? html`<button class="ghost" type="button" style=${{ color: "#dc2626" }} onClick=${() => remove(editId)}>Delete</button>` : null}
          </div>
        </form>
      ` : html`
        <div style=${{ marginBottom: "0.75rem", display: "flex", gap: "0.5rem", flexWrap: "wrap" }}>
          <button class="primary" type="button" onClick=${openNew}>+ Add course</button>
          <button class="ghost" type="button" onClick=${seedCertificateEighteen}>Seed 18 certificate modules</button>
        </div>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Code</th><th>Title</th><th>Programme</th><th>Order</th><th>Status</th><th></th></tr></thead>
            <tbody>
              ${visible.length === 0 ? html`<tr><td colspan="6" class="muted">No courses yet.</td></tr>` : null}
              ${visible.map((r) => html`
                <tr key=${r.id}>
                  <td><code>${r.code || r.id}</code></td>
                  <td>${r.title || "—"}</td>
                  <td>${r.program || "—"}</td>
                  <td>${r.sortOrder != null ? r.sortOrder : "—"}</td>
                  <td><${Badge} status=${r.active === false ? "inactive" : "active"} /></td>
                  <td style=${{ whiteSpace: "nowrap" }}>
                    <button class="ghost" type="button" onClick=${() => openEdit(r)}>Edit</button>
                    <button class="ghost" type="button" onClick=${async () => {
                      try {
                        const api = await getDb();
                        const next = r.active === false;
                        await api.setDoc(api.doc(api.db, "courses", r.id), { active: next, hibernated: !next, updatedAt: api.serverTimestamp() }, { merge: true });
                        toast(next ? "Module restored" : "Module hibernated");
                        load();
                      } catch (ex) { toast(ex.message || "Failed", "error"); }
                    }}>${r.active === false ? "Restore" : "Hibernate"}</button>
                    <button class="ghost" type="button" onClick=${() => remove(r.id)}>Delete</button>
                  </td>
                </tr>
              `)}
            </tbody>
          </table>
        </div>
      `}
    </div>
  `;
}


function AssessmentsPanel() {
  const empty = {
    title: "", type: "test", moduleId: "", program: "certificate",
    dueDate: "", maxScore: "100", description: "", active: true,
    timerMinutes: "30", antiCheat: true, showReview: false, questions: []
  };
  const [rows, setRows] = useState([]);
  const [modules, setModules] = useState([]);
  const [form, setForm] = useState({ ...empty });
  const [editId, setEditId] = useState(null);
  const [tab, setTab] = useState("list");
  const [filterType, setFilterType] = useState("all");
  const [err, setErr] = useState("");

  async function load() {
    try {
      const api = await getDb();
      const [as, cs] = await Promise.all([
        api.getDocs(api.collection(api.db, "assessments")),
        api.getDocs(api.collection(api.db, "courses"))
      ]);
      const list = []; as.forEach((d) => list.push({ id: d.id, ...d.data() }));
      list.sort((a, b) => String(b.updatedAt?.toMillis?.() || "").localeCompare(String(a.updatedAt?.toMillis?.() || "")));
      const mods = []; cs.forEach((d) => mods.push({ id: d.id, ...d.data() }));
      mods.sort((a, b) => String(a.code || "").localeCompare(String(b.code || "")));
      setRows(list); setModules(mods);
    } catch (e) { setErr(e.message || String(e)); }
  }
  useEffect(() => { load(); }, []);

  function openNew() { setEditId(null); setForm({ ...empty }); setTab("edit"); }
  function openEdit(row) {
    setEditId(row.id);
    setForm({
      title: row.title || "",
      type: row.type || "test",
      moduleId: row.moduleId || "",
      program: row.program || "certificate",
      dueDate: row.dueDate || "",
      maxScore: String(row.maxScore != null ? row.maxScore : 100),
      description: row.description || "",
      active: row.active !== false,
      timerMinutes: String(row.timerMinutes != null ? row.timerMinutes : 30),
      antiCheat: row.antiCheat !== false,
      showReview: row.showReview === true,
      questions: Array.isArray(row.questions) ? row.questions.map((q, i) => ({
        prompt: q.prompt || q.text || "",
        options: Array.isArray(q.options) ? q.options.slice() : ["", "", "", ""],
        correct: q.correct != null ? q.correct : 0
      })) : []
    });
    setTab("edit");
  }
  function cancel() { setEditId(null); setForm({ ...empty }); setTab("list"); }

  async function save(e) {
    e.preventDefault();
    const title = (form.title || "").trim();
    if (!title) { toast("Title required", "error"); return; }
    try {
      const api = await getDb();
      const id = editId || ("a_" + Date.now().toString(36));
      const mod = modules.find((m) => m.id === form.moduleId);
      const questions = (form.questions || []).map((q) => ({
        prompt: (q.prompt || "").trim(),
        options: (q.options || []).map((o) => String(o || "").trim()).filter(Boolean),
        correct: Number(q.correct) || 0
      })).filter((q) => q.prompt);
      await api.setDoc(api.doc(api.db, "assessments", id), {
        title,
        type: form.type || "test",
        moduleId: form.moduleId || "",
        moduleCode: mod ? (mod.code || "") : "",
        moduleTitle: mod ? (mod.title || "") : "",
        program: form.program || "certificate",
        dueDate: form.dueDate || "",
        maxScore: Number(form.maxScore) || 100,
        timerMinutes: Number(form.timerMinutes) || 0,
        antiCheat: form.antiCheat !== false,
        showReview: form.showReview === true,
        questions,
        description: (form.description || "").trim(),
        active: form.active !== false,
        hibernated: form.active === false,
        updatedAt: api.serverTimestamp(),
        ...(editId ? {} : { createdAt: api.serverTimestamp() })
      }, { merge: true });
      toast(editId ? "Saved" : "Created");
      cancel();
      load();
    } catch (ex) { toast(ex.message || "Save failed", "error"); }
  }

  async function hibernate(row) {
    try {
      const api = await getDb();
      const next = row.active === false;
      await api.setDoc(api.doc(api.db, "assessments", row.id), {
        active: next, hibernated: !next, updatedAt: api.serverTimestamp()
      }, { merge: true });
      toast(next ? "Restored" : "Hibernated");
      load();
    } catch (ex) { toast(ex.message || "Failed", "error"); }
  }

  async function remove(id) {
    if (!(await askConfirm("Delete this assessment permanently?"))) return;
    try {
      const api = await getDb();
      await api.deleteDoc(api.doc(api.db, "assessments", id));
      toast("Deleted");
      if (editId === id) cancel();
      load();
    } catch (ex) { toast(ex.message || "Delete failed", "error"); }
  }

  const visible = rows.filter((r) => filterType === "all" || r.type === filterType);
  const typeLabel = { test: "Test", assignment: "Assignment", exam: "Exam" };

  return html`
    <div>
      <h1>Tests & assignments</h1>
      <p class="muted">Create tests, assignments, and exams. Hibernate to hide from the student portal without deleting. Ready for the next phase of the portal.</p>
      ${err ? html`<p class="error">${err}</p>` : null}
      <${SubTabs}
        tabs=${[{ id: "list", label: "Records (" + rows.length + ")" }, { id: "edit", label: editId ? "Edit" : "Add new" }]}
        active=${tab}
        onChange=${(id) => { if (id === "list") cancel(); else openNew(); }}
        menu=${tab === "list" ? [
          { label: "All types", checked: filterType === "all", run: () => setFilterType("all") },
          { label: "Tests", checked: filterType === "test", run: () => setFilterType("test") },
          { label: "Assignments", checked: filterType === "assignment", run: () => setFilterType("assignment") },
          { label: "Exams", checked: filterType === "exam", run: () => setFilterType("exam") }
        ] : null}
      />
      ${tab === "edit" ? html`
        <form class="card" onSubmit=${save}>
          <div class="form-row"><label class="muted">Title</label><input required value=${form.title} onInput=${(e) => setForm({ ...form, title: e.target.value })} placeholder="Test #2 — Infection control" /></div>
          <div class="form-row"><label class="muted">Type</label>
            <select value=${form.type} onChange=${(e) => setForm({ ...form, type: e.target.value })}>
              <option value="test">Test</option>
              <option value="assignment">Assignment</option>
              <option value="exam">Exam</option>
            </select>
          </div>
          <div class="form-row"><label class="muted">Linked module (optional)</label>
            <select value=${form.moduleId} onChange=${(e) => setForm({ ...form, moduleId: e.target.value })}>
              <option value="">— none —</option>
              ${modules.map((m) => html`<option key=${m.id} value=${m.id}>${m.code} — ${m.title}</option>`)}
            </select>
          </div>
          <div class="form-row"><label class="muted">Programme</label>
            <select value=${form.program} onChange=${(e) => setForm({ ...form, program: e.target.value })}>
              <option value="certificate">certificate</option>
              <option value="diploma">diploma</option>
              <option value="higher-diploma">higher-diploma</option>
            </select>
          </div>
          <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.5rem" }}>
            <div><label class="muted">Due date</label><input type="date" value=${form.dueDate} onInput=${(e) => setForm({ ...form, dueDate: e.target.value })} /></div>
            <div><label class="muted">Max score</label><input type="number" value=${form.maxScore} onInput=${(e) => setForm({ ...form, maxScore: e.target.value })} /></div>
          </div>
          <div class="form-row"><label class="muted">Description</label><textarea rows="2" value=${form.description} onInput=${(e) => setForm({ ...form, description: e.target.value })}></textarea></div>
          <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.5rem" }}>
            <div><label class="muted">Timer (minutes, 0 = none)</label>
              <input type="number" min="0" value=${form.timerMinutes} onInput=${(e) => setForm({ ...form, timerMinutes: e.target.value })} /></div>
            <div style=${{ paddingTop: "1.25rem" }}>
              <${Toggle} checked=${form.antiCheat !== false} label="Anti-cheat (block copy, warn on tab switch)" onChange=${(v) => setForm({ ...form, antiCheat: v })} />
              <${Toggle} checked=${form.showReview === true} label="Let students review answers (see which were wrong and ask a query)" onChange=${(v) => setForm({ ...form, showReview: v })} />
            </div>
          </div>
          <div class="card" style=${{ margin: "0.75rem 0", padding: "0.75rem" }}>
            <div style=${{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "0.5rem" }}>
              <strong style=${{ fontSize: "0.9rem" }}>Objective questions</strong>
              <button type="button" class="ghost" onClick=${() => setForm({
                ...form,
                questions: [...(form.questions || []), { prompt: "", options: ["", "", "", ""], correct: 0 }]
              })}>+ Add question</button>
            </div>
            ${(form.questions || []).map((q, qi) => html`<div key=${qi} class="mcq-block">
              <label class="muted" style=${{ fontSize: "0.72rem", fontWeight: 600 }}>Question ${qi + 1}</label>
              <textarea class="mcq-prompt" rows="2" value=${q.prompt} onInput=${(e) => {
                const questions = form.questions.slice();
                questions[qi] = { ...questions[qi], prompt: e.target.value };
                setForm({ ...form, questions });
              }} placeholder="What is the first step in hand hygiene?" />
              <p class="muted" style=${{ fontSize: "0.68rem", margin: "0.4rem 0 0.25rem" }}>Select the circle next to the correct answer</p>
              ${(q.options || ["", "", "", ""]).map((opt, oi) => html`<label class="mcq-option" key=${oi}>
                <input type="radio" name=${"correct-" + qi} checked=${Number(q.correct) === oi}
                  onChange=${() => {
                    const questions = form.questions.slice();
                    questions[qi] = { ...questions[qi], correct: oi };
                    setForm({ ...form, questions });
                  }} />
                <span class="mcq-letter">${String.fromCharCode(65 + oi)}</span>
                <input class="mcq-option-input" value=${opt} placeholder=${"Choice " + String.fromCharCode(65 + oi)} onInput=${(e) => {
                  const questions = form.questions.slice();
                  const options = (questions[qi].options || ["", "", "", ""]).slice();
                  options[oi] = e.target.value;
                  questions[qi] = { ...questions[qi], options };
                  setForm({ ...form, questions });
                }} />
                ${Number(q.correct) === oi ? html`<span class="mcq-correct-tag">Correct</span>` : null}
              </label>`)}
              <button type="button" class="ghost" style=${{ color: "#dc2626", fontSize: "0.75rem", marginTop: "0.35rem" }} onClick=${() => {
                const questions = form.questions.slice();
                questions.splice(qi, 1);
                setForm({ ...form, questions });
              }}>Remove question</button>
            </div>`)}
          </div>
          <div class="form-row"><${Toggle} checked=${form.active !== false} label="Live (off = hibernated)" onChange=${(v) => setForm({ ...form, active: v })} /></div>
          <div style=${{ display: "flex", gap: "0.5rem", flexWrap: "wrap" }}>
            <button class="primary" type="submit">Save</button>
            <button class="ghost" type="button" onClick=${cancel}>Cancel</button>
            ${editId ? html`<button class="ghost" type="button" style=${{ color: "#dc2626" }} onClick=${() => remove(editId)}>Delete</button>` : null}
          </div>
        </form>
      ` : html`
        <div style=${{ marginBottom: "0.75rem" }}>
          <button class="primary" type="button" onClick=${openNew}>+ Add test, assignment, or exam</button>
        </div>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Type</th><th>Title</th><th>Module</th><th>Due</th><th>Status</th><th></th></tr></thead>
            <tbody>
              ${visible.length === 0 ? html`<tr><td colspan="6" class="muted">None yet. Add a test or assignment when you are ready.</td></tr>` : null}
              ${visible.map((r) => html`
                <tr key=${r.id}>
                  <td>${typeLabel[r.type] || r.type}</td>
                  <td>${r.title || "—"}</td>
                  <td>${r.moduleCode || "—"}</td>
                  <td>${r.dueDate || "—"}</td>
                  <td><${Badge} status=${r.active === false ? "inactive" : "active"} /></td>
                  <td style=${{ whiteSpace: "nowrap" }}>
                    <button class="ghost" type="button" onClick=${() => openEdit(r)}>Edit</button>
                    <button class="ghost" type="button" onClick=${() => hibernate(r)}>${r.active === false ? "Restore" : "Hibernate"}</button>
                    <button class="ghost" type="button" onClick=${() => remove(r.id)}>Delete</button>
                  </td>
                </tr>
              `)}
            </tbody>
          </table>
        </div>
      `}
    </div>
  `;
}


function gradeTimestampMs(g) {
  const t = g.publishedAt || g.createdAt || g.updatedAt;
  if (!t) return 0;
  if (typeof t.toMillis === "function") return t.toMillis();
  if (typeof t === "number") return t;
  const d = new Date(t).getTime();
  return Number.isNaN(d) ? 0 : d;
}
function gradeEditable(g, days) {
  const ms = gradeTimestampMs(g);
  if (!ms) return true; // no timestamp yet — allow once
  return (Date.now() - ms) <= (days * 24 * 60 * 60 * 1000);
}
const GRADE_EDIT_DAYS = 14;

const DEFAULT_GRADE_COMPONENTS = [
  { key: "ca", label: "CA", max: 20 },
  { key: "test", label: "Test", max: 15 },
  { key: "exam", label: "Exam", max: 65 },
  { key: "attendance", label: "Attendance %", max: 0 }
];
const numOrNull = (v) => (v === "" || v == null || isNaN(Number(v)) ? null : Number(v));
function uniqueColKey() { return "col_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 5); }
function valsFrom(g, defs) {
  const out = {};
  const comp = (g && g.components) || {};
  (defs || []).forEach((c) => {
    const v = comp[c.key] != null ? comp[c.key] : (g ? g[c.key] : null);
    if (v != null) out[c.key] = String(v);
  });
  return out;
}
function bandOf(avg) {
  if (avg == null) return "—";
  if (avg >= 70) return "A";
  if (avg >= 60) return "B";
  if (avg >= 50) return "C";
  if (avg >= 45) return "D";
  if (avg >= 40) return "E";
  return "F";
}

function studentYear(s) {
  const m = String(s.cohort || "").match(/(19|20)\d{2}/);
  if (m) return m[0];
  const sd = s.startDate;
  let d = null;
  if (sd && sd.toDate) d = sd.toDate();
  else if (sd) { const t = new Date(sd); if (!isNaN(t.getTime())) d = t; }
  return d ? String(d.getFullYear()) : "";
}
const PROGRAMME_CHOICES = [
  { key: "all", label: "All programmes" },
  { key: "certificate", label: "Certificate" },
  { key: "diploma", label: "Diploma" },
  { key: "higher-diploma", label: "Higher diploma" },
  { key: "licensing", label: "Licensing" }
];

function GradesPanel() {
  const [progFilter, setProgFilter] = useState("all");
  const [yearFilter, setYearFilter] = useState("all");
  const [cohortFilter, setCohortFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [students, setStudents] = useState([]);
  const [courses, setCourses] = useState([]);
  const [rows, setRows] = useState([]);
  const [studentId, setStudentId] = useState("");
  const [courseId, setCourseId] = useState("");
  const [grade, setGrade] = useState("");
  const [score, setScore] = useState("");
  const [remark, setRemark] = useState("");
  const [comps, setComps] = useState(DEFAULT_GRADE_COMPONENTS);
  const [vals, setVals] = useState({});
  const [published, setPublished] = useState(true);
  const [err, setErr] = useState("");
  const [filterStudent, setFilterStudent] = useState("");
  // Re-entering a result: load what is already saved for this student and module
  useEffect(() => {
    if (!studentId || !courseId) return;
    (async () => {
      try {
        const api = await getDb();
        const snap = await api.getDoc(api.doc(api.db, "grades", studentId + "__" + courseId));
        if (snap.exists()) {
          const g = snap.data();
          setGrade(g.grade || "");
          setScore(g.score != null ? String(g.score) : "");
          setRemark(g.remark || "");
          setVals(valsFrom(g, comps));
          setPublished(g.published !== false);
        } else {
          setGrade(""); setScore(""); setRemark(""); setVals({});
        }
      } catch (_) {}
    })();
  }, [studentId, courseId]);

  async function load() {
    try {
      const api = await getDb();
      const [ss, cs, gs] = await Promise.all([
        api.getDocs(api.collection(api.db, "students")),
        api.getDocs(api.collection(api.db, "courses")),
        api.getDocs(api.collection(api.db, "grades"))
      ]);
      const sl = []; ss.forEach((d) => { if (d.data().trashed !== true) sl.push({ id: d.id, ...d.data() }); });
      sl.sort((a, b) => String(a.fullLegalName || a.fullName || "").localeCompare(String(b.fullLegalName || b.fullName || "")));
      const cl = []; cs.forEach((d) => cl.push({ id: d.id, ...d.data() }));
      cl.sort((a, b) => (Number(a.sortOrder) || 0) - (Number(b.sortOrder) || 0));
      const gl = []; gs.forEach((d) => gl.push({ id: d.id, ...d.data() }));
      gl.sort((a, b) => String(b.updatedAt?.toMillis?.() || b.updatedAt || "").localeCompare(String(a.updatedAt?.toMillis?.() || a.updatedAt || "")));
      setStudents(sl); setCourses(cl); setRows(gl);
    } catch (e) { setErr(e.message || String(e)); }
  }
  useEffect(() => { load(); }, []);

  useEffect(() => {
    (async () => {
      try {
        const api = await getDb();
        const snap = await api.getDoc(api.doc(api.db, "siteContent", "portalSettings"));
        const defs = snap.exists() && Array.isArray(snap.data().gradeComponents) ? snap.data().gradeComponents : null;
        if (defs && defs.length) setComps(defs.map((c) => ({ key: c.key, label: c.label || c.key, max: Number(c.max) || 0 })));
      } catch (_) {}
    })();
  }, []);

  function addColumn() {
    setComps([...comps, { key: uniqueColKey(), label: "New column", max: 0 }]);
  }
  function updateColumn(i, patch) {
    setComps(comps.map((c, k) => (k === i ? { ...c, ...patch } : c)));
  }
  function removeColumn(i) {
    setComps(comps.filter((c, k) => k !== i));
  }
  async function saveColumns() {
    try {
      const api = await getDb();
      await api.setDoc(api.doc(api.db, "siteContent", "portalSettings"), {
        gradeComponents: comps.map((c) => ({ key: c.key, label: (c.label || "").trim() || c.key, max: Number(c.max) || 0 }))
      }, { merge: true });
      toast("Column layout saved. Every transcript now uses it.", "ok");
    } catch (e) { toast(e.message || String(e), "error"); }
  }
  function componentValues() {
    const out = {};
    comps.forEach((c) => { const n = numOrNull(vals[c.key]); if (n != null) out[c.key] = n; });
    return out;
  }

  const selectedStudent = students.find((s) => s.id === studentId);
  const yearOptions = Array.from(new Set(students.map(studentYear).filter(Boolean))).sort().reverse();
  const cohortOptions = Array.from(new Set(students.map((s) => s.cohort).filter(Boolean))).sort();
  const q = search.trim().toLowerCase();
  const filteredStudents = students.filter((s) =>
    (progFilter === "all" || (s.program || "") === progFilter) &&
    (yearFilter === "all" || studentYear(s) === yearFilter) &&
    (cohortFilter === "all" || s.cohort === cohortFilter) &&
    (!q || [s.fullLegalName, s.fullName, s.regNumber, s.email].filter(Boolean).join(" ").toLowerCase().includes(q))
  );
  const studentOptions = selectedStudent && !filteredStudents.includes(selectedStudent) ? [selectedStudent, ...filteredStudents] : filteredStudents;
  const programCourses = courses.filter((c) =>
    c.active !== false &&
    (progFilter === "all" || c.program === progFilter) &&
    (!selectedStudent || !selectedStudent.program || selectedStudent.program === "all" || c.program === selectedStudent.program)
  );

  async function save(e) {
    e.preventDefault();
    if (!studentId || !courseId) { toast("Pick student and course", "error"); return; }
    if (!grade.trim() && score === "") { toast("Enter a grade or score", "error"); return; }
    const st = students.find((s) => s.id === studentId);
    const co = courses.find((c) => c.id === courseId);
    if (!st || !co) return;
    if (st.transcriptLocked === true) {
      if (!(await askConfirm("This student's transcript is locked. Save grade anyway?"))) return;
    }
    try {
      const api = await getDb();
      const id = studentId + "__" + courseId;
      const prev = await api.getDoc(api.doc(api.db, "grades", id));
      if (prev.exists()) {
        const prevData = { id, ...prev.data() };
        if (!gradeEditable(prevData, GRADE_EDIT_DAYS)) {
          toast("This result is locked after " + GRADE_EDIT_DAYS + " days and cannot be changed.", "error");
          return;
        }
      }
      await api.setDoc(api.doc(api.db, "grades", id), {
        studentId,
        studentName: st.fullLegalName || st.fullName || "",
        studentEmail: (st.email || "").toLowerCase(),
        regNumber: st.regNumber || "",
        courseId,
        courseCode: co.code || "",
        courseTitle: co.title || "",
        program: co.program || st.program || "",
        grade: (grade || "").trim().toUpperCase(),
        score: score === "" ? null : Number(score),
        remark: (remark || "").trim(),
        components: componentValues(),
        componentDefs: comps.map((c) => ({ key: c.key, label: (c.label || "").trim() || c.key, max: Number(c.max) || 0 })),
        ca: numOrNull(vals.ca),
        test: numOrNull(vals.test),
        exam: numOrNull(vals.exam),
        attendance: numOrNull(vals.attendance),
        published: published !== false,
        updatedAt: api.serverTimestamp(),
        ...(published !== false ? { publishedAt: api.serverTimestamp() } : {})
      }, { merge: true });
      // Ensure createdAt exists only on first write
      try {
        const existing = await api.getDoc(api.doc(api.db, "grades", id));
        if (!existing.exists() || !existing.data().createdAt) {
          await api.setDoc(api.doc(api.db, "grades", id), { createdAt: api.serverTimestamp() }, { merge: true });
        }
      } catch (_) {}
      toast("Result saved — editable for " + GRADE_EDIT_DAYS + " days");
      setGrade(""); setScore(""); setRemark("");
      load();
    } catch (ex) { toast(ex.message || "Save failed", "error"); }
  }

  async function remove(id) {
    const row = rows.find((r) => r.id === id);
    if (row && !gradeEditable(row, GRADE_EDIT_DAYS)) {
      toast("This result is past the " + GRADE_EDIT_DAYS + "-day edit window and cannot be deleted.", "error");
      return;
    }
    if (!(await askConfirm("Delete this result?"))) return;
    try {
      const api = await getDb();
      await api.deleteDoc(api.doc(api.db, "grades", id));
      toast("Deleted");
      load();
    } catch (ex) { toast(ex.message || "Failed", "error"); }
  }

  function loadIntoForm(r) {
    if (!gradeEditable(r, GRADE_EDIT_DAYS)) {
      toast("Past the " + GRADE_EDIT_DAYS + "-day window — view only.", "error");
      return;
    }
    setStudentId(r.studentId || "");
    setCourseId(r.courseId || "");
    setGrade(r.grade || "");
    setScore(r.score != null ? String(r.score) : "");
    setRemark(r.remark || "");
    setPublished(r.published !== false);
    toast("Loaded for edit — save within the " + GRADE_EDIT_DAYS + "-day window", "ok");
  }

  const shown = rows.filter((r) => {
    if (!filterStudent) return true;
    const q = filterStudent.toLowerCase();
    return String(r.studentName || "").toLowerCase().includes(q) || String(r.regNumber || "").toLowerCase().includes(q) || String(r.studentEmail || "").toLowerCase().includes(q);
  });

  return html`
    <div>
      <h1>Results / grades</h1>
      <p class="muted">Enter grades per student and course. Published results appear on the student portal (grades + transcript). Each result stays <strong>editable for ${GRADE_EDIT_DAYS} days</strong> from first save, then becomes locked.</p>
      ${err ? html`<p class="error">${err}</p>` : null}
      <form class="card" onSubmit=${save} style=${{ marginBottom: "1rem" }}>
        <div class="form-row"><label class="muted">Programme</label>
          <div class="filter-chips">
            ${PROGRAMME_CHOICES.map((p) => html`<button type="button" key=${p.key} class=${"chip" + (progFilter === p.key ? " on" : "")} onClick=${() => { setProgFilter(p.key); setCourseId(""); }}>${p.label}</button>`)}
          </div>
        </div>
        <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.5rem" }}>
          <div><label class="muted">Year</label>
            <select value=${yearFilter} onChange=${(e) => setYearFilter(e.target.value)}>
              <option value="all">All years</option>
              ${yearOptions.map((y) => html`<option key=${y} value=${y}>${y}</option>`)}
            </select></div>
          <div><label class="muted">Cohort</label>
            <select value=${cohortFilter} onChange=${(e) => setCohortFilter(e.target.value)}>
              <option value="all">All cohorts</option>
              ${cohortOptions.map((c) => html`<option key=${c} value=${c}>${c}</option>`)}
            </select></div>
        </div>
        <div class="form-row"><label class="muted">Search by name, reg number or email</label>
          <input type="search" placeholder="Type to narrow the list…" value=${search} onInput=${(e) => setSearch(e.target.value)} />
        </div>
        <div class="form-row"><label class="muted">Student (${filteredStudents.length} match${filteredStudents.length === 1 ? "" : "es"})</label>
          <select required value=${studentId} onChange=${(e) => { setStudentId(e.target.value); setCourseId(""); }}>
            <option value="">Select student…</option>
            ${studentOptions.map((s) => html`<option key=${s.id} value=${s.id}>${s.fullLegalName || s.fullName || s.email} · ${s.regNumber || "no reg"} · ${s.cohort || studentYear(s) || ""} · ${s.program || ""}</option>`)}
          </select>
        </div>
        <div class="form-row"><label class="muted">Course</label>
          <select required value=${courseId} onChange=${(e) => setCourseId(e.target.value)}>
            <option value="">Select course…</option>
            ${programCourses.map((c) => html`<option key=${c.id} value=${c.id}>${c.code} — ${c.title} (${c.program})</option>`)}
          </select>
        </div>
        <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.5rem" }}>
          <div><label class="muted">Grade (A, B, C…)</label><input value=${grade} onInput=${(e) => setGrade(e.target.value)} placeholder="A" /></div>
          <div><label class="muted">Score (optional)</label><input type="number" value=${score} onInput=${(e) => setScore(e.target.value)} placeholder="85" /></div>
        </div>
        <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(110px, 1fr))", gap: "0.5rem" }}>
          ${comps.map((c) => html`<div key=${c.key}>
            <label class="muted">${c.label}${c.max ? " / " + c.max : ""}</label>
            <input type="number" value=${vals[c.key] != null ? vals[c.key] : ""} onInput=${(e) => setVals({ ...vals, [c.key]: e.target.value })} />
          </div>`)}
        </div>
        <details style=${{ margin: "0.5rem 0 0.75rem" }}>
          <summary class="muted" style=${{ cursor: "pointer" }}>Edit result columns (applies to every transcript)</summary>
          <div style=${{ marginTop: "0.5rem" }}>
            ${comps.map((c, i) => html`<div key=${c.key} class="form-row" style=${{ display: "grid", gridTemplateColumns: "2fr 1fr auto", gap: "0.5rem", alignItems: "end" }}>
              <div><label class="muted">Column name</label><input value=${c.label} onInput=${(e) => updateColumn(i, { label: e.target.value })} /></div>
              <div><label class="muted">Max</label><input type="number" value=${c.max} onInput=${(e) => updateColumn(i, { max: e.target.value })} /></div>
              <button class="ghost" type="button" onClick=${() => removeColumn(i)}>Remove</button>
            </div>`)}
            <div style=${{ display: "flex", gap: "0.5rem", flexWrap: "wrap", marginTop: "0.5rem" }}>
              <button class="ghost" type="button" onClick=${addColumn}>+ Add column</button>
              <button class="primary" type="button" onClick=${saveColumns}>Save column layout</button>
            </div>
            <p class="muted" style=${{ fontSize: "0.75rem", margin: "0.5rem 0 0" }}>Removing a column hides it from new entries. Results already saved keep their values.</p>
          </div>
        </details>
        <div class="form-row"><label class="muted">Remark</label><input value=${remark} onInput=${(e) => setRemark(e.target.value)} /></div>
        <div class="form-row"><${Toggle} checked=${published} label="Published (student can see)" onChange=${setPublished} /></div>
        <button class="primary" type="submit">Save result</button>
      </form>
      <div class="form-row"><input placeholder="Filter by student name, reg, email…" value=${filterStudent} onInput=${(e) => setFilterStudent(e.target.value)} /></div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Student</th><th>Course</th><th>Grade</th><th>Score</th><th>Status</th><th></th></tr></thead>
          <tbody>
            ${shown.length === 0 ? html`<tr><td colspan="6" class="muted">No results yet.</td></tr>` : null}
            ${shown.map((r) => {
              const open = gradeEditable(r, GRADE_EDIT_DAYS);
              const ms = gradeTimestampMs(r);
              const daysLeft = ms ? Math.max(0, Math.ceil((GRADE_EDIT_DAYS * 86400000 - (Date.now() - ms)) / 86400000)) : GRADE_EDIT_DAYS;
              return html`
              <tr key=${r.id}>
                <td>${r.studentName || "—"}<br/><span class="muted" style=${{ fontSize: "0.75rem" }}>${r.regNumber || r.studentEmail || ""}</span></td>
                <td><code>${r.courseCode || ""}</code> ${r.courseTitle || ""}</td>
                <td><strong>${r.grade || "—"}</strong></td>
                <td>${r.score != null ? r.score : "—"}</td>
                <td>
                  <${Badge} status=${r.published === false ? "inactive" : "active"} />
                  <br/><span class="muted" style=${{ fontSize: "0.7rem" }}>${open ? (daysLeft + "d left to edit") : "Locked"}</span>
                </td>
                <td style=${{ whiteSpace: "nowrap" }}>
                  <button class="ghost" type="button" disabled=${!open} onClick=${() => loadIntoForm(r)}>Edit</button>
                  <button class="ghost" type="button" disabled=${!open} onClick=${() => remove(r.id)}>Delete</button>
                </td>
              </tr>`;
            })}
          </tbody>
        </table>
      </div>
    </div>
  `;
}



function SchedulePanel() {
  const empty = { day: "Monday", startTime: "09:00", endTime: "11:00", title: "", room: "", tutor: "", program: "certificate", active: true, sectionType: "Live class", courseId: "" };
  const [rows, setRows] = useState([]);
  const [form, setForm] = useState(empty);
  const [editId, setEditId] = useState(null);
  const [tab, setTab] = useState("list");
  const [err, setErr] = useState("");
  const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
  const [courses, setCourses] = useState([]);
  useEffect(() => {
    (async () => {
      try {
        const api = await getDb();
        const snap = await api.getDocs(api.collection(api.db, "courses"));
        const cl = []; snap.forEach((d) => { if (d.data().active !== false) cl.push({ id: d.id, ...d.data() }); });
        cl.sort((a, b) => String(a.code || "").localeCompare(String(b.code || "")));
        setCourses(cl);
      } catch (_) {}
    })();
  }, []);

  async function load() {
    try {
      const api = await getDb();
      const snap = await api.getDocs(api.collection(api.db, "schedule"));
      const list = [];
      snap.forEach((d) => { if (d.data().trashed !== true) list.push({ id: d.id, ...d.data() }); });
      list.sort((a, b) => String(a.day || "").localeCompare(String(b.day || "")) || String(a.startTime || "").localeCompare(String(b.startTime || "")));
      setRows(list);
    } catch (e) { setErr(e.message || String(e)); }
  }
  useEffect(() => { load(); }, []);

  function openNew() { setEditId(null); setForm({ ...empty }); setTab("edit"); }
  function openEdit(row) {
    setEditId(row.id);
    setForm({
      day: row.day || "Monday",
      startTime: row.startTime || "",
      endTime: row.endTime || "",
      title: row.title || row.courseTitle || "",
      room: row.room || row.venue || "",
      tutor: row.tutor || row.instructor || "",
      sectionType: row.sectionType || "Live class",
      courseId: row.courseId || "",
      program: row.program || "certificate",
      active: row.active !== false
    });
    setTab("edit");
  }
  async function save(e) {
    e.preventDefault();
    if (!(form.title || "").trim()) { toast("Session title required", "error"); return; }
    try {
      const api = await getDb();
      const id = editId || ("sch_" + Date.now().toString(36));
      const dayOrder = days.indexOf(form.day);
      await api.setDoc(api.doc(api.db, "schedule", id), {
        day: form.day,
        dayOrder: dayOrder >= 0 ? dayOrder : 99,
        startTime: form.startTime,
        endTime: form.endTime,
        title: form.title.trim(),
        room: (form.room || "").trim(),
        tutor: (form.tutor || "").trim(),
        sectionType: form.sectionType || "Live class",
        courseId: form.courseId || "",
        courseCode: ((courses.find((c) => c.id === form.courseId) || {}).code) || "",
        courseTitle: ((courses.find((c) => c.id === form.courseId) || {}).title) || "",
        program: form.program || "certificate",
        active: form.active !== false,
        updatedAt: api.serverTimestamp(),
        ...(editId ? {} : { createdAt: api.serverTimestamp() })
      }, { merge: true });
      toast("Schedule saved", "ok");
      setTab("list");
      load();
    } catch (ex) { toast(ex.message || "Save failed", "error"); }
  }
  async function remove(id) {
    if (!(await askConfirm("Delete this session?"))) return;
    try {
      const api = await getDb();
      await api.deleteDoc(api.doc(api.db, "schedule", id));
      load();
    } catch (e) { toast(e.message || String(e), "error"); }
  }

  return html`<div>
    <h1>Class schedule</h1>
    <p class="muted">Sessions shown on the student portal timetable. Filter by programme on the student side.</p>
    ${err ? html`<p class="error">${err}</p>` : null}
    <${SubTabs} tabs=${[{ id: "list", label: "Sessions" }, { id: "edit", label: editId ? "Edit session" : "Add session" }]} active=${tab} onChange=${setTab} />
    ${tab === "edit" ? html`
      <form class="card" style=${{ padding: "1rem", maxWidth: "36rem" }} onSubmit=${save}>
        <div class="form-row"><label class="muted">Title</label>
          <input required value=${form.title} onInput=${(e) => setForm({ ...form, title: e.target.value })} placeholder="Infection control lab" /></div>
        <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.5rem" }}>
          <div><label class="muted">Day</label>
            <select value=${form.day} onChange=${(e) => setForm({ ...form, day: e.target.value })}>
              ${days.map((d) => html`<option key=${d} value=${d}>${d}</option>`)}
            </select></div>
          <div><label class="muted">Programme</label>
            <select value=${form.program} onChange=${(e) => setForm({ ...form, program: e.target.value })}>
              <option value="certificate">Certificate</option>
              <option value="diploma">Diploma</option>
              <option value="higher-diploma">Higher diploma</option>
              <option value="all">All programmes</option>
            </select></div>
        </div>
        <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.5rem" }}>
          <div><label class="muted">Start</label><input type="time" value=${form.startTime} onInput=${(e) => setForm({ ...form, startTime: e.target.value })} /></div>
          <div><label class="muted">End</label><input type="time" value=${form.endTime} onInput=${(e) => setForm({ ...form, endTime: e.target.value })} /></div>
        </div>
        <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.5rem" }}>
          <div><label class="muted">Room / venue</label><input value=${form.room} onInput=${(e) => setForm({ ...form, room: e.target.value })} placeholder="Hall A" /></div>
          <div><label class="muted">Tutor</label><input value=${form.tutor} onInput=${(e) => setForm({ ...form, tutor: e.target.value })} /></div>
        </div>
        <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.5rem" }}>
          <div><label class="muted">Section type</label>
            <select value=${form.sectionType} onChange=${(e) => setForm({ ...form, sectionType: e.target.value })}>
              <option>Live class</option>
              <option>Physical class</option>
              <option>Online class</option>
              <option>Practical lab</option>
              <option>Other</option>
            </select></div>
          <div><label class="muted">Module</label>
            <select value=${form.courseId} onChange=${(e) => setForm({ ...form, courseId: e.target.value })}>
              <option value="">No module</option>
              ${courses.map((c) => html`<option key=${c.id} value=${c.id}>${c.code || ""} ${c.title || ""}</option>`)}
            </select></div>
        </div>
        <div class="form-row"><${Toggle} checked=${form.active !== false} label="Live on student portal" onChange=${(v) => setForm({ ...form, active: v })} /></div>
        <div style=${{ display: "flex", gap: "0.5rem" }}>
          <button class="primary" type="submit">Save session</button>
          <button class="ghost" type="button" onClick=${() => setTab("list")}>Cancel</button>
          ${editId ? html`<button class="ghost" type="button" style=${{ color: "#dc2626" }} onClick=${() => remove(editId)}>Delete</button>` : null}
        </div>
      </form>
    ` : html`
      <div style=${{ marginBottom: "0.75rem" }}><button class="primary" type="button" onClick=${openNew}>+ Add session</button></div>
      <div class="table-wrap"><table>
        <thead><tr><th>Day</th><th>Time</th><th>Title</th><th>Programme</th><th>Room</th><th>Status</th><th></th></tr></thead>
        <tbody>
          ${rows.length === 0 ? html`<tr><td colspan="7" class="muted">No sessions yet.</td></tr>` : null}
          ${rows.map((r) => html`<tr key=${r.id}>
            <td>${r.day || "—"}</td>
            <td>${r.startTime || "—"}${r.endTime ? " – " + r.endTime : ""}</td>
            <td><strong>${r.title || "—"}</strong><br/><span class="muted" style=${{ fontSize: "0.75rem" }}>${r.tutor || ""}</span></td>
            <td>${r.program || "—"}</td>
            <td>${r.room || "—"}</td>
            <td><${Badge} status=${r.active === false ? "inactive" : "active"} /></td>
            <td><button class="ghost" type="button" onClick=${() => openEdit(r)}>Edit</button></td>
          </tr>`)}
        </tbody>
      </table></div>
    `}
  </div>`;
}

function SectionAttendance({ onSaved }) {
  const [sections, setSections] = useState([]);
  const [students, setStudents] = useState([]);
  const [existing, setExisting] = useState([]);
  const [sectionId, setSectionId] = useState("");
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [yearF, setYearF] = useState("all");
  const [cohortF, setCohortF] = useState("all");
  const [search, setSearch] = useState("");
  const [marks, setMarks] = useState({});
  const [touched, setTouched] = useState({});
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const OPTIONS = ["Present", "Absent", "Late", "Excused"];

  useEffect(() => {
    (async () => {
      try {
        const api = await getDb();
        const [sc, ss, as] = await Promise.all([
          api.getDocs(api.collection(api.db, "schedule")),
          api.getDocs(api.collection(api.db, "students")),
          api.getDocs(api.collection(api.db, "attendance"))
        ]);
        const sec = [];
        sc.forEach((d) => { const x = { id: d.id, ...d.data() }; if (x.trashed !== true && x.active !== false) sec.push(x); });
        sec.sort((a, b) => String(a.title || "").localeCompare(String(b.title || "")));
        const sl = [];
        ss.forEach((d) => { if (d.data().trashed !== true) sl.push({ id: d.id, ...d.data() }); });
        const al = [];
        as.forEach((d) => al.push({ id: d.id, ...d.data() }));
        setSections(sec); setStudents(sl); setExisting(al);
      } catch (e) { setErr(e.message || String(e)); }
    })();
  }, []);

  const section = sections.find((x) => x.id === sectionId) || null;
  // Everyone on this section's programme (all years), then narrowed by the filters below
  const sectionStudents = section
    ? students.filter((st) => !section.program || section.program === "all" || String(st.program || "").toLowerCase() === String(section.program).toLowerCase())
    : [];
  const yearOpts = Array.from(new Set(sectionStudents.map(studentYear).filter(Boolean))).sort().reverse();
  const cohortOpts = Array.from(new Set(sectionStudents.map((st) => st.cohort).filter(Boolean))).sort();
  const q = search.trim().toLowerCase();
  const roster = sectionStudents.filter((st) =>
    (yearF === "all" || studentYear(st) === yearF) &&
    (cohortF === "all" || st.cohort === cohortF) &&
    (!q || [st.fullLegalName, st.fullName, st.regNumber, st.email].filter(Boolean).join(" ").toLowerCase().includes(q))
  );

  // Load saved marks for the whole section on this date; anything unsaved starts as Present
  useEffect(() => {
    if (!section) { setMarks({}); setTouched({}); return; }
    const m = {};
    sectionStudents.forEach((st) => {
      const prev = existing.find((r) => r.sectionId === section.id && r.date === date && r.studentId === st.id);
      m[st.id] = prev ? prev.status : "Present";
    });
    setMarks(m);
    setTouched({});
  }, [sectionId, date, students.length, existing.length]);

  function setOne(id, status) {
    setMarks((prev) => ({ ...prev, [id]: status }));
    setTouched((prev) => ({ ...prev, [id]: true }));
  }
  function setVisible(status) {
    const m = {}; const t = {};
    roster.forEach((st) => { m[st.id] = status; t[st.id] = true; });
    setMarks((prev) => ({ ...prev, ...m }));
    setTouched((prev) => ({ ...prev, ...t }));
  }

  const changedIds = Object.keys(touched);

  async function saveSection() {
    if (!section || changedIds.length === 0) return;
    setBusy(true); setErr("");
    try {
      const api = await getDb();
      for (const id of changedIds) {
        const st = students.find((x) => x.id === id);
        if (!st) continue;
        const status = marks[id] || "Present";
        await api.setDoc(api.doc(api.db, "attendance", section.id + "__" + date + "__" + id), {
          studentId: id,
          email: (st.email || "").toLowerCase(),
          studentName: st.fullLegalName || st.fullName || "",
          regNumber: st.regNumber || "",
          cohort: st.cohort || "",
          date, sessionDate: date,
          sessionTitle: section.title || "",
          sectionId: section.id,
          sectionType: section.sectionType || "",
          courseCode: section.courseCode || "",
          status,
          present: /present/i.test(status),
          updatedAt: api.serverTimestamp()
        }, { merge: true });
      }
      toast("Attendance saved for " + changedIds.length + " student" + (changedIds.length === 1 ? "" : "s"), "ok");
      setTouched({});
      if (onSaved) onSaved();
    } catch (e) { setErr(e.message || String(e)); }
    finally { setBusy(false); }
  }

  return html`<section class="card" style=${{ padding: "1rem", marginBottom: "1rem" }}>
    <h3 style=${{ margin: "0 0 0.25rem" }}>Mark attendance by section</h3>
    <p class="muted" style=${{ margin: "0 0 0.75rem" }}>Pick the section and date, then narrow to a year or batch. Use the buttons to mark everyone on screen at once. Only the students you change are saved.</p>
    <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.5rem" }}>
      <div><label class="muted">Section</label>
        <select value=${sectionId} onChange=${(e) => { setSectionId(e.target.value); setYearF("all"); setCohortF("all"); setSearch(""); }}>
          <option value="">Select section…</option>
          ${sections.map((x) => html`<option key=${x.id} value=${x.id}>${x.title || "Untitled"} · ${x.sectionType || "Class"} · ${x.day || ""} ${x.startTime || ""}</option>`)}
        </select></div>
      <div><label class="muted">Date</label><input type="date" value=${date} onInput=${(e) => setDate(e.target.value)} /></div>
    </div>
    ${section ? html`
      <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.5rem" }}>
        <div><label class="muted">Year</label>
          <select value=${yearF} onChange=${(e) => setYearF(e.target.value)}>
            <option value="all">All years</option>
            ${yearOpts.map((y) => html`<option key=${y} value=${y}>${y}</option>`)}
          </select></div>
        <div><label class="muted">Batch / cohort</label>
          <select value=${cohortF} onChange=${(e) => setCohortF(e.target.value)}>
            <option value="all">All batches</option>
            ${cohortOpts.map((c) => html`<option key=${c} value=${c}>${c}</option>`)}
          </select></div>
      </div>
      <div class="form-row"><label class="muted">Search name, reg number or email</label>
        <input type="search" placeholder="Type to narrow the list…" value=${search} onInput=${(e) => setSearch(e.target.value)} />
      </div>
      <div style=${{ display: "flex", gap: "0.4rem", flexWrap: "wrap", margin: "0.75rem 0", alignItems: "center" }}>
        <button class="ghost" type="button" disabled=${roster.length === 0} onClick=${() => setVisible("Present")}>All present</button>
        <button class="ghost" type="button" disabled=${roster.length === 0} onClick=${() => setVisible("Absent")}>All absent</button>
        <button class="ghost" type="button" disabled=${roster.length === 0} onClick=${() => setVisible("Late")}>All late</button>
        <button class="ghost" type="button" disabled=${roster.length === 0} onClick=${() => setVisible("Excused")}>All excused</button>
        <span class="muted" style=${{ fontSize: "0.8rem" }}>${roster.length} shown of ${sectionStudents.length} on this programme${changedIds.length ? " · " + changedIds.length + " changed" : ""}</span>
      </div>
      <div class="table-wrap"><table>
        <thead><tr><th>Student</th><th>Reg</th><th>Batch</th><th>Status</th></tr></thead>
        <tbody>
          ${roster.length === 0 ? html`<tr><td colspan="4" class="muted">No students match these filters.</td></tr>` : null}
          ${roster.map((st) => html`<tr key=${st.id}>
            <td>${st.fullLegalName || st.fullName || st.email}</td>
            <td><code>${st.regNumber || "—"}</code></td>
            <td>${st.cohort || studentYear(st) || "—"}</td>
            <td><div style=${{ display: "flex", gap: "0.3rem", flexWrap: "wrap" }}>
              ${OPTIONS.map((o) => html`<button key=${o} type="button" class=${marks[st.id] === o ? "primary" : "ghost"}
                style=${{ padding: "0.25rem 0.55rem", fontSize: "0.78rem" }}
                onClick=${() => setOne(st.id, o)}>${o}</button>`)}
            </div></td>
          </tr>`)}
        </tbody>
      </table></div>
      <div style=${{ marginTop: "0.75rem" }}><button class="primary" type="button" disabled=${busy || changedIds.length === 0} onClick=${saveSection}>${busy ? "Saving…" : "Save " + changedIds.length + " change" + (changedIds.length === 1 ? "" : "s")}</button></div>
    ` : null}
    ${err ? html`<p class="error">${err}</p>` : null}
  </section>`;
}

function AttendancePanel() {
  const [students, setStudents] = useState([]);
  const [rows, setRows] = useState([]);
  const [studentId, setStudentId] = useState("");
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [sessionTitle, setSessionTitle] = useState("");
  const [status, setStatus] = useState("Present");
  const [err, setErr] = useState("");
  const [filter, setFilter] = useState("");

  async function load() {
    try {
      const api = await getDb();
      const [ss, as] = await Promise.all([
        api.getDocs(api.collection(api.db, "students")),
        api.getDocs(api.collection(api.db, "attendance"))
      ]);
      const sl = []; ss.forEach((d) => { if (d.data().trashed !== true) sl.push({ id: d.id, ...d.data() }); });
      sl.sort((a, b) => String(a.fullLegalName || a.fullName || "").localeCompare(String(b.fullLegalName || b.fullName || "")));
      const al = []; as.forEach((d) => al.push({ id: d.id, ...d.data() }));
      al.sort((a, b) => String(b.date || "").localeCompare(String(a.date || "")));
      setStudents(sl); setRows(al);
    } catch (e) { setErr(e.message || String(e)); }
  }
  useEffect(() => { load(); }, []);

  async function save(e) {
    e.preventDefault();
    if (!studentId || !sessionTitle.trim()) { toast("Pick student and session title", "error"); return; }
    const st = students.find((s) => s.id === studentId);
    if (!st) return;
    try {
      const api = await getDb();
      const id = "att_" + Date.now().toString(36);
      await api.setDoc(api.doc(api.db, "attendance", id), {
        studentId,
        email: (st.email || "").toLowerCase(),
        studentName: st.fullLegalName || st.fullName || "",
        regNumber: st.regNumber || "",
        date: date,
        sessionDate: date,
        sessionTitle: sessionTitle.trim(),
        status,
        present: /present/i.test(status),
        createdAt: api.serverTimestamp()
      });
      toast("Attendance recorded", "ok");
      setSessionTitle("");
      load();
    } catch (ex) { toast(ex.message || "Failed", "error"); }
  }
  async function remove(id) {
    if (!(await askConfirm("Delete this attendance row?"))) return;
    try {
      const api = await getDb();
      await api.deleteDoc(api.doc(api.db, "attendance", id));
      load();
    } catch (e) { toast(e.message || String(e), "error"); }
  }
  const q = filter.trim().toLowerCase();
  const shown = q ? rows.filter((r) => [r.studentName, r.email, r.regNumber, r.sessionTitle].join(" ").toLowerCase().includes(q)) : rows;

  return html`<div>
    <h1>Attendance</h1>
    <p class="muted">Mark present/absent. Students see this under Attendance in the portal.</p>
    <${SectionAttendance} onSaved=${load} />
    ${err ? html`<p class="error">${err}</p>` : null}
    <form class="card" style=${{ padding: "1rem", maxWidth: "36rem", marginBottom: "1rem" }} onSubmit=${save}>
      <div class="form-row"><label class="muted">Student</label>
        <select required value=${studentId} onChange=${(e) => setStudentId(e.target.value)}>
          <option value="">Select student…</option>
          ${students.map((s) => html`<option key=${s.id} value=${s.id}>${s.fullLegalName || s.fullName || s.email} ${s.regNumber ? "(" + s.regNumber + ")" : ""}</option>`)}
        </select>
      </div>
      <div class="form-row"><label class="muted">Session title</label>
        <input required value=${sessionTitle} onInput=${(e) => setSessionTitle(e.target.value)} placeholder="Week 2 — Unsafe moves" /></div>
      <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.5rem" }}>
        <div><label class="muted">Date</label><input type="date" value=${date} onInput=${(e) => setDate(e.target.value)} /></div>
        <div><label class="muted">Status</label>
          <select value=${status} onChange=${(e) => setStatus(e.target.value)}>
            <option>Present</option>
            <option>Absent</option>
            <option>Late</option>
            <option>Excused</option>
          </select>
        </div>
      </div>
      <button class="primary" type="submit">Save attendance</button>
    </form>
    <div class="form-row"><input placeholder="Filter by student or session…" value=${filter} onInput=${(e) => setFilter(e.target.value)} /></div>
    <div class="table-wrap"><table>
      <thead><tr><th>Date</th><th>Student</th><th>Session</th><th>Status</th><th></th></tr></thead>
      <tbody>
        ${shown.length === 0 ? html`<tr><td colspan="5" class="muted">No records yet.</td></tr>` : null}
        ${shown.map((r) => html`<tr key=${r.id}>
          <td>${r.date || r.sessionDate || "—"}</td>
          <td>${r.studentName || "—"}<br/><span class="muted" style=${{ fontSize: "0.75rem" }}>${r.regNumber || r.email || ""}</span></td>
          <td>${r.sessionTitle || "—"}</td>
          <td><${Badge} status=${/present/i.test(r.status || "") ? "active" : "pending"} /></td>
          <td><button class="ghost" type="button" onClick=${() => remove(r.id)}>Delete</button></td>
        </tr>`)}
      </tbody>
    </table></div>
  </div>`;
}

// Your public site. Links that start with /assets/ point at files in its assets folder.
const PUBLIC_SITE_ORIGIN = "https://cgtia-web.pages.dev";
function resolveMediaLink(u) {
  const t = String(u || "").trim();
  return t.startsWith("/") ? PUBLIC_SITE_ORIGIN + t : t;
}
const MEDIA_SIZES = {
  mobile: { w: 1080, h: 1350, label: "Phone design (portrait)" },
  desktop: { w: 1920, h: 1080, label: "Desktop design (landscape)" },
  free: { w: 0, h: 0, label: "Placeholder picture (PNG, transparent background)" }
};
function checkImageSize(url, kind) {
  return new Promise((resolve, reject) => {
    const im = new Image();
    im.onload = () => {
      const spec = MEDIA_SIZES[kind];
      if (spec.w && (im.naturalWidth !== spec.w || im.naturalHeight !== spec.h)) {
        reject(new Error(spec.label + " must be exactly " + spec.w + "×" + spec.h + " px. This image is " + im.naturalWidth + "×" + im.naturalHeight + " px."));
      } else resolve(url);
    };
    im.onerror = () => reject(new Error("That link is not an image we can load."));
    im.src = url;
  });
}
// Free crop with a locked frame ratio: drag the frame to move it, drag a corner to resize it.
// The frame always keeps the exact ratio of the design, so the export is exactly 1080 x 1350 (or 1920 x 1080).
function CropModal({ file, spec, onCancel, onDone }) {
  const MAX_W = 300;
  const MAX_H = 380;
  const ratio = spec.w / spec.h;
  const [bmp, setBmp] = useState(null);
  const [url, setUrl] = useState("");
  const [crop, setCrop] = useState({ x: 0, y: 0, w: 0, h: 0 });
  const [busy, setBusy] = useState(false);
  const drag = useRef(null);

  useEffect(() => {
    let alive = true;
    let objectUrl = "";
    (async () => {
      const b = await createImageBitmap(file);
      if (!alive) { b.close && b.close(); return; }
      objectUrl = URL.createObjectURL(file);
      let w = b.width;
      let h = w / ratio;
      if (h > b.height) { h = b.height; w = h * ratio; }
      setBmp(b);
      setUrl(objectUrl);
      setCrop({ x: (b.width - w) / 2, y: (b.height - h) / 2, w, h });
    })();
    document.body.style.overflow = "hidden"; // nothing behind the crop tool moves
    return () => {
      alive = false;
      document.body.style.overflow = "";
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [file]);

  const k = bmp ? Math.min(MAX_W / bmp.width, MAX_H / bmp.height) : 1;
  const stageW = bmp ? Math.round(bmp.width * k) : MAX_W;
  const stageH = bmp ? Math.round(bmp.height * k) : MAX_H;
  const MIN_W = 120;

  function onDown(e) {
    const handle = e.target.closest("[data-h]");
    if (!handle) return;
    drag.current = { h: handle.dataset.h, sx: e.clientX, sy: e.clientY, start: { ...crop } };
    e.currentTarget.setPointerCapture(e.pointerId);
  }
  function onMove(e) {
    const d = drag.current;
    if (!d || !bmp) return;
    const dx = (e.clientX - d.sx) / k;
    const dy = (e.clientY - d.sy) / k;
    const st = d.start;
    if (d.h === "move") {
      setCrop({
        x: Math.min(bmp.width - st.w, Math.max(0, st.x + dx)),
        y: Math.min(bmp.height - st.h, Math.max(0, st.y + dy)),
        w: st.w, h: st.h
      });
      return;
    }
    // Corner resize: the opposite corner stays put, and the frame keeps the exact ratio
    const west = d.h === "nw" || d.h === "sw";
    const north = d.h === "nw" || d.h === "ne";
    const anchorX = west ? st.x + st.w : st.x;
    const anchorY = north ? st.y + st.h : st.y;
    const widthChange = west ? -dx : dx;
    const heightChange = north ? -dy : dy;
    const change = Math.abs(widthChange) >= Math.abs(heightChange * ratio) ? widthChange : heightChange * ratio;
    const maxW = Math.min(west ? anchorX : bmp.width - anchorX, (north ? anchorY : bmp.height - anchorY) * ratio);
    const w = Math.max(MIN_W, Math.min(maxW, st.w + change));
    const h = w / ratio;
    setCrop({ x: west ? anchorX - w : anchorX, y: north ? anchorY - h : anchorY, w, h });
  }
  function onUp() { drag.current = null; }

  async function confirm() {
    if (!bmp || busy) return;
    setBusy(true);
    try {
      const out = document.createElement("canvas");
      out.width = spec.w;
      out.height = spec.h;
      const ctx = out.getContext("2d");
      ctx.imageSmoothingQuality = "high";
      ctx.drawImage(bmp, crop.x, crop.y, crop.w, crop.h, 0, 0, spec.w, spec.h);
      let blob = await new Promise((res) => out.toBlob(res, "image/webp", 0.92));
      if (!blob) blob = await new Promise((res) => out.toBlob(res, "image/png"));
      if (!blob) throw new Error("Could not export the cropped picture.");
      onDone(blob);
    } catch (e) {
      toast(e.message || String(e), "error");
      setBusy(false);
    }
  }

  const fx = Math.round(crop.x * k), fy = Math.round(crop.y * k);
  const fw = Math.round(crop.w * k), fh = Math.round(crop.h * k);
  return html`<div class="crop-scrim" role="dialog" aria-modal="true" aria-label="Crop to exact size"
      onClick=${(e) => { if (e.target === e.currentTarget && !busy) onCancel(); }}>
    <div class="crop-box">
      <h3>Crop to ${spec.w} × ${spec.h} px</h3>
      <p class="muted">Drag the frame to move it. Drag a corner to make it bigger or smaller. The frame keeps the exact shape, so the export is exact.</p>
      <div class="crop-stage" style=${{ width: stageW, height: stageH }}
        onPointerDown=${onDown} onPointerMove=${onMove} onPointerUp=${onUp} onPointerCancel=${onUp}>
        ${url ? html`<img src=${url} alt="" draggable="false" style=${{ width: stageW, height: stageH }} />` : null}
        ${bmp ? html`<div class="crop-frame" data-h="move" style=${{ left: fx, top: fy, width: fw, height: fh }}>
          ${["nw", "ne", "sw", "se"].map((h) => html`<span key=${h} class=${"crop-handle h-" + h} data-h=${h}></span>`)}
        </div>` : null}
      </div>
      <p class="crop-readout">Selected ${Math.round(crop.w)} × ${Math.round(crop.h)} px → exports ${spec.w} × ${spec.h} px</p>
      <p class="muted" style=${{ fontSize: "0.75rem", margin: "0" }}>Original: ${bmp ? bmp.width + " × " + bmp.height : "…"} px.</p>
      <div style=${{ display: "flex", gap: "0.5rem", justifyContent: "flex-end", marginTop: "0.75rem" }}>
        <button class="ghost" type="button" disabled=${busy} onClick=${onCancel}>Cancel</button>
        <button class="primary" type="button" disabled=${busy || !bmp} onClick=${confirm}>${busy ? "Saving…" : "Crop and use"}</button>
      </div>
    </div>
  </div>`;
}

function MediaUploadField({ kind, value, onChange, folder }) {
  const spec = MEDIA_SIZES[kind];
  const [busy, setBusy] = useState(false);
  const [link, setLink] = useState("");
  const [cropFile, setCropFile] = useState(null);

  async function sendBlob(blob, type, ext) {
    const api = await getDb();
    const r = api.storageRef(api.storage, "dashboard-media/" + (folder || "misc") + "/" + kind + "-" + Date.now().toString(36) + "." + ext);
    await api.uploadBytes(r, blob, { contentType: type });
    return api.getDownloadURL(r);
  }
  async function pick(e) {
    const file = e.target.files && e.target.files[0];
    e.target.value = "";
    if (!file) return;
    if (!/^image\/(png|jpeg|webp)$/.test(file.type)) { toast("Use a PNG, JPG or WEBP image.", "error"); return; }
    if (file.size > 12 * 1024 * 1024) { toast("Image is over 12 MB.", "error"); return; }
    if (spec.w) {
      try {
        const bmp = await createImageBitmap(file);
        if (bmp.width !== spec.w || bmp.height !== spec.h) {
          // Not the exact size: offer the crop tool instead of rejecting it
          setCropFile(file);
          return;
        }
      } catch (err) { toast(err.message || String(err), "error"); return; }
    }
    setBusy(true);
    try {
      const ext = file.type === "image/png" ? "png" : file.type === "image/webp" ? "webp" : "jpg";
      onChange(await sendBlob(file, file.type, ext));
      toast(spec.label + " uploaded", "ok");
    } catch (err) { toast(err.message || String(err), "error"); }
    finally { setBusy(false); }
  }
  async function onCropDone(blob) {
    setBusy(true);
    try {
      onChange(await sendBlob(blob, "image/webp", "webp"));
      toast("Cropped to " + spec.w + "×" + spec.h + " and uploaded", "ok");
      setCropFile(null);
    } catch (err) { toast(err.message || String(err), "error"); }
    finally { setBusy(false); }
  }
  async function useLink() {
    let t = link.trim();
    if (!t) return;
    // A bare file name means a file in the site's /assets folder
    if (!/^(https?:|\/)/.test(t)) t = "/assets/" + t;
    setBusy(true);
    try { onChange(await checkImageSize(resolveMediaLink(t), kind)); setLink(""); toast(spec.label + " linked", "ok"); }
    catch (err) { toast(err.message || String(err), "error"); }
    finally { setBusy(false); }
  }
  return html`<div class="media-field">
    <div class="media-head"><strong>${spec.label}</strong><span class="muted">${spec.w ? spec.w + " × " + spec.h + " px" : "any size, PNG recommended"}</span></div>
    <div class=${"media-preview " + (kind === "mobile" ? "is-portrait" : kind === "desktop" ? "is-landscape" : "is-free")}>
      ${value ? html`<img src=${value} alt="" />` : html`<span class="muted">Nothing uploaded yet</span>`}
    </div>
    <div class="media-actions">
      <input type="file" accept="image/png,image/jpeg,image/webp" onChange=${pick} disabled=${busy} />
      ${value ? html`<button type="button" class="ghost" onClick=${() => onChange("")}>Remove</button>` : null}
    </div>
    <div class="media-link">
      <input placeholder="file name in /assets, or a full https link" value=${link} onInput=${(e) => setLink(e.target.value)} />
      <button type="button" class="ghost" disabled=${busy || !link.trim()} onClick=${useLink}>Use</button>
    </div>
    <small class="muted">${busy ? "Working…" : (spec.w ? "Any size works. Pictures that are not the exact size open the crop tool." : "Use a transparent PNG so the picture sits cleanly on the card.")}</small>
    ${cropFile ? html`<${CropModal} file=${cropFile} spec=${spec} onCancel=${() => setCropFile(null)} onDone=${onCropDone} />` : null}
  </div>`;
}

const CARD_STYLE_DEFAULTS = { phScale: 100, phX: 0, phY: 0, textSize: 24, textWeight: 800 };
function CardPreview({ v }) {
  const protrude = v.placeholderMode === "protrude";
  const tf = "translate(" + v.phX + "%," + v.phY + "%) scale(" + (v.phScale / 100) + ")";
  return html`<div class=${"card-preview" + (protrude ? " is-protrude" : "")} aria-label="Live preview of the card">
    <div class="card-preview-card">
      <div class="card-preview-text" style=${{ maxWidth: "60%" }}>
        <h3 style=${{ fontSize: v.textSize + "px", fontWeight: v.textWeight }}>${v.title || "Your heading"}</h3>
        <p>${v.body || "Your write-up appears here."}</p>
      </div>
      ${(v.placeholder && !protrude) ? html`<img class="card-preview-ph" src=${v.placeholder} alt="" style=${{ transform: tf }} />` : null}
    </div>
    ${(v.placeholder && protrude) ? html`<div class="card-preview-clip"><img class="card-preview-ph" src=${v.placeholder} alt="" style=${{ transform: tf }} /></div>` : null}
    <span class="card-preview-cta">${v.ctaLabel || "Learn more"} →</span>
  </div>`;
}
function CardStyleControls({ editing, set }) {
  const v = { ...CARD_STYLE_DEFAULTS, ...editing };
  const slider = (label, key, min, max, step, unit) => html`<label class="card-style-row">
    <span>${label} <strong>${v[key]}${unit}</strong></span>
    <input type="range" min=${min} max=${max} step=${step || 1} value=${v[key]} onInput=${(e) => set({ [key]: Number(e.target.value) })} />
  </label>`;
  return html`<div class="card-style">
    <strong>Placeholder and heading</strong>
    <div class="card-style-grid">
      <div class="card-style-controls">
        ${slider("Picture size", "phScale", 50, 160, 1, "%")}
        ${slider("Picture left / right", "phX", -40, 40, 1, "%")}
        ${slider("Picture up / down", "phY", -40, 40, 1, "%")}
        ${slider("Heading size", "textSize", 16, 44, 1, "px")}
        ${slider("Heading weight", "textWeight", 400, 900, 100, "")}
        <button type="button" class="ghost" onClick=${() => set({ ...CARD_STYLE_DEFAULTS })}>Reset these</button>
      </div>
      <${CardPreview} v=${{ ...v, title: editing.title, body: editing.body, ctaLabel: editing.ctaLabel, placeholder: editing.placeholder, placeholderMode: editing.placeholderMode }} />
    </div>
    <p class="muted" style=${{ fontSize: "0.75rem", margin: "0.5rem 0 0" }}>The preview follows the same rules as the student dashboard. Save the slide to publish these settings.</p>
  </div>`;
}

function DashboardSlidesPanel() {
  const [rows, setRows] = useState([]);
  const [editing, setEditing] = useState(null);
  const [seconds, setSeconds] = useState("6");
  const [err, setErr] = useState("");
  const blank = { id: "", kind: "design", title: "", body: "", ctaLabel: "Learn more", ctaUrl: "", imageMobile: "", imageDesktop: "", bgMobile: "", bgDesktop: "", placeholder: "", placeholderMode: "inside", ...CARD_STYLE_DEFAULTS, order: 10, active: true };

  async function load() {
    try {
      const api = await getDb();
      const snap = await api.getDocs(api.collection(api.db, "dashboardSlides"));
      const list = [];
      snap.forEach((d) => { if (d.data().trashed !== true) list.push({ id: d.id, ...d.data() }); });
      list.sort((a, b) => (Number(a.order) || 0) - (Number(b.order) || 0));
      setRows(list);
      const ps = await api.getDoc(api.doc(api.db, "siteContent", "portalSettings"));
      if (ps.exists() && ps.data().slideSeconds) setSeconds(String(ps.data().slideSeconds));
    } catch (e) { setErr(e.message || String(e)); }
  }
  useEffect(() => { load(); }, []);

  async function save() {
    if (!editing) return;
    const isCard = editing.kind === "card";
    if (isCard && !editing.title.trim() && !editing.placeholder && !editing.bgMobile && !editing.bgDesktop) { toast("A card needs a title, a background or a picture.", "error"); return; }
    if (!isCard && !editing.imageMobile && !editing.imageDesktop) { toast("A design slide needs at least one design uploaded.", "error"); return; }
    try {
      const api = await getDb();
      const id = editing.id || ("slide-" + Date.now().toString(36));
      await api.setDoc(api.doc(api.db, "dashboardSlides", id), {
        kind: isCard ? "card" : "design",
        title: editing.title.trim(), body: editing.body.trim(),
        ctaLabel: (editing.ctaLabel || "Learn more").trim(), ctaUrl: editing.ctaUrl.trim(),
        imageMobile: isCard ? "" : (editing.imageMobile || ""),
        imageDesktop: isCard ? "" : (editing.imageDesktop || ""),
        bgMobile: isCard ? (editing.bgMobile || "") : "",
        bgDesktop: isCard ? (editing.bgDesktop || "") : "",
        placeholder: isCard ? (editing.placeholder || "") : "",
        placeholderMode: editing.placeholderMode === "protrude" ? "protrude" : "inside",
        phScale: Number(editing.phScale) || 100, phX: Number(editing.phX) || 0, phY: Number(editing.phY) || 0,
        textSize: Number(editing.textSize) || 24, textWeight: Number(editing.textWeight) || 800,
        order: Number(editing.order) || 0, active: editing.active !== false,
        updatedAt: api.serverTimestamp()
      }, { merge: true });
      toast("Slide saved", "ok");
      setEditing(null); load();
    } catch (e) { toast(e.message || String(e), "error"); }
  }
  async function remove(row) {
    if (!(await askConfirm("Remove this slide from the dashboard?"))) return;
    try {
      const api = await getDb();
      await api.updateDoc(api.doc(api.db, "dashboardSlides", row.id), { trashed: true, active: false });
      load();
    } catch (e) { toast(e.message || String(e), "error"); }
  }
  async function saveTiming() {
    try {
      const api = await getDb();
      const n = Math.max(3, Math.min(30, Number(seconds) || 6));
      await api.setDoc(api.doc(api.db, "siteContent", "portalSettings"), { slideSeconds: n }, { merge: true });
      setSeconds(String(n));
      toast("Slide timing saved", "ok");
    } catch (e) { toast(e.message || String(e), "error"); }
  }

  if (editing) {
    const set = (patch) => setEditing({ ...editing, ...patch });
    const folder = editing.id || "new";
    const isCard = editing.kind === "card";
    return html`<div>
      <h1>${editing.id ? "Edit slide" : "New slide"}</h1>
      <p class="muted">Two kinds of slide. <strong>Design</strong>: the designer's full artwork, which is the whole card. <strong>Card</strong>: a background (optional), a placeholder picture, your write-up and a button.</p>
      <div class="card" style=${{ padding: "1rem" }}>
        <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.5rem" }}>
          <div><label class="muted">Slide type</label>
            <select value=${editing.kind} onChange=${(e) => set({ kind: e.target.value })}>
              <option value="design">Design (full artwork)</option>
              <option value="card">Card (text, placeholder, button)</option>
            </select></div>
          <div><label class="muted">Order (lower shows first)</label><input type="number" value=${editing.order} onInput=${(e) => set({ order: e.target.value })} /></div>
        </div>
        <div class="form-row"><label class="muted">Internal name (for your list)</label><input value=${editing.title} onInput=${(e) => set({ title: e.target.value })} /></div>
        ${isCard ? html`
          <div class="form-row"><label class="muted">Heading</label><input value=${editing.title} onInput=${(e) => set({ title: e.target.value })} placeholder="Your dashboard" /></div>
          <div class="form-row"><label class="muted">Write-up</label><textarea rows="3" value=${editing.body} onInput=${(e) => set({ body: e.target.value })}></textarea></div>
        ` : html`<div class="form-row"><label class="muted">Text (shown only when there is no design)</label><textarea rows="2" value=${editing.body} onInput=${(e) => set({ body: e.target.value })}></textarea></div>`}
        <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.5rem" }}>
          <div><label class="muted">Button text</label><input value=${editing.ctaLabel} onInput=${(e) => set({ ctaLabel: e.target.value })} /></div>
          <div><label class="muted">Button link (optional)</label><input placeholder="https://…" value=${editing.ctaUrl} onInput=${(e) => set({ ctaUrl: e.target.value })} /></div>
        </div>
        <div class="form-row"><${Toggle} checked=${editing.active !== false} label="Show on the dashboard" onChange=${(v) => set({ active: v })} /></div>
        ${isCard ? html`
          <div style=${{ display: "grid", gridTemplateColumns: "1fr", gap: "1rem", marginTop: "0.5rem" }}>
            <div class="form-row"><label class="muted">Placeholder position</label>
              <select value=${editing.placeholderMode || "inside"} onChange=${(e) => set({ placeholderMode: e.target.value })}>
                <option value="inside">Inside the card (stays within its edges)</option>
                <option value="protrude">Protruding (rises above the card's top edge)</option>
              </select></div>
            <${CardStyleControls} editing=${editing} set=${set} />
            <${MediaUploadField} kind="free" value=${editing.placeholder} folder=${folder} onChange=${(v) => set({ placeholder: v })} />
            <p class="muted" style=${{ margin: 0 }}>Background (optional). Same two sizes as designs.</p>
            <${MediaUploadField} kind="mobile" value=${editing.bgMobile} folder=${folder} onChange=${(v) => set({ bgMobile: v })} />
            <${MediaUploadField} kind="desktop" value=${editing.bgDesktop} folder=${folder} onChange=${(v) => set({ bgDesktop: v })} />
          </div>` : html`
          <div style=${{ display: "grid", gridTemplateColumns: "1fr", gap: "1rem", marginTop: "0.5rem" }}>
            <${MediaUploadField} kind="mobile" value=${editing.imageMobile} folder=${folder} onChange=${(v) => set({ imageMobile: v })} />
            <${MediaUploadField} kind="desktop" value=${editing.imageDesktop} folder=${folder} onChange=${(v) => set({ imageDesktop: v })} />
          </div>`}
        <div style=${{ display: "flex", gap: "0.5rem", marginTop: "1rem" }}>
          <button class="primary" type="button" onClick=${save}>Save slide</button>
          <button class="ghost" type="button" onClick=${() => setEditing(null)}>Cancel</button>
        </div>
      </div>
    </div>`;
  }

  return html`<div>
    <h1>Dashboard carousel</h1>
    <p class="muted">Slides rotate on the student dashboard, one after another. Design slides show the designer's artwork. Card slides show a background, a placeholder picture, your write-up and a button.</p>
    ${err ? html`<p class="error">${err}</p>` : null}
    <div class="card" style=${{ padding: "1rem", marginBottom: "1rem" }}>
      <strong>Timing</strong>
      <div class="form-row" style=${{ display: "flex", gap: "0.5rem", alignItems: "end", flexWrap: "wrap" }}>
        <div><label class="muted">Seconds per slide (3 to 30)</label><input type="number" value=${seconds} onInput=${(e) => setSeconds(e.target.value)} style=${{ width: "10rem" }} /></div>
        <button class="ghost" type="button" onClick=${saveTiming}>Save timing</button>
      </div>
    </div>
    <button class="primary" type="button" onClick=${() => setEditing({ ...blank })}>New slide</button>
    <div class="table-wrap" style=${{ marginTop: "0.75rem" }}><table>
      <thead><tr><th>Order</th><th>Type</th><th>Preview</th><th>Name</th><th>Status</th><th></th></tr></thead>
      <tbody>
        ${rows.length === 0 ? html`<tr><td colspan="6" class="muted">No slides yet. The dashboard shows its default banner.</td></tr>` : null}
        ${rows.map((r) => html`<tr key=${r.id}>
          <td>${r.order}</td>
          <td>${r.kind === "card" ? "Card" : "Design"}</td>
          <td>${(r.imageMobile || r.bgMobile || r.imageDesktop || r.bgDesktop) ? html`<img src=${r.imageMobile || r.bgMobile || r.imageDesktop || r.bgDesktop} alt="" style=${{ width: 40, height: 50, objectFit: "cover", borderRadius: 6 }} />` : "—"}</td>
          <td>${r.title || "Untitled"}</td>
          <td>${r.active === false ? "Hidden" : "Showing"}</td>
          <td style=${{ whiteSpace: "nowrap" }}>
            <button class="ghost" type="button" onClick=${() => setEditing({ ...blank, ...r })}>Edit</button>
            <button class="ghost" type="button" onClick=${() => remove(r)}>Remove</button>
          </td>
        </tr>`)}
      </tbody>
    </table></div>
  </div>`;
}

function AnswerQueriesPanel() {
  const [rows, setRows] = useState([]);
  const [filter, setFilter] = useState("open");
  const [err, setErr] = useState("");
  const [replyFor, setReplyFor] = useState(null);
  const [replyText, setReplyText] = useState("");

  async function load() {
    try {
      const api = await getDb();
      const snap = await api.getDocs(api.collection(api.db, "answerQueries"));
      const list = [];
      snap.forEach((d) => list.push({ id: d.id, ...d.data() }));
      list.sort((a, b) => queryMs(b.createdAt) - queryMs(a.createdAt));
      setRows(list); setErr("");
    } catch (e) { setErr(e.message || String(e)); }
  }
  useEffect(() => { load(); }, []);

  const shown = rows.filter((r) => filter === "all" || (r.status || "open") === filter);

  async function resolve(row, reply) {
    try {
      const api = await getDb();
      await api.setDoc(api.doc(api.db, "answerQueries", row.id), {
        status: "resolved", reply: (reply || "").trim(), resolvedAt: api.serverTimestamp()
      }, { merge: true });
      toast("Query resolved", "ok");
      setReplyFor(null); setReplyText("");
      load();
    } catch (e) { toast(e.message || String(e), "error"); }
  }

  return html`<div>
    <h1>Answer queries</h1>
    <p class="muted">Students can question an answer on a test you marked "let students review". Check the question, reply with your decision, and resolve it.</p>
    ${err ? html`<p class="error">${err}</p>` : null}
    <div class="form-row" style=${{ maxWidth: "16rem" }}>
      <select value=${filter} onChange=${(e) => setFilter(e.target.value)}>
        <option value="open">Open</option>
        <option value="resolved">Resolved</option>
        <option value="all">All</option>
      </select>
    </div>
    ${shown.length === 0 ? html`<p class="muted">No queries here.</p>` : null}
    ${shown.map((r) => html`<div class="card" key=${r.id} style=${{ marginBottom: "0.75rem" }}>
      <p class="muted" style=${{ margin: 0, fontSize: "0.8rem" }}>${r.studentName || r.studentEmail || "Student"} · ${r.assessmentTitle || "Test"} · Question ${(Number(r.questionIndex) || 0) + 1}</p>
      <p style=${{ fontWeight: 700, margin: "0.35rem 0" }}>${r.questionPrompt || ""}</p>
      <p style=${{ margin: "0.2rem 0" }}><span class="muted">Student answered:</span> ${r.yourAnswer || "—"}</p>
      <p style=${{ margin: "0.2rem 0" }}><span class="muted">Marked correct:</span> ${r.correctAnswer || "—"}</p>
      <p style=${{ margin: "0.6rem 0", whiteSpace: "pre-wrap" }}>${r.message || ""}</p>
      ${r.reply ? html`<p class="muted" style=${{ margin: "0.3rem 0" }}>Your reply: ${r.reply}</p>` : null}
      ${(r.status || "open") === "open"
        ? (replyFor === r.id
          ? html`<div>
              <textarea rows="3" value=${replyText} placeholder="Your decision and reason" onInput=${(e) => setReplyText(e.target.value)}></textarea>
              <div class="form-row" style=${{ display: "flex", gap: "0.5rem" }}>
                <button class="primary" type="button" onClick=${() => resolve(r, replyText)}>Resolve with reply</button>
                <button class="ghost" type="button" onClick=${() => { setReplyFor(null); setReplyText(""); }}>Cancel</button>
              </div>
            </div>`
          : html`<button class="ghost" type="button" onClick=${() => setReplyFor(r.id)}>Reply and resolve</button>`)
        : html`<span class="badge paid">Resolved</span>`}
    </div>`)}
  </div>`;
}

function SupportMessagesPanel() {
  const [rows, setRows] = useState([]);
  const [err, setErr] = useState("");
  const [filter, setFilter] = useState("open");
  const [replyFor, setReplyFor] = useState(null);
  const [replyText, setReplyText] = useState("");

  async function load() {
    try {
      const api = await getDb();
      const snap = await api.getDocs(api.collection(api.db, "supportMessages"));
      const list = [];
      snap.forEach((d) => list.push({ id: d.id, ...d.data() }));
      list.sort((a, b) => {
        const ta = a.createdAt?.toMillis?.() || 0;
        const tb = b.createdAt?.toMillis?.() || 0;
        return tb - ta;
      });
      setRows(list);
    } catch (e) { setErr(e.message || String(e)); }
  }
  useEffect(() => { load(); }, []);

  async function setStatus(row, status) {
    try {
      const api = await getDb();
      await api.setDoc(api.doc(api.db, "supportMessages", row.id), { status, updatedAt: api.serverTimestamp() }, { merge: true });
      load();
    } catch (e) { toast(e.message || String(e), "error"); }
  }
  async function sendReply(e) {
    e.preventDefault();
    if (!replyFor || !replyText.trim()) return;
    try {
      const api = await getDb();
      await api.setDoc(api.doc(api.db, "supportMessages", replyFor.id), {
        reply: replyText.trim(),
        status: "replied",
        repliedAt: api.serverTimestamp(),
        updatedAt: api.serverTimestamp()
      }, { merge: true });
      toast("Reply saved — student will see it in Messages", "ok");
      setReplyFor(null);
      setReplyText("");
      load();
    } catch (ex) { toast(ex.message || "Failed", "error"); }
  }

  const shown = rows.filter((r) => {
    if (filter === "all") return true;
    if (filter === "open") return (r.status || "open") === "open";
    if (filter === "replied") return r.status === "replied" || r.reply;
    return true;
  });

  return html`<div>
    <h1>Student messages</h1>
    <p class="muted">Messages students send from the portal. Reply here and they see it under Messages.</p>
    ${err ? html`<p class="error">${err}</p>` : null}
    <div style=${{ display: "flex", gap: "0.5rem", marginBottom: "0.75rem", flexWrap: "wrap" }}>
      ${["open", "replied", "all"].map((f) => html`<button type="button" class=${filter === f ? "primary" : "ghost"} key=${f} onClick=${() => setFilter(f)}>${f}</button>`)}
    </div>
    ${replyFor ? html`
      <form class="card" style=${{ padding: "1rem", marginBottom: "1rem", maxWidth: "36rem" }} onSubmit=${sendReply}>
        <p class="muted" style=${{ marginBottom: "0.5rem" }}>Replying to <strong>${replyFor.subject}</strong> (${replyFor.email || replyFor.name || ""})</p>
        <textarea rows="4" required value=${replyText} onInput=${(e) => setReplyText(e.target.value)} placeholder="Type your reply…" style=${{ width: "100%", boxSizing: "border-box" }}></textarea>
        <div style=${{ display: "flex", gap: "0.5rem", marginTop: "0.5rem" }}>
          <button class="primary" type="submit">Send reply</button>
          <button class="ghost" type="button" onClick=${() => { setReplyFor(null); setReplyText(""); }}>Cancel</button>
        </div>
      </form>
    ` : null}
    <div class="table-wrap"><table>
      <thead><tr><th>When</th><th>From</th><th>Subject</th><th>Status</th><th></th></tr></thead>
      <tbody>
        ${shown.length === 0 ? html`<tr><td colspan="5" class="muted">No messages in this filter.</td></tr>` : null}
        ${shown.map((r) => {
          const when = r.createdAt?.toDate ? r.createdAt.toDate().toLocaleString() : "—";
          return html`<tr key=${r.id}>
            <td style=${{ whiteSpace: "nowrap", fontSize: "0.8rem" }}>${when}</td>
            <td>${r.name || "—"}<br/><span class="muted" style=${{ fontSize: "0.75rem" }}>${r.email || ""}</span></td>
            <td><strong>${r.subject || "—"}</strong><br/><span class="muted" style=${{ fontSize: "0.8rem" }}>${(r.body || "").slice(0, 80)}</span>
              ${r.reply ? html`<br/><span style=${{ fontSize: "0.8rem" }}><strong>Reply:</strong> ${(r.reply || "").slice(0, 80)}</span>` : null}
            </td>
            <td><${Badge} status=${r.status || "open"} /></td>
            <td style=${{ whiteSpace: "nowrap" }}>
              <button class="ghost" type="button" onClick=${() => { setReplyFor(r); setReplyText(r.reply || ""); }}>Reply</button>
              ${(r.status || "open") === "open" ? html`<button class="ghost" type="button" onClick=${() => setStatus(r, "closed")}>Close</button>` : null}
            </td>
          </tr>`;
        })}
      </tbody>
    </table></div>
  </div>`;
}



function gradeColor(grade) {
  const k = String(grade || "").trim().toUpperCase().charAt(0);
  return { A: "#15803d", B: "#0948e6", C: "#0e7490", D: "#b45309", E: "#c2410c", F: "#b91c1c" }[k] || "#0f172a";
}
function transcriptCols(rows) {
  const seen = {};
  const out = [];
  rows.forEach((g) => (g.componentDefs || []).forEach((c) => { if (!seen[c.key]) { seen[c.key] = true; out.push({ key: c.key, label: c.label || c.key }); } }));
  if (!out.length) return DEFAULT_GRADE_COMPONENTS.map((c) => ({ key: c.key, label: c.label }));
  return out;
}
function componentCell(g, key) {
  const v = (g.components && g.components[key] != null) ? g.components[key] : g[key];
  return v != null && v !== "" ? v : "—";
}
function gradeVal(g, keys) {
  for (const k of keys) if (g && g[k] != null && g[k] !== "") return g[k];
  return "—";
}
const queryMs = (t) => (t && t.toMillis ? t.toMillis() : 0);

async function uploadStudentPhoto(e, form, setForm) {
  const file = e.target.files && e.target.files[0];
  if (!file) return;
  if (!/^image\//.test(file.type)) { toast("Choose an image file.", "error"); return; }
  if (file.size > 3 * 1024 * 1024) { toast("Photo is over 3 MB. Choose a smaller image.", "error"); return; }
  try {
    const bmp = await createImageBitmap(file);
    const side = 480;
    const scale = Math.min(side / bmp.width, side / bmp.height);
    const w = Math.round(bmp.width * scale), h = Math.round(bmp.height * scale);
    const canvas = document.createElement("canvas");
    canvas.width = side; canvas.height = side;
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = "#ffffff"; ctx.fillRect(0, 0, side, side);
    ctx.drawImage(bmp, (side - w) / 2, (side - h) / 2, w, h);
    const blob = await new Promise((res) => canvas.toBlob(res, "image/jpeg", 0.86));
    const api = await getDb();
    const key = String(form.email || form.regNumber || Date.now()).toLowerCase().replace(/[^a-z0-9]+/g, "_");
    const r = api.storageRef(api.storage, "student-photos/" + key + ".jpg");
    await api.uploadBytes(r, blob, { contentType: "image/jpeg" });
    const url = await api.getDownloadURL(r);
    setForm({ ...form, photoUrl: url });
    toast("Photo uploaded. Save the student to keep it.", "ok");
  } catch (err) { toast(err.message || String(err), "error"); }
}

function TranscriptPanel() {
  const [students, setStudents] = useState([]);
  const [grades, setGrades] = useState([]);
  const [studentId, setStudentId] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  async function load() {
    try {
      const api = await getDb();
      const [ss, gs] = await Promise.all([
        api.getDocs(api.collection(api.db, "students")),
        api.getDocs(api.collection(api.db, "grades"))
      ]);
      const sl = []; ss.forEach((d) => { if (d.data().trashed !== true) sl.push({ id: d.id, ...d.data() }); });
      sl.sort((a, b) => String(a.fullLegalName || a.fullName || "").localeCompare(String(b.fullLegalName || b.fullName || "")));
      const gl = []; gs.forEach((d) => gl.push({ id: d.id, ...d.data() }));
      setStudents(sl); setGrades(gl);
    } catch (e) { setErr(e.message || String(e)); }
  }
  useEffect(() => { load(); }, []);

  const st = students.find((s) => s.id === studentId);
  const rows = grades.filter((g) => g.studentId === studentId && g.published !== false)
    .sort((a, b) => String(a.courseCode || "").localeCompare(String(b.courseCode || "")));
  const scores = rows.map((g) => Number(g.score)).filter((n) => !Number.isNaN(n));
  const avg = scores.length ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : null;
  const locked = st && st.transcriptLocked === true;

  async function setLock(on) {
    if (!st) return;
    setBusy(true);
    try {
      const api = await getDb();
      await api.setDoc(api.doc(api.db, "students", st.id), {
        transcriptLocked: !!on,
        updatedAt: api.serverTimestamp()
      }, { merge: true });
      toast(on ? "Transcript locked" : "Transcript unlocked", "ok");
      load();
    } catch (e) { toast(e.message || String(e), "error"); }
    finally { setBusy(false); }
  }

  function printSheet() {
    window.print();
  }

  return html`<div>
    <h1>Transcript</h1>
    <p class="muted">Official view of published grades for one student. Lock stops casual edits from looking “final” in the portal badge sense — grades are still managed under Results / grades.</p>
    ${err ? html`<p class="error">${err}</p>` : null}
    <div class="form-row" style=${{ maxWidth: "28rem" }}>
      <label class="muted">Student</label>
      <select value=${studentId} onChange=${(e) => setStudentId(e.target.value)}>
        <option value="">Select student…</option>
        ${students.map((s) => html`<option key=${s.id} value=${s.id}>${s.fullLegalName || s.fullName || s.email} ${s.regNumber ? "· " + s.regNumber : ""}</option>`)}
      </select>
    </div>
    ${st ? html`
      <div class="card transcript-sheet" style=${{ padding: "1.25rem", marginTop: "1rem", maxWidth: "40rem" }}>
        <div style=${{ display: "flex", justifyContent: "space-between", gap: "1rem", flexWrap: "wrap", marginBottom: "1rem", alignItems: "flex-start" }}>
        ${st.photoUrl ? html`<img class="tx-admin-photo" src=${st.photoUrl} alt="Student photo" />` : html`<div class="tx-admin-photo is-empty">No photo</div>`}
          <div>
            <p class="muted" style=${{ margin: 0, fontSize: "0.75rem", textTransform: "uppercase", letterSpacing: "0.04em" }}>Caregivers Training & Internship Academy</p>
            <h2 style=${{ margin: "0.35rem 0" }}>Academic transcript</h2>
            <p style=${{ margin: 0 }}><strong>${st.fullLegalName || st.fullName || "—"}</strong></p>
            <p class="muted" style=${{ margin: "0.25rem 0 0", fontSize: "0.9rem" }}>
              ${st.regNumber || "No reg"} · ${st.program || "Programme TBD"} · ${st.email || ""}
            </p>
          </div>
          <div style=${{ textAlign: "right" }}>
            <p class="muted" style=${{ margin: 0, fontSize: "0.75rem" }}>Modules published</p>
            <p style=${{ margin: 0, fontSize: "1.5rem", fontWeight: 800 }}>${rows.length}</p>
            <p class="muted" style=${{ margin: "0.25rem 0 0", fontSize: "0.75rem" }}>Average ${avg != null ? avg : "—"}</p>
            ${locked ? html`<span class="badge paid">Locked</span>` : html`<span class="badge pending">Open</span>`}
          </div>
        </div>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Code</th><th>Module</th>${transcriptCols(rows).map((c) => html`<th key=${c.key}>${c.label}</th>`)}<th>Score</th><th>Grade</th><th>Remark</th></tr></thead>
            <tbody>
              ${rows.length === 0 ? html`<tr><td colspan="99" class="muted">No published grades for this student.</td></tr>` : null}
              ${rows.map((g) => html`<tr key=${g.id}>
                <td><code>${g.courseCode || "—"}</code></td>
                <td>${g.courseTitle || "—"}</td>
                ${transcriptCols(rows).map((c) => html`<td key=${c.key}>${componentCell(g, c.key)}</td>`)}
                <td>${g.score != null ? g.score : "—"}</td>
                <td><strong style=${{ color: gradeColor(g.grade) }}>${g.grade || "—"}</strong></td>
                <td class="muted">${g.remark || ""}</td>
              </tr>`)}
            </tbody>
          </table>
        </div>
        <p class="muted" style=${{ fontSize: "0.75rem", marginTop: "1rem" }}>Generated from published results. Not a sealed certificate — use Certificates for formal awards.</p>
        <div class="no-print" style=${{ display: "flex", gap: "0.5rem", flexWrap: "wrap", marginTop: "1rem" }}>
          <button class="primary" type="button" onClick=${printSheet}>Print / PDF</button>
          <button class="ghost" type="button" disabled=${busy} onClick=${() => setLock(!locked)}>
            ${locked ? "Unlock transcript" : "Lock transcript"}
          </button>
        </div>
      </div>
    ` : html`<p class="muted" style=${{ marginTop: "1rem" }}>Choose a student to view their transcript.</p>`}
  </div>`;
}



function ResultsSummaryPanel() {
  const [students, setStudents] = useState([]);
  const [grades, setGrades] = useState([]);
  const [program, setProgram] = useState("all");
  const [err, setErr] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const api = await getDb();
        const [ss, gs] = await Promise.all([
          api.getDocs(api.collection(api.db, "students")),
          api.getDocs(api.collection(api.db, "grades"))
        ]);
        const sl = []; ss.forEach((d) => { if (d.data().trashed !== true) sl.push({ id: d.id, ...d.data() }); });
        sl.sort((a, b) => String(a.fullLegalName || a.fullName || "").localeCompare(String(b.fullLegalName || b.fullName || "")));
        const gl = []; gs.forEach((d) => gl.push({ id: d.id, ...d.data() }));
        setStudents(sl); setGrades(gl);
      } catch (e) { setErr(e.message || String(e)); }
    })();
  }, []);

  const published = grades.filter((g) => g.published !== false && numOrNull(g.score) != null);
  const programs = Array.from(new Set(students.map((s) => s.program).filter(Boolean)));
  const shown = students.filter((s) => program === "all" || s.program === program);
  const out = shown.map((s) => {
    const mine = published.filter((g) => g.studentId === s.id);
    const n = mine.length;
    const avg = n ? Math.round((mine.reduce((t, g) => t + Number(g.score), 0) / n) * 10) / 10 : null;
    return { s, n, avg, band: bandOf(avg) };
  });
  const withResults = out.filter((r) => r.n > 0);
  const classAvg = withResults.length ? Math.round((withResults.reduce((t, r) => t + r.avg, 0) / withResults.length) * 10) / 10 : null;

  return html`<div>
    <h1>Results summary</h1>
    <p class="muted no-print">Aggregate of published results per student. Average is the mean of published scores. Band uses the preliminary scale A 70+, B 60+, C 50+, D 45+, E 40+, F below 40.</p>
    ${err ? html`<p class="error">${err}</p>` : null}
    <div class="no-print" style=${{ display: "flex", gap: "0.5rem", flexWrap: "wrap", alignItems: "center", marginBottom: "0.75rem" }}>
      <select value=${program} onChange=${(e) => setProgram(e.target.value)}>
        <option value="all">All programmes</option>
        ${programs.map((p) => html`<option key=${p} value=${p}>${p}</option>`)}
      </select>
      <button class="primary" type="button" onClick=${() => { try { window.print(); } catch (_) {} }}>Print summary</button>
    </div>
    <div class="card summary-print" style=${{ padding: "1rem" }}>
      <div style=${{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: "0.5rem", marginBottom: "0.75rem" }}>
        <div><strong>CGTIA · Results summary</strong><div class="muted" style=${{ fontSize: "0.8rem" }}>${new Date().toLocaleDateString("en-GB")}${program !== "all" ? " · " + program : ""}</div></div>
        <div class="muted" style=${{ fontSize: "0.85rem" }}>${shown.length} students · ${withResults.length} with results · class average ${classAvg != null ? classAvg + "%" : "—"}</div>
      </div>
      <div class="table-wrap"><table>
        <thead><tr><th>#</th><th>Student</th><th>Reg</th><th>Programme</th><th>Published results</th><th>Average %</th><th>Band</th></tr></thead>
        <tbody>
          ${out.length === 0 ? html`<tr><td colspan="7" class="muted">No students.</td></tr>` : null}
          ${out.map((r, i) => html`<tr key=${r.s.id}>
            <td>${i + 1}</td>
            <td>${r.s.fullLegalName || r.s.fullName || r.s.email}</td>
            <td><code>${r.s.regNumber || "—"}</code></td>
            <td>${r.s.program || "—"}</td>
            <td>${r.n}</td>
            <td>${r.avg != null ? r.avg + "%" : "—"}</td>
            <td><strong style=${{ color: gradeColor(r.band) }}>${r.band}</strong></td>
          </tr>`)}
        </tbody>
      </table></div>
    </div>
  </div>`;
}

function NotificationsPanel() {
  const [rows, setRows] = useState([]);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [audience, setAudience] = useState("all");
  const [program, setProgram] = useState("");
  const [email, setEmail] = useState("");
  const [linkUrl, setLinkUrl] = useState("");
  const [err, setErr] = useState("");

  async function load() {
    try {
      const api = await getDb();
      const snap = await api.getDocs(api.collection(api.db, "portalNotifications"));
      const list = [];
      snap.forEach((d) => list.push({ id: d.id, ...d.data() }));
      list.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
      setRows(list);
    } catch (e) { setErr(e.message || String(e)); }
  }
  useEffect(() => { load(); }, []);

  async function save(e) {
    e.preventDefault();
    if (!title.trim()) { toast("Title required", "error"); return; }
    try {
      const api = await getDb();
      const id = "n_" + Date.now().toString(36);
      await api.setDoc(api.doc(api.db, "portalNotifications", id), {
        title: title.trim(),
        body: body.trim(),
        audience: audience || "all",
        program: audience === "program" ? program : "",
        email: audience === "student" ? email.trim().toLowerCase() : "",
        linkUrl: linkUrl.trim(),
        active: true,
        createdAt: api.serverTimestamp()
      });
      toast("Notification published to portal", "ok");
      setTitle(""); setBody(""); setLinkUrl("");
      load();
    } catch (ex) { toast(ex.message || "Failed", "error"); }
  }
  async function remove(id) {
    if (!(await askConfirm("Delete this notification?"))) return;
    try {
      const api = await getDb();
      await api.deleteDoc(api.doc(api.db, "portalNotifications", id));
      load();
    } catch (e) { toast(e.message || String(e), "error"); }
  }

  return html`<div>
    <h1>Portal notifications</h1>
    <p class="muted">In-app notices for the student dashboard bell. Students see these in the notification drawer (not SMS/email push unless you add FCM later).</p>
    ${err ? html`<p class="error">${err}</p>` : null}
    <form class="card" style=${{ padding: "1rem", maxWidth: "36rem", marginBottom: "1rem" }} onSubmit=${save}>
      <div class="form-row"><label class="muted">Title</label>
        <input required value=${title} onInput=${(e) => setTitle(e.target.value)} placeholder="Results published" /></div>
      <div class="form-row"><label class="muted">Message</label>
        <textarea rows="3" value=${body} onInput=${(e) => setBody(e.target.value)} placeholder="Your Introduction to Caregiving grade is ready."></textarea></div>
      <div class="form-row"><label class="muted">Audience</label>
        <select value=${audience} onChange=${(e) => setAudience(e.target.value)}>
          <option value="all">All students</option>
          <option value="program">One programme</option>
          <option value="student">One email</option>
        </select></div>
      ${audience === "program" ? html`<div class="form-row"><label class="muted">Programme key</label>
        <input value=${program} onInput=${(e) => setProgram(e.target.value)} placeholder="certificate" /></div>` : null}
      ${audience === "student" ? html`<div class="form-row"><label class="muted">Student email</label>
        <input type="email" value=${email} onInput=${(e) => setEmail(e.target.value)} /></div>` : null}
      <div class="form-row"><label class="muted">Optional link</label>
        <input value=${linkUrl} onInput=${(e) => setLinkUrl(e.target.value)} placeholder="https://…" /></div>
      <button class="primary" type="submit">Send to portal</button>
    </form>
    <div class="table-wrap"><table>
      <thead><tr><th>Title</th><th>Audience</th><th></th></tr></thead>
      <tbody>
        ${rows.length === 0 ? html`<tr><td colspan="3" class="muted">None yet.</td></tr>` : null}
        ${rows.map((r) => html`<tr key=${r.id}>
          <td><strong>${r.title}</strong><br/><span class="muted" style=${{ fontSize: "0.8rem" }}>${(r.body || "").slice(0, 80)}</span></td>
          <td>${r.audience || "all"}${r.program ? " · " + r.program : ""}${r.email ? " · " + r.email : ""}</td>
          <td><button class="ghost" type="button" onClick=${() => remove(r.id)}>Delete</button></td>
        </tr>`)}
      </tbody>
    </table></div>
  </div>`;
}


function StudentsPanel() {
  const empty = {
    fullName: "",
    fullLegalName: "",
    email: "",
    phone: "",
    nin: "",
    dateOfBirth: "",
    nextOfKinName: "",
    nextOfKinPhone: "",
    nextOfKinRelation: "",
    program: "certificate",
    cohort: "",
    regNumber: "",
    status: "active",
    applicationId: "",
    certificateCode: "",
    startDate: "",
    notes: "",
    photoUrl: "",
    profileCompleted: "",
    portalShowFees: true,
    portalShowCourses: true,
    portalShowResults: true
  };
  const [rows, setRows] = useState([]);
  const [form, setForm] = useState({ ...empty });
  const [editId, setEditId] = useState(null);
  const [err, setErr] = useState("");
  const [filter, setFilter] = useState("");
  const [stuTab, setStuTab] = useState("records");
  const [studentPayments, setStudentPayments] = useState([]);
  const [showCashForStudent, setShowCashForStudent] = useState(false);
  const [cashForStudent, setCashForStudent] = useState({
    amount: "",
    feeName: "Tuition",
    feeType: "tuition",
    status: "paid",
    installmentsTotal: "1",
    installmentsPaid: "1",
    notes: ""
  });

  async function load() {
    try {
      const api = await getDb();
      const snap = await api.getDocs(api.collection(api.db, "students"));
      const list = [];
      snap.forEach((d) => { if (d.data().trashed !== true) list.push({ id: d.id, ...d.data() }); });
      list.sort((a, b) => String(a.fullName || "").localeCompare(String(b.fullName || "")));
      setRows(list);
    } catch (e) {
      setErr(e.message || String(e));
    }
  }
  useEffect(() => { load(); }, []);

  async function loadStudentPayments(student) {
    if (!student) { setStudentPayments([]); return; }
    try {
      const api = await getDb();
      const snap = await api.getDocs(api.collection(api.db, "payments"));
      const email = (student.email || "").toLowerCase().trim();
      const reg = (student.regNumber || "").toLowerCase().trim();
      const sid = student.id;
      const list = [];
      snap.forEach((d) => {
        const p = { id: d.id, ...d.data() };
        const pEmail = (p.email || "").toLowerCase().trim();
        const pReg = (p.regNumber || "").toLowerCase().trim();
        const pSid = p.studentId || "";
        if ((sid && pSid === sid) || (email && pEmail && pEmail === email) || (reg && pReg && pReg === reg)) {
          list.push(p);
        }
      });
      list.sort((a, b) => {
        const ta = a.createdAt?.seconds || a.paidAt?.seconds || 0;
        const tb = b.createdAt?.seconds || b.paidAt?.seconds || 0;
        return tb - ta;
      });
      setStudentPayments(list);
    } catch (e) {
      setStudentPayments([]);
    }
  }

  function openNew() {
    setEditId(null);
    setForm({ ...empty });
    setStudentPayments([]);
    setShowCashForStudent(false);
    setStuTab("add");
  }
  function openEdit(row) {
    setEditId(row.id);
    setShowCashForStudent(false);
    loadStudentPayments(row);
    const kin = row.nextOfKin || {};
    setForm({
      fullName: row.fullName || row.fullLegalName || "",
      fullLegalName: row.fullLegalName || row.fullName || "",
      email: row.email || "",
      phone: row.phone || "",
      nin: row.nin || "",
      dateOfBirth: row.dateOfBirth || "",
      nextOfKinName: row.nextOfKinName || kin.name || "",
      nextOfKinPhone: row.nextOfKinPhone || kin.phone || "",
      nextOfKinRelation: row.nextOfKinRelation || kin.relation || "",
      program: row.program || "certificate",
      cohort: row.cohort || "",
      regNumber: row.regNumber || "",
      status: row.status || "active",
      applicationId: row.applicationId || "",
      certificateCode: row.certificateCode || "",
      startDate: row.startDate || "",
      notes: row.notes || "",
      photoUrl: row.photoUrl || "",
      profileCompleted: row.profileCompleted ? "yes" : "",
      portalShowFees: row.portalShowFees !== false,
      portalShowCourses: row.portalShowCourses !== false,
      portalShowResults: row.portalShowResults !== false
    });
    setStuTab("add");
  }
  function cancel() {
    setEditId(null);
    setForm({ ...empty });
    setStudentPayments([]);
    setShowCashForStudent(false);
    setStuTab("records");
  }

  async function save(e) {
    e.preventDefault();
    if (!(form.fullLegalName || form.fullName || "").trim()) { toast("Full name required", "error"); return; }
    const ninDigits = (form.nin || "").replace(/\D/g, "");
    if (ninDigits && ninDigits.length !== 11) {
      toast("NIN should be 11 digits. Check the number and try again.", "error");
      return;
    }
    try {
      const api = await getDb();
      // NIN uniqueness (same NIN on another student)
      if (ninDigits) {
        const snap = await api.getDocs(api.collection(api.db, "students"));
        let taken = false;
        snap.forEach((d) => {
          if (editId && d.id === editId) return;
          const n = String((d.data() || {}).nin || "").replace(/\D/g, "");
          if (n && n === ninDigits) taken = true;
        });
        if (taken) {
          toast("This NIN is already on another student record.", "error");
          return;
        }
      }
      // Reg number uniqueness
      const reg = (form.regNumber || "").trim();
      if (reg) {
        const snap = await api.getDocs(api.collection(api.db, "students"));
        let regTaken = false;
        const regKey = reg.toUpperCase();
        snap.forEach((d) => {
          if (editId && d.id === editId) return;
          if (String((d.data() || {}).regNumber || "").trim().toUpperCase() === regKey) regTaken = true;
        });
        if (regTaken) {
          toast("That reg number is already assigned to another student.", "error");
          return;
        }
      }
      const id = editId || (form.email || form.fullName).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") + "-" + Date.now().toString(36);
      const emailNorm = (form.email || "").trim().toLowerCase();
      const payload = {
        fullName: (form.fullLegalName || form.fullName || "").trim(),
        fullLegalName: (form.fullLegalName || form.fullName || "").trim(),
        email: emailNorm,
        phone: (form.phone || "").trim(),
        nin: ninDigits,
        dateOfBirth: form.dateOfBirth || "",
        nextOfKinName: (form.nextOfKinName || "").trim(),
        nextOfKinPhone: (form.nextOfKinPhone || "").trim(),
        nextOfKinRelation: (form.nextOfKinRelation || "").trim(),
        nextOfKin: {
          name: (form.nextOfKinName || "").trim(),
          phone: (form.nextOfKinPhone || "").trim(),
          relation: (form.nextOfKinRelation || "").trim()
        },
        program: form.program,
        cohort: form.cohort || "",
        regNumber: reg,
        status: form.status || "active",
        // Prefer explicit application id; otherwise email is the applications doc id
        applicationId: (form.applicationId || "").trim() || emailNorm,
        certificateCode: (form.certificateCode || "").trim().toUpperCase(),
        startDate: form.startDate || "",
        notes: form.notes || "",
        photoUrl: form.photoUrl || "",
        portalShowFees: form.portalShowFees !== false,
        portalShowCourses: form.portalShowCourses !== false,
        portalShowResults: form.portalShowResults !== false,
        profileCompleted: form.profileCompleted === true || form.profileCompleted === "yes",
        updatedAt: api.serverTimestamp()
      };
      if (!editId) payload.createdAt = api.serverTimestamp();
      await api.setDoc(api.doc(api.db, "students", id), payload, { merge: true });
      toast(editId ? "Student updated" : "Student saved");
      cancel();
      load();
    } catch (ex) {
      setErr(ex.message || String(ex));
      toast(ex.message || "Save failed", "error");
    }
  }

  async function remove(id) {
    if (!(await askConfirm("Delete this student record?"))) return;
    try {
      const api = await getDb();
      await moveToTrash("students", id);
      toast("Moved to Trash", "ok");
      if (editId === id) cancel();
      load();
    } catch (ex) {
      toast(ex.message || "Delete failed", "error");
    }
  }

  async function generateCertFor(row) {
    if (!row || !row.id) return;
    // Payment completeness check
    try {
      const api = await getDb();
      let incomplete = false;
      let detail = "";
      if (row.email) {
        try {
          const appSnap = await api.getDoc(api.doc(api.db, "applications", String(row.email).toLowerCase()));
          if (appSnap.exists()) {
            const a = appSnap.data() || {};
            const paid = Number(a.installmentsPaid || 0);
            const total = Number(a.installmentsTotal || 1);
            const st = String(a.paymentStatus || a.status || "").toLowerCase();
            if (paid < total || (st && st !== "paid" && st !== "completed")) {
              incomplete = true;
              detail = "Installments " + paid + "/" + total + ", status " + (st || "unknown");
            }
          }
        } catch (e) {}
      }
      if (incomplete) {
        if (!(await askConfirm("Payment may not be complete (" + detail + "). Issue certificate anyway?"))) return;
      }
    } catch (e) {}
    if (String(row.status || "").toLowerCase() !== "graduated") {
      if (!(await askConfirm("Mark as graduated and issue certificate?"))) return;
    }
    try {
      const api = await getDb();
      const certYear = (row.year || row.gradYear || new Date().getFullYear());
      let finalCode = genCertCode(row.fullLegalName || row.fullName || "", new Date().toISOString().slice(0, 10), certYear);
      for (let i = 0; i < 5; i++) {
        const existing = await api.getDoc(api.doc(api.db, "certificates", finalCode));
        if (!existing.exists()) break;
        finalCode = genCertCode(row.fullLegalName || row.fullName || "", new Date().toISOString().slice(0, 10), certYear);
      }
      await api.setDoc(api.doc(api.db, "certificates", finalCode), {
        code: finalCode,
        studentName: row.fullLegalName || row.fullName || "",
        studentId: row.id,
        regNumber: row.regNumber || "",
        program: row.program || "certificate",
        issueDate: new Date().toISOString().slice(0, 10),
        status: "valid",
        email: row.email || "",
        createdAt: api.serverTimestamp(),
        updatedAt: api.serverTimestamp()
      }, { merge: true });
      await api.setDoc(api.doc(api.db, "students", row.id), {
        certificateCode: finalCode,
        status: "graduated",
        updatedAt: api.serverTimestamp()
      }, { merge: true });
      toast("Certificate: " + finalCode);
      load();
    } catch (e) {
      toast(e.message || "Certificate failed", "error");
    }
  }

  const q = filter.trim().toLowerCase();
  const visible = q
    ? rows.filter((r) => [r.fullName, r.fullLegalName, r.email, r.phone, r.program, r.certificateCode, r.cohort, r.regNumber, r.nin].some((x) => String(x || "").toLowerCase().includes(q)))
    : rows;

  return html`
    <div>
      <h1>Students</h1>
      <p class="muted">Full student records. Legal details (NIN, DOB, next of kin) arrive when students submit the private form at /field-check/confirm. You can also edit everything here and link a certificate code.</p>
      ${err ? html`<p class="error">${err}</p>` : null}
      <${SubTabs}
        tabs=${[
          { id: "records", label: "Records (" + rows.length + ")" },
          { id: "payments", label: "Payments" + (editId ? " (" + studentPayments.length + ")" : "") }
        ]}
        active=${stuTab === "add" ? "records" : stuTab}
        onChange=${(id) => {
          setStuTab(id);
        }}
        menu=${null} />
      ${stuTab === "add" ? html`
        <form class="card" onSubmit=${save} style=${{ marginBottom: "1rem" }}>
          <p class="muted">${editId ? "Edit student" : "New student"}</p>
          <div class="form-row">
            <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Full legal name</label>
            <input required value=${form.fullLegalName || form.fullName} onInput=${(e) => setForm({ ...form, fullLegalName: e.target.value, fullName: e.target.value })} />
          </div>
          <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.5rem" }}>
            <div>
              <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>NIN</label>
              <input value=${form.nin} onInput=${(e) => setForm({ ...form, nin: e.target.value })} placeholder="11 digits" />
            </div>
            <div>
              <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Date of birth</label>
              <input type="date" value=${form.dateOfBirth} onInput=${(e) => setForm({ ...form, dateOfBirth: e.target.value })} />
            </div>
          </div>
          <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.5rem" }}>
            <div>
              <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Email</label>
              <input type="email" value=${form.email} onInput=${(e) => setForm({ ...form, email: e.target.value })} />
            </div>
            <div>
              <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Phone</label>
              <input value=${form.phone} onInput=${(e) => setForm({ ...form, phone: e.target.value })} />
            </div>
          </div>
          <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "0.5rem" }}>
            <div>
              <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Next of kin</label>
              <input value=${form.nextOfKinName} onInput=${(e) => setForm({ ...form, nextOfKinName: e.target.value })} />
            </div>
            <div>
              <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Kin phone</label>
              <input value=${form.nextOfKinPhone} onInput=${(e) => setForm({ ...form, nextOfKinPhone: e.target.value })} />
            </div>
            <div>
              <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Relationship</label>
              <input value=${form.nextOfKinRelation} onInput=${(e) => setForm({ ...form, nextOfKinRelation: e.target.value })} />
            </div>
          </div>
          <div class="form-row">
            <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Programme</label>
            <select value=${form.program} onChange=${(e) => setForm({ ...form, program: e.target.value })}>
              <option value="certificate">certificate</option>
              <option value="diploma">diploma</option>
              <option value="higher-diploma">higher-diploma</option>
              <option value="licensing">licensing</option>
            </select>
          </div>
          <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "0.5rem" }}>
            <div>
              <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Cohort</label>
              <input value=${form.cohort} onInput=${(e) => setForm({ ...form, cohort: e.target.value })} placeholder="2025-A" />
            </div>
            <div>
              <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Start date</label>
              <input type="date" value=${form.startDate} onInput=${(e) => setForm({ ...form, startDate: e.target.value })} />
            </div>
            <div>
              <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Status</label>
              <select value=${form.status} onChange=${(e) => setForm({ ...form, status: e.target.value })}>
                <option value="active">active</option>
                <option value="graduated">graduated</option>
                <option value="withdrawn">withdrawn</option>
                <option value="suspended">suspended</option>
              </select>
            </div>
          </div>
          <div class="form-row">
            <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Reg number</label>
            <div style=${{ display: "flex", gap: "0.5rem", flexWrap: "wrap", alignItems: "center" }}>
              <input style=${{ flex: "1", minWidth: "12rem" }} value=${form.regNumber || ""} onInput=${(e) => setForm({ ...form, regNumber: e.target.value.trim() })} placeholder="e.g. 26/CG/492999" />
              <button type="button" class="ghost" onClick=${async () => {
                try {
                  const api = await getDb();
                  const snap = await api.getDocs(api.collection(api.db, "students"));
                  const regs = [];
                  snap.forEach((d) => {
                    if (editId && d.id === editId) return;
                    const r = (d.data() || {}).regNumber;
                    if (r) regs.push(r);
                  });
                  const y = (form.startDate && String(form.startDate).length >= 4)
                    ? String(form.startDate).slice(0, 4)
                    : (form.cohort && /\d{4}/.test(form.cohort) ? form.cohort.match(/\d{4}/)[0] : new Date().getFullYear());
                  const code = genRegNumber(form.program, y, regs);
                  setForm({ ...form, regNumber: code });
                  toast("Reg number: " + code);
                } catch (ex) {
                  toast(ex.message || "Could not generate", "error");
                }
              }}>Generate</button>
            </div>
            <p class="muted" style=${{ fontSize: "0.7rem", margin: "0.25rem 0 0" }}>Same format as profile invite: YY/CG/###### (e.g. 26/CG/492999). Generate creates a free number for walk-ins. You can still type one by hand.</p>
          </div>
          <div class="form-row">
            <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Certificate code (optional link)</label>
            <input value=${form.certificateCode} onInput=${(e) => setForm({ ...form, certificateCode: e.target.value.toUpperCase() })} placeholder="CRT… (issued codes look like CRTAB12CD34)" />
            <p class="muted" style=${{ fontSize: "0.7rem", margin: "0.25rem 0 0" }}>Only if a certificate already exists. New codes are generated from Certificates / Issue — format CRT + letters/numbers, not CGTIA-2026-…</p>
          </div>
          <div class="form-row">
            <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Application link (optional)</label>
            <input value=${form.applicationId} onInput=${(e) => setForm({ ...form, applicationId: e.target.value })} placeholder="Leave blank to use the student email" />
            <p class="muted" style=${{ fontSize: "0.7rem", margin: "0.25rem 0 0" }}>Ties this student to an application record. Applications are stored by email — if you leave this blank, we use the email above.</p>
          </div>
          <div class="form-row">
            <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Photo path / URL</label>
            <input value=${form.photoUrl} onInput=${(e) => setForm({ ...form, photoUrl: e.target.value })} placeholder="/assets/images/graduates/name.webp" />
            <div class="form-row"><label class="muted">Or upload a passport photo</label><input type="file" accept="image/*" onChange=${(e) => uploadStudentPhoto(e, form, setForm)} /><small class="muted">Cropped square, saved to Storage. Max 3 MB.</small></div>
          </div>
          <div class="form-row">
            <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Notes</label>
            <input value=${form.notes} onInput=${(e) => setForm({ ...form, notes: e.target.value })} />
          </div>
          <div class="card" style=${{ marginBottom: "0.75rem", background: "#f8fafc" }}>
            <p class="muted" style=${{ margin: "0 0 0.5rem", fontSize: "0.8rem" }}>Student portal sections (off hides that tab for this student only)</p>
            <div style=${{ display: "flex", flexDirection: "column", gap: "0.45rem" }}>
              <${Toggle} checked=${form.portalShowFees !== false} label="Show Fees" onChange=${(v) => setForm({ ...form, portalShowFees: v })} />
              <${Toggle} checked=${form.portalShowCourses !== false} label="Show Courses" onChange=${(v) => setForm({ ...form, portalShowCourses: v })} />
              <${Toggle} checked=${form.portalShowResults !== false} label="Show Results" onChange=${(v) => setForm({ ...form, portalShowResults: v })} />
            </div>
          </div>
          <div style=${{ display: "flex", gap: "0.5rem", flexWrap: "wrap" }}>
            <button class="primary" type="submit">${editId ? "Update student" : "Save student"}</button>
            <button type="button" class="ghost" onClick=${cancel}>Cancel</button>
            ${editId ? html`<button type="button" class="ghost" onClick=${() => setStuTab("payments")}>View payments</button>` : null}
          </div>
        </form>
      ` : null}
      ${stuTab === "payments" ? html`
        <div class="card" style=${{ marginBottom: "1rem" }}>
          ${!editId ? html`<p class="muted">Open a student from <strong>Records</strong> (Edit), then switch to this tab to see their payment history and record cash payments.</p>` : html`
            <p style=${{ margin: "0 0 0.75rem", fontWeight: 600 }}>Payments for ${form.fullLegalName || form.fullName || form.email || "student"}</p>
            <div style=${{ display: "flex", gap: "0.5rem", marginBottom: "0.75rem", flexWrap: "wrap" }}>
              <button type="button" class=${showCashForStudent ? "primary" : "ghost"} onClick=${() => setShowCashForStudent(!showCashForStudent)}>${showCashForStudent ? "Hide cash form" : "Add cash payment"}</button>
              <button type="button" class="ghost" onClick=${() => loadStudentPayments(rows.find((r) => r.id === editId) || { id: editId, email: form.email })}>Refresh</button>
            </div>
            ${showCashForStudent ? html`
              <form class="card" style=${{ marginBottom: "1rem", background: "#f8fafc" }} onSubmit=${async (e) => {
                e.preventDefault();
                const amount = Number(cashForStudent.amount);
                if (!amount || amount < 1) { toast("Enter amount", "error"); return; }
                try {
                  const api = await getDb();
                  const id = "cash_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 6);
                  const total = Math.min(3, Math.max(1, parseInt(cashForStudent.installmentsTotal, 10) || 1));
                  const paid = Math.min(total, Math.max(0, parseInt(cashForStudent.installmentsPaid, 10) || 1));
                  const status = paid >= total ? "paid" : (paid > 0 ? "partially_paid" : "pending");
                  await api.setDoc(api.doc(api.db, "payments", id), {
                    fullName: form.fullLegalName || form.fullName || "",
                    email: (form.email || "").toLowerCase().trim(),
                    studentId: editId,
                    regNumber: (rows.find((r) => r.id === editId) || {}).regNumber || "",
                    program: form.program || "",
                    amount: amount,
                    amountPaid: amount,
                    method: "cash",
                    channel: "cash",
                    status: status,
                    paymentStatus: status,
                    feeType: cashForStudent.feeType || "tuition",
                    feeName: cashForStudent.feeName || "Tuition",
                    purpose: cashForStudent.feeType || "tuition",
                    installmentsTotal: total,
                    installmentsPaid: paid,
                    notes: cashForStudent.notes || "",
                    reference: id,
                    createdAt: api.serverTimestamp(),
                    paidAt: api.serverTimestamp()
                  });
                  toast("Cash payment recorded");
                  setShowCashForStudent(false);
                  setCashForStudent({ amount: "", feeName: "Tuition", feeType: "tuition", status: "paid", installmentsTotal: "1", installmentsPaid: "1", notes: "" });
                  loadStudentPayments(rows.find((r) => r.id === editId) || { id: editId, email: form.email });
                } catch (ex) {
                  toast(ex.message || "Failed", "error");
                }
              }}>
                <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.5rem" }}>
                  <div>
                    <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Amount (₦)</label>
                    <input required type="number" min="1" value=${cashForStudent.amount} onInput=${(e) => setCashForStudent({ ...cashForStudent, amount: e.target.value })} />
                  </div>
                  <div>
                    <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Fee name</label>
                    <input value=${cashForStudent.feeName} onInput=${(e) => setCashForStudent({ ...cashForStudent, feeName: e.target.value })} />
                  </div>
                </div>
                <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "0.5rem" }}>
                  <div>
                    <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Fee type</label>
                    <select value=${cashForStudent.feeType} onChange=${(e) => setCashForStudent({ ...cashForStudent, feeType: e.target.value })}>
                      <option value="tuition">tuition</option>
                      <option value="graduation">graduation</option>
                      <option value="clinicals">clinicals</option>
                      <option value="id-card">id-card</option>
                      <option value="other">other</option>
                    </select>
                  </div>
                  <div>
                    <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Installments total</label>
                    <select value=${cashForStudent.installmentsTotal} onChange=${(e) => setCashForStudent({ ...cashForStudent, installmentsTotal: e.target.value })}>
                      <option value="1">1</option><option value="2">2</option><option value="3">3</option>
                    </select>
                  </div>
                  <div>
                    <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Installments paid</label>
                    <select value=${cashForStudent.installmentsPaid} onChange=${(e) => setCashForStudent({ ...cashForStudent, installmentsPaid: e.target.value })}>
                      <option value="0">0</option><option value="1">1</option><option value="2">2</option><option value="3">3</option>
                    </select>
                  </div>
                </div>
                <div class="form-row">
                  <label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Notes</label>
                  <input value=${cashForStudent.notes} onInput=${(e) => setCashForStudent({ ...cashForStudent, notes: e.target.value })} />
                </div>
                <button class="primary" type="submit">Save cash payment</button>
              </form>
            ` : null}
            ${studentPayments.length === 0 ? html`<p class="muted">No payments linked to this student yet.</p>` : html`
              <div class="table-wrap">
                <table>
                  <thead>
                    <tr>
                      <th>Date</th>
                      <th>Fee</th>
                      <th>Amount</th>
                      <th>Method</th>
                      <th>Installments</th>
                      <th>Status</th>
                      <th>Ref</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${studentPayments.map((p) => html`
                      <tr key=${p.id}>
                        <td>${p.paidAt?.toDate ? p.paidAt.toDate().toLocaleDateString() : (p.createdAt?.toDate ? p.createdAt.toDate().toLocaleDateString() : "—")}</td>
                        <td>${p.feeName || p.purpose || p.feeType || p.program || "—"}</td>
                        <td>₦${Number(p.amount || p.amountPaid || 0).toLocaleString("en-NG")}</td>
                        <td>${p.method || p.channel || "—"}</td>
                        <td>${(p.installmentsPaid != null ? p.installmentsPaid : "?") + "/" + (p.installmentsTotal || 1)}</td>
                        <td><${Badge} status=${p.status || p.paymentStatus || "pending"} /></td>
                        <td><code style=${{ fontSize: "0.65rem" }}>${(p.reference || p.id || "").toString().slice(0, 14)}</code></td>
                      </tr>
                    `)}
                  </tbody>
                </table>
              </div>
            `}
          `}
        </div>
      ` : null}
      ${stuTab === "records" ? html`
        <div style=${{ display: "flex", gap: "0.5rem", marginBottom: "1rem", flexWrap: "wrap" }}>
          <button class="primary" onClick=${openNew}>Add student</button>
          <input style=${{ flex: "1", minWidth: "180px" }} placeholder="Search name, email, cert code…" value=${filter} onInput=${(e) => setFilter(e.target.value)} />
        </div>
        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Reg no.</th>
                <th>Email</th>
                <th>NIN</th>
                <th>Program</th>
                <th>Profile</th>
                <th>Cert code</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              ${visible.length === 0 ? html`<tr><td colspan="9" class="muted">No students yet. Create a Profile invite and share the link.</td></tr>` : null}
              ${visible.map((r) => html`
                <tr key=${r.id}>
                  <td>${r.fullLegalName || r.fullName || "—"}</td>
                  <td><code style=${{ fontSize: "0.7rem" }}>${r.regNumber || "—"}</code></td>
                  <td>${r.email || "—"}</td>
                  <td><code style=${{ fontSize: "0.7rem" }}>${r.nin ? String(r.nin).slice(0, 3) + "••••" + String(r.nin).slice(-2) : "—"}</code></td>
                  <td>${r.program || "—"}</td>
                  <td>${r.profileCompleted ? "✓ Done" : "—"}</td>
                  <td><code>${r.certificateCode || "—"}</code></td>
                  <td><${Badge} status=${r.status || "active"} /></td>
                  <td style=${{ whiteSpace: "nowrap" }}>
                    <button class="ghost" onClick=${() => openEdit(r)}>Edit</button>
                    <button class="ghost" onClick=${() => { openEdit(r); setStuTab("payments"); }}>Payments</button>
                    <button class="ghost" onClick=${() => generateCertFor(r)}>Issue cert</button>
                    <button class="ghost" onClick=${() => remove(r.id)}>Delete</button>
                  </td>
                </tr>
              `)}
            </tbody>
          </table>
        </div>
      ` : null}
    </div>
  `;
}



function MediaPanel() {
  const SECTIONS_MEDIA = [
    { id: "hero", label: "Hero", folder: "hero/" },
    { id: "gallery", label: "Gallery", folder: "gallery/" },
    { id: "graduates", label: "Graduates", folder: "graduates/" },
    { id: "wall-of-fame", label: "Wall of Fame", folder: "wall-of-fame/" },
    { id: "programs", label: "Programs", folder: "programs/" },
    { id: "partners", label: "Partners", folder: "partners/" },
    { id: "about", label: "About", folder: "about/" },
    { id: "misc", label: "Misc", folder: "misc/" }
  ];
  const [section, setSection] = useState("graduates");
  const [rows, setRows] = useState([]);
  const [form, setForm] = useState({ title: "", path: "", year: "", batch: "A", sort: "0", email: "" });
  const [err, setErr] = useState("");
  const [csvMsg, setCsvMsg] = useState("");

  async function load() {
    try {
      const api = await getDb();
      const snap = await api.getDocs(api.collection(api.db, "siteMedia"));
      const list = [];
      snap.forEach((d) => list.push({ id: d.id, ...d.data() }));
      setRows(list.filter((r) => (r.section || "") === section).sort((a, b) => Number(a.sort || 0) - Number(b.sort || 0)));
    } catch (e) {
      setErr(e.message || String(e));
    }
  }
  useEffect(() => { load(); }, [section]);

  const folderHint = (SECTIONS_MEDIA.find((s) => s.id === section) || {}).folder || "";

  async function save(e) {
    e.preventDefault();
    const path = (form.path || "").trim();
    if (!path) { toast("Path required", "error"); return; }
    try {
      const api = await getDb();
      const id = (section + "-" + (form.year || "") + "-" + (form.batch || "") + "-" + (form.title || "img")).toLowerCase().replace(/[^a-z0-9]+/g, "-").slice(0, 60) + "-" + Date.now().toString(36);
      await api.setDoc(api.doc(api.db, "siteMedia", id), {
        section,
        title: form.title || "",
        path: path.replace(/^\//, ""),
        url: assetUrl(path),
        year: form.year || "",
        batch: form.batch || "",
        email: (form.email || "").trim().toLowerCase(),
        sort: Number(form.sort) || 0,
        updatedAt: api.serverTimestamp()
      }, { merge: true });
      setForm({ title: "", path: "", year: form.year, batch: form.batch, sort: "0", email: "" });
      toast("Saved");
      load();
    } catch (ex) {
      toast(ex.message || "Save failed", "error");
    }
  }

  async function remove(id) {
    if (!(await askConfirm("Remove this media entry?"))) return;
    try {
      const api = await getDb();
      await moveToTrash("siteMedia", id);
      toast("Moved to Trash", "ok");
      load();
    } catch (ex) {
      toast(ex.message || "Remove failed", "error");
    }
  }

  function parseCsv(text) {
    const lines = text.replace(/^\uFEFF/, "").split(/\r?\n/).filter((l) => l.trim());
    if (lines.length < 2) return [];
    const split = (line) => {
      const out = [];
      let cur = "";
      let q = false;
      for (let i = 0; i < line.length; i++) {
        const c = line[i];
        if (c === '"') { q = !q; continue; }
        if (c === "," && !q) { out.push(cur.trim()); cur = ""; continue; }
        cur += c;
      }
      out.push(cur.trim());
      return out;
    };
    const headers = split(lines[0]).map((h) => h.toLowerCase());
    const rows = [];
    for (let i = 1; i < lines.length; i++) {
      const cols = split(lines[i]);
      if (!cols.some(Boolean)) continue;
      const obj = {};
      headers.forEach((h, j) => { obj[h] = cols[j] || ""; });
      rows.push(obj);
    }
    return rows;
  }

  async function onCsvFile(e) {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    setCsvMsg("Importing…");
    try {
      const text = await file.text();
      const parsed = parseCsv(text);
      if (!parsed.length) { setCsvMsg("No data rows found"); return; }
      const api = await getDb();
      let ok = 0;
      for (const row of parsed) {
        const sec = (row.section || section || "graduates").trim();
        const path = (row.path || row.file || row.filename || "").trim().replace(/^\//, "");
        if (!path) continue;
        const title = row.title || row.name || row.studentname || "";
        const year = row.year || "";
        const batch = row.batch || row.cohort || "";
        const email = (row.email || "").trim().toLowerCase();
        const sort = Number(row.sort || 0) || 0;
        const id = (sec + "-" + year + "-" + batch + "-" + title + "-" + path).toLowerCase().replace(/[^a-z0-9]+/g, "-").slice(0, 80);
        await api.setDoc(api.doc(api.db, "siteMedia", id || ("media-" + Date.now())), {
          section: sec,
          title,
          path,
          url: assetUrl(path),
          year,
          batch,
          email,
          sort,
          updatedAt: api.serverTimestamp()
        }, { merge: true });
        ok++;
      }
      setCsvMsg("Imported " + ok + " row(s).");
      toast("CSV import done: " + ok);
      load();
    } catch (err) {
      setCsvMsg(err.message || "Import failed");
      toast(err.message || "Import failed", "error");
    }
    e.target.value = "";
  }

  return html`
    <div>
      <h1>Images / media registry</h1>
      <p class="muted">Pictures are stored on the picture server. Upload new pictures there, then type the picture's name here. The full web address is filled in for you.</p>
      ${err ? html`<p class="error">${err}</p>` : null}
      <div style=${{ display: "flex", flexWrap: "wrap", gap: "0.35rem", marginBottom: "1rem" }}>
        ${SECTIONS_MEDIA.map((s) => html`<button type="button" class=${section === s.id ? "primary" : "ghost"} key=${s.id} onClick=${() => setSection(s.id)}>${s.label}</button>`)}
      </div>
      <div class="card" style=${{ marginBottom: "1rem" }}>
        <p class="muted" style=${{ marginBottom: "0.5rem" }}><strong>Bulk import from a spreadsheet</strong> — the columns are: section, year, batch, title, path, email, sort</p>
        <p class="muted" style=${{ fontSize: "0.75rem" }}>Example path: <code>graduates/2025/A/ada-okonkwo.webp</code>. Create the file in Google Sheets or Excel → Download as CSV.</p>
        <input type="file" accept=".csv,text/csv" onChange=${onCsvFile} />
        ${csvMsg ? html`<p class="muted" style=${{ marginTop: "0.5rem" }}>${csvMsg}</p>` : null}
      </div>
      <p class="muted">Folder hint: <code>${folderHint}</code></p>
      <form class="card" onSubmit=${save} style=${{ marginBottom: "1rem" }}>
        <div class="form-row"><label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Title / name</label><input value=${form.title} onInput=${(e) => setForm({ ...form, title: e.target.value })} /></div>
        <div class="form-row"><label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Path (under assets site)</label><input required value=${form.path} onInput=${(e) => setForm({ ...form, path: e.target.value })} placeholder=${folderHint + "2025/A/name.webp"} /></div>
        <div class="form-row"><label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Email (optional, for graduates)</label><input type="email" value=${form.email} onInput=${(e) => setForm({ ...form, email: e.target.value })} /></div>
        <div class="form-row" style=${{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "0.5rem" }}>
          <div><label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Year</label><input value=${form.year} onInput=${(e) => setForm({ ...form, year: e.target.value })} placeholder="2025" /></div>
          <div><label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Batch</label><input value=${form.batch} onInput=${(e) => setForm({ ...form, batch: e.target.value })} placeholder="A" /></div>
          <div><label style=${{ fontSize: "0.75rem", color: "#64748b" }}>Sort</label><input value=${form.sort} onInput=${(e) => setForm({ ...form, sort: e.target.value })} /></div>
        </div>
        <button class="primary" type="submit">Add image entry</button>
      </form>
      <div style=${{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(140px, 1fr))", gap: "0.75rem" }}>
        ${rows.length === 0 ? html`<p class="muted">No entries yet.</p>` : null}
        ${rows.map((r) => html`
          <div class="card" key=${r.id} style=${{ padding: "0.5rem" }}>
            <div style=${{ aspectRatio: "1", background: "#f1f5f9", borderRadius: "0.75rem", overflow: "hidden", marginBottom: "0.35rem" }}>
              <img src=${r.url || assetUrl(r.path)} alt="" style=${{ width: "100%", height: "100%", objectFit: "cover" }} onError=${(e) => { e.target.style.opacity = "0.3"; }} />
            </div>
            <p style=${{ fontSize: "0.7rem", margin: 0 }}>${r.title || "—"}</p>
            <p class="muted" style=${{ fontSize: "0.65rem" }}>${[r.year, r.batch, r.email].filter(Boolean).join(" · ")}</p>
            <button class="ghost" type="button" onClick=${() => remove(r.id)}>Remove</button>
          </div>
        `)}
      </div>
    </div>
  `;
}


function downloadJson(filename, data) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function ExportBackupPanel() {
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");

  async function runExport() {
    setBusy(true);
    setMsg("");
    try {
      const api = await getDb();
      const collections = [
        "students", "certificates", "studentInvites", "applications",
        "payments", "promotions", "programs", "wallOfFame", "graduates",
        "partners", "siteContent", "users"
      ];
      const backup = {
        exportedAt: new Date().toISOString(),
        project: "cgtia",
        collections: {}
      };
      for (const name of collections) {
        try {
          const snap = await api.getDocs(api.collection(api.db, name));
          const rows = [];
          snap.forEach((d) => {
            const data = d.data();
            // strip non-serializable timestamps roughly
            const clean = JSON.parse(JSON.stringify(data, (k, v) => {
              if (v && typeof v === "object" && typeof v.toDate === "function") {
                return v.toDate().toISOString();
              }
              if (v && typeof v === "object" && v.seconds != null && v.nanoseconds != null) {
                return new Date(v.seconds * 1000).toISOString();
              }
              return v;
            }));
            rows.push({ id: d.id, ...clean });
          });
          backup.collections[name] = rows;
        } catch (e) {
          backup.collections[name] = { error: e.message || String(e) };
        }
      }
      const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
      downloadJson("cgtia-backup-" + stamp + ".json", backup);
      setMsg("Backup downloaded. Keep this file safe. To restore later you can import docs manually or ask a developer to bulk-write from this JSON.");
      toast("Backup downloaded");
    } catch (e) {
      setMsg(e.message || String(e));
      toast(e.message || "Export failed", "error");
    } finally {
      setBusy(false);
    }
  }

  return html`
    <div>
      <h1>Backup / export</h1>
      <p class="muted">Download a copy of all academy records (students, certificates, invites, applications, payments and website content). Keep it safe as a backup. Images stored only as URLs in the data — the image files themselves live wherever you hosted them (site folder, Drive, CDN).</p>
      <button class="primary" disabled=${busy} onClick=${runExport}>${busy ? "Exporting…" : "Download full backup (.json)"}</button>
      ${msg ? html`<p class="muted" style=${{ marginTop: "1rem" }}>${msg}</p>` : null}
      <div class="card" style=${{ marginTop: "1.5rem" }}>
        <p class="muted"><strong>Photo URLs — any source works</strong></p>
        <ul class="muted" style=${{ fontSize: "0.85rem", lineHeight: "1.5" }}>
          <li>Site file: <code>/assets/images/graduates/name.webp</code></li>
          <li>Full HTTPS URL (CDN, Firebase Storage, Imgur, etc.)</li>
          <li>Google Drive: use a <em>direct</em> image link, not the share page. Format: <code>https://drive.google.com/uc?export=view&amp;id=FILE_ID</code> (file must be “Anyone with the link”)</li>
        </ul>
        <p class="muted" style=${{ marginTop: "0.75rem" }}>In Graduates / Wall of Fame / Certificates, put that path or URL in the <code>photoUrl</code> field. Nothing forces you to keep photos only on the client site.</p>
      </div>
    </div>
  `;
}


function Dashboard({ profile }) {
  const [stats, setStats] = useState({ apps: "—", unpaid: "—", paid: "—", payments: "—" });
  useEffect(() => {
    (async () => {
      try {
        const api = await getDb();
        const snap = await api.getDocs(api.collection(api.db, "applications"));
        let unpaid = 0, paid = 0, total = 0;
        snap.forEach((d) => {
          total++;
          if ((d.data().paymentStatus || "").toLowerCase() === "paid") paid++; else unpaid++;
        });
        let payments = 0;
        try {
          const ps = await api.getDocs(api.collection(api.db, "payments"));
          payments = ps.size;
        } catch (e) {}
        setStats({ apps: total, unpaid, paid, payments });
      } catch (e) {
        setStats({ apps: "?", unpaid: "?", paid: "?", payments: "?" });
      }
    })();
  }, []);
  return html`
    <div>
      <h1>Dashboard</h1>
      <${ProfileBanner} profile=${profile} />
      <div class="grid">
        <div class="card"><div class="label">Applications</div><div class="value">${stats.apps}</div></div>
        <div class="card"><div class="label">Unpaid</div><div class="value">${stats.unpaid}</div></div>
        <div class="card"><div class="label">Paid</div><div class="value">${stats.paid}</div></div>
        <div class="card"><div class="label">Payment records</div><div class="value">${stats.payments}</div></div>
      </div>
      <div class="card">
        <p class="muted"><strong>Promotions on the public site:</strong> when a promotion is Active, the payment screen uses that amount (for matching programmes). No separate banner design required.</p>
      </div>
    </div>
  `;
}


function InsightsPanel() {
  const [stats, setStats] = useState({ apps: 0, paid: 0, unpaid: 0, lastHour: 0, payments: 0, errors: [] });
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    (async () => {
      try {
        const api = await getDb();
        const snap = await api.getDocs(api.collection(api.db, "applications"));
        let paid = 0, unpaid = 0, lastHour = 0;
        const hourAgo = Date.now() - 3600000;
        snap.forEach((d) => {
          const data = d.data();
          if ((data.paymentStatus || "").toLowerCase() === "paid") paid++;
          else unpaid++;
          let t = data.createdAt;
          if (t && t.toMillis) t = t.toMillis();
          else if (t && t.seconds) t = t.seconds * 1000;
          else t = 0;
          if (t >= hourAgo) lastHour++;
        });
        let payments = 0;
        try {
          const ps = await api.getDocs(api.collection(api.db, "payments"));
          payments = ps.size;
        } catch (e) {}
        setStats({ apps: snap.size, paid, unpaid, lastHour, payments, errors: [] });
      } catch (e) {
        setStats((s) => ({ ...s, errors: [e.message || "Could not load insights"] }));
      } finally {
        setLoading(false);
      }
    })();
  }, []);
  return html`
    <div>
      <h1>Insights</h1>
      <p class="sub">Live figures for applications and payments. If something fails on the public website, the site developer can see it.</p>
      ${loading ? html`<${Skeleton} rows=${4} />` : null}
      <div class="grid">
        <div class="card"><div class="label">Applications</div><div class="value">${stats.apps}</div></div>
        <div class="card"><div class="label">Paid</div><div class="value">${stats.paid}</div></div>
        <div class="card"><div class="label">Unpaid</div><div class="value">${stats.unpaid}</div></div>
        <div class="card"><div class="label">New (last hour)</div><div class="value">${stats.lastHour}</div></div>
        <div class="card"><div class="label">Payment records</div><div class="value">${stats.payments}</div></div>
      </div>
      <div class="card">
        <p class="muted"><strong>Rush hour tip:</strong> if “New (last hour)” spikes, check the payment dashboard for failed payments.</p>
        <p class="muted">Detailed traffic reports are not shown here.</p>
        ${stats.errors.map((e) => html`<p class="error">${e}</p>`)}
      </div>
    </div>
  `;
}


function TrashPanel() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [retention, setRetention] = useState(getTrashRetentionDays());
  const [msg, setMsg] = useState("");

  async function load() {
    setLoading(true);
    setErr("");
    try {
      const api = await getDb();
      const days = getTrashRetentionDays();
      const all = [];
      for (const col of TRASH_COLLECTIONS) {
        const snap = await api.getDocs(api.collection(api.db, col));
        snap.forEach((d) => {
          const data = d.data() || {};
          if (!isTrashed(data) && !data.purged) return;
          if (data.purged) return;
          all.push({
            id: d.id,
            collection: col,
            ...data
          });
        });
      }
      // Auto-purge expired trash
      let purged = 0;
      const now = Date.now();
      const kept = [];
      for (const r of all) {
        const purgeMs = parseTime(r.trashPurgeAt) || (parseTime(r.deletedAt) ? parseTime(r.deletedAt) + days * 86400000 : null);
        if (purgeMs && now > purgeMs) {
          try {
            await hardDeleteDoc(r.collection, r.id);
            purged++;
          } catch (e) {}
        } else {
          kept.push(r);
        }
      }
      kept.sort((a, b) => (parseTime(b.deletedAt) || 0) - (parseTime(a.deletedAt) || 0));
      setRows(kept);
      if (purged) setMsg("Auto-purged " + purged + " item(s) past retention.");
    } catch (e) {
      setErr(e.message || String(e));
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { load(); }, []);

  function labelType(col) {
    if (col === "studentInvites") return "Profile invite";
    if (col === "licensingInvites") return "Licensing invite";
    if (col === "feePaymentLinks") return "Payment link";
    if (col === "programs") return "Programme";
    if (col === "promotions") return "Promotion";
    if (col === "certificates") return "Certificate";
    if (col === "students") return "Student record";
    if (col === "siteMedia") return "Media";
    return col;
  }

  function saveRetention(days) {
    setTrashRetentionDays(days);
    setRetention(days);
    toast("New deletes will use " + days + "-day trash retention");
  }

  async function restore(row) {
    try {
      await restoreFromTrash(row.collection, row.id);
      toast("Restored");
      load();
    } catch (e) {
      toast(e.message || "Failed", "error");
    }
  }

  async function destroy(row) {
    if (!(await askConfirm("Permanently delete this item? This cannot be undone."))) return;
    try {
      await hardDeleteDoc(row.collection, row.id);
      toast("Permanently deleted");
      load();
    } catch (e) {
      toast(e.message || "Failed", "error");
    }
  }

  async function emptyTrash() {
    if (!(await askConfirm("Permanently delete ALL items in Trash?"))) return;
    try {
      for (const r of rows) {
        await hardDeleteDoc(r.collection, r.id);
      }
      toast("Trash emptied");
      load();
    } catch (e) {
      toast(e.message || "Failed", "error");
    }
  }

  return html`
    <div>
      <h1>Trash</h1>
      <p class="muted">Deleted profile invites, licensing invites, and payment links stay here until the retention period ends, then they are removed automatically. You can restore or permanently delete sooner.</p>
      ${err ? html`<p class="error">${err}</p>` : null}
      ${msg ? html`<p class="muted">${msg}</p>` : null}

      <div class="card" style=${{ marginBottom: "1rem" }}>
        <p class="muted" style=${{ marginBottom: "0.5rem" }}>Trash retention (for newly deleted items)</p>
        <div style=${{ display: "flex", gap: "0.5rem", flexWrap: "wrap", alignItems: "center" }}>
          <button type="button" class=${retention === 30 ? "primary" : "ghost"} onClick=${() => saveRetention(30)}>30 days</button>
          <button type="button" class=${retention === 90 ? "primary" : "ghost"} onClick=${() => saveRetention(90)}>90 days</button>
          <button type="button" class="ghost" onClick=${load}>Refresh</button>
          ${rows.length ? html`<button type="button" class="ghost" style=${{ color: "#dc2626" }} onClick=${emptyTrash}>Empty trash</button>` : null}
        </div>
      </div>

      <div class="table-wrap">
        <table>
          <thead>
            <tr><th>Type</th><th>Token / id</th><th>Detail</th><th>Deleted</th><th>Purge after</th><th></th></tr>
          </thead>
          <tbody>
            ${loading ? html`<tr><td colspan="6"><${Skeleton} rows=${3} /></td></tr>` : null}
            ${!loading && !rows.length ? html`<tr><td colspan="6" class="muted">Trash is empty.</td></tr>` : null}
            ${rows.map((r) => html`
              <tr key=${r.collection + "/" + r.id}>
                <td>${labelType(r.collection)}</td>
                <td><code style=${{ fontSize: "0.75rem" }}>${String(r.id).slice(0, 16)}…</code></td>
                <td class="muted" style=${{ fontSize: "0.8rem" }}>
                  ${r.feeName || r.email || r.fullName || r.headline || r.name || r.title || r.code || r.feeType || "—"}
                </td>
                <td style=${{ fontSize: "0.75rem" }}>${parseTime(r.deletedAt) ? new Date(parseTime(r.deletedAt)).toLocaleString() : "—"}</td>
                <td style=${{ fontSize: "0.75rem" }}>${parseTime(r.trashPurgeAt) ? new Date(parseTime(r.trashPurgeAt)).toLocaleDateString() : "—"}</td>
                <td style=${{ whiteSpace: "nowrap" }}>
                  <button class="ghost" type="button" onClick=${() => restore(r)}>Restore</button>
                  <button class="ghost" type="button" style=${{ color: "#dc2626" }} onClick=${() => destroy(r)}>Delete forever</button>
                </td>
              </tr>
            `)}
          </tbody>
        </table>
      </div>
    </div>
  `;
}


function SettingsHelp() {
  const [cohortLabel, setCohortLabel] = useState("Enrolling Now / 2026 Cohort");
  const [footerYear, setFooterYear] = useState("2026");
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const api = await getDb();
        const snap = await api.getDoc(api.doc(api.db, "siteContent", "settings"));
        if (snap.exists()) {
          const d = snap.data();
          if (d.cohortLabel) setCohortLabel(d.cohortLabel);
          if (d.footerYear) setFooterYear(String(d.footerYear));
        }
      } catch (e) {}
    })();
  }, []);

  async function saveSite(e) {
    e.preventDefault();
    try {
      const api = await getDb();
      await api.setDoc(api.doc(api.db, "siteContent", "settings"), {
        cohortLabel,
        footerYear: String(footerYear),
        updatedAt: api.serverTimestamp()
      }, { merge: true });
      setMsg("Saved. Public site will show this cohort label after refresh.");
      setErr("");
    } catch (ex) {
      setErr(ex.message || String(ex));
    }
  }

  return html`
    <div>
      <h1>Site settings</h1>
      <p class="sub">Cohort year and labels shown on the public homepage. Programme start dates live under Programs & prices.</p>
      <form class="card" onSubmit=${saveSite}>
        <div class="form-row">
          <label class="muted">Cohort label (homepage)</label>
          <input value=${cohortLabel} onInput=${(e) => setCohortLabel(e.target.value)} placeholder="Enrolling Now / 2026 Cohort" />
        </div>
        <div class="form-row">
          <label class="muted">Footer year</label>
          <input value=${footerYear} onInput=${(e) => setFooterYear(e.target.value)} placeholder="2026" />
        </div>
        <button class="primary">Save site settings</button>
        ${msg ? html`<p class="muted">${msg}</p>` : null}
        ${err ? html`<p class="error">${err}</p>` : null}
      </form>
      <div class="card">
        <h3>Staff profile</h3>
        <p class="muted">Firestore → users → your Auth UID → <code>role: "super-admin"</code>, <code>active: true</code></p>
        <h3>Access levels</h3>
        <p class="muted">super-admin, admin, admissions, licensing-officer, registrar, training-officer, instructor, student</p>
      </div>
    </div>
  `;
}

const NAV_GROUPS = [
  { title: "Overview", icon: "home", items: ["dashboard"] },
  { title: "Admissions", icon: "doc", items: ["applications", "payments", "fees", "invites", "applyForm"] },
  { title: "Students & credentials", icon: "badge", items: ["students", "courses", "assessments", "grades", "transcript", "resultsSummary", "schedule", "attendance", "supportMessages", "answerQueries", "notifications", "certificates", "idcards", "licences", "verifyFields"] },
  { title: "Enquiries", icon: "inbox", items: ["contact", "institutional", "licrequests", "licinvites"] },
  { title: "Website", icon: "globe", items: ["promotions", "dashboardSlides", "programs", "homePage", "aboutPage", "galleryPage", "programsPage", "tuitionPage", "contactPage", "legalPages", "pageControl", "wall", "graduates", "partners", "insights", "media"] },
  { title: "Team & system", icon: "gear", items: ["users", "portalSettings", "backup", "trash", "settings"] }
];
const ICON_PATHS = {
  home: "M3 10.5 12 3l9 7.5V21a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z",
  doc: "M7 3h7l5 5v13a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1zM14 3v5h5M9 13h6M9 17h6",
  badge: "M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6zM9 12l2 2 4-4",
  inbox: "M4 13l2-8h12l2 8v6H4zM4 13h4l1 2h6l1-2h4",
  globe: "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM3 12h18M12 3c2.5 3 2.5 15 0 18M12 3c-2.5 3-2.5 15 0 18",
  gear: "M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM4 12h2M18 12h2M12 4v2M12 18v2M6.3 6.3l1.4 1.4M16.3 16.3l1.4 1.4M6.3 17.7l1.4-1.4M16.3 7.7l1.4-1.4",
  other: "M4 6h16M4 12h16M4 18h16",
  menu: "M4 6h16M4 12h16M4 18h16",
  close: "M6 6l12 12M18 6L6 18",
  search: "M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM16 16l5 5",
  logout: "M9 21H5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h4M16 17l5-5-5-5M21 12H9",
  chevron: "M9 6l6 6-6 6",
  updown: "M8 9l4-4 4 4M8 15l4 4 4-4",
  user: "M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4 21a8 8 0 0 1 16 0",
  refresh: "M4 4v5h5M20 20v-5h-5M5.6 15a7 7 0 0 0 12.3 1.5M18.4 9A7 7 0 0 0 6 7.5",
  dots: "M5 12h.01M12 12h.01M19 12h.01",
  bell: "M6 8a6 6 0 1 1 12 0c0 7 3 8 3 8H3s3-1 3-8M10 20a2 2 0 0 0 4 0"
};
function Icon({ name, size }) {
  const s = size || 18;
  return html`<svg width=${s} height=${s} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d=${ICON_PATHS[name] || ICON_PATHS.other} /></svg>`;
}

function Skeleton({ rows }) {
  const n = rows || 4;
  return html`<div class="skel-wrap" aria-hidden="true">${Array.from({ length: n }).map((_, i) => html`<div class="skel-row" key=${i} style=${{ width: (100 - ((i * 13) % 35)) + "%" }}></div>`)}</div>`;
}
function BootLoader() {
  return html`<div class="boot" role="status"><div class="boot-spin"></div><p>Loading…</p></div>`;
}

function PageSkeleton() {
  return html`<div class="page-skel" aria-hidden="true">
    <div class="skel-block" style=${{ width: "42%", height: "30px" }}></div>
    <div class="skel-block" style=${{ width: "78%", height: "14px", marginTop: "12px" }}></div>
    <div class="skel-block" style=${{ width: "58%", height: "14px", marginTop: "8px" }}></div>
    <div class="skel-card">
      <div class="skel-block" style=${{ width: "36%", height: "16px" }}></div>
      <div class="skel-block" style=${{ width: "100%", height: "12px", marginTop: "16px" }}></div>
      <div class="skel-block" style=${{ width: "92%", height: "12px", marginTop: "10px" }}></div>
      <div class="skel-block" style=${{ width: "70%", height: "12px", marginTop: "10px" }}></div>
    </div>
    <div class="skel-card">
      <div class="skel-block" style=${{ width: "30%", height: "16px" }}></div>
      <div class="skel-block" style=${{ width: "100%", height: "12px", marginTop: "16px" }}></div>
      <div class="skel-block" style=${{ width: "84%", height: "12px", marginTop: "10px" }}></div>
    </div>
  </div>`;
}

function ProfilePage({ user, profile, notes, onSignOut }) {
  const role = profile && profile.role ? profile.role : "staff";
  const active = !(profile && profile.active === false);
  return html`<div>
    <h1>My profile</h1>
    <div class="card">
      <p class="muted">Signed in as</p>
      <p><strong>${user ? user.email : ""}</strong></p>
      <p class="muted">Access level: <strong>${role}</strong></p>
      <p class="muted">Status: <strong>${active ? "On" : "Turned off"}</strong></p>
      <button class="ghost" type="button" onClick=${async () => { if (await askConfirm("Sign out of the admin?", { okText: "Sign out" })) onSignOut(); }}>Sign out</button>
    </div>
    <div class="card">
      <h2 class="card-title">Recent activity</h2>
      ${notes.length
        ? notes.slice(0, 20).map((n) => html`<div class="note-row" key=${n.id}><strong>${n.title}</strong><span>${n.text}</span><small>${new Date(n.at).toLocaleString()}</small></div>`)
        : html`<p class="muted">Nothing has come in yet.</p>`}
    </div>
  </div>`;
}

/* Dropdowns: the native list is replaced with a styled one; the value stays in the real field */
let selectsWired = false;
function enhanceSelects(root) {
  root.querySelectorAll("select").forEach(function (sel) {
    if (sel.dataset.enhanced === "1") return;
    sel.dataset.enhanced = "1";
    sel.style.display = "none";
    const wrap = document.createElement("div");
    wrap.className = "sel-wrap";
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "sel-btn";
    const list = document.createElement("div");
    list.className = "sel-list";
    list.hidden = true;
    wrap.append(btn, list);
    sel.after(wrap);
    const showValue = function () {
      const opt = sel.options[sel.selectedIndex];
      const text = opt ? opt.textContent : "Choose";
      if (btn.textContent !== text) btn.textContent = text;
      btn.disabled = sel.disabled;
    };
    const buildList = function () {
      list.innerHTML = "";
      Array.from(sel.options).forEach(function (o, i) {
        const it = document.createElement("button");
        it.type = "button";
        it.className = "sel-opt" + (i === sel.selectedIndex ? " on" : "");
        it.textContent = o.textContent;
        it.addEventListener("click", function (e) {
          e.stopPropagation();
          sel.selectedIndex = i;
          sel.dispatchEvent(new Event("change", { bubbles: true }));
          list.hidden = true;
          showValue();
        });
        list.appendChild(it);
      });
    };
    btn.addEventListener("click", function (e) {
      e.stopPropagation();
      document.querySelectorAll(".sel-list").forEach(function (l) { if (l !== list) l.hidden = true; });
      if (list.hidden) buildList();
      list.hidden = !list.hidden;
    });
    sel._showValue = showValue;
    showValue();
  });
  if (!selectsWired) {
    selectsWired = true;
    document.addEventListener("click", function () {
      document.querySelectorAll(".sel-list").forEach(function (l) { l.hidden = true; });
    });
    setInterval(function () {
      document.querySelectorAll("select[data-enhanced='1']").forEach(function (sel) { if (sel._showValue) sel._showValue(); });
    }, 500);
  }
}

function Toggle({ checked, onChange, label }) {
  return html`<label class="toggle">
    <input type="checkbox" checked=${!!checked} onChange=${(e) => onChange(!!e.target.checked)} />
    <span class="toggle-track" aria-hidden="true"></span>
    ${label ? html`<span>${label}</span>` : null}
  </label>`;
}

/* Sub-page tabs with a "..." menu (like Cloudflare's Metrics | Custom domains | Settings) */
function SubTabs({ tabs, active, onChange, menu }) {
  const [open, setOpen] = useState(false);
  const items = (menu || []).filter(Boolean);
  return html`<div class="subtabs">
    <div class="subtabs-row" role="tablist">
      ${tabs.map((t) => html`<button key=${t.id} type="button" role="tab" aria-selected=${active === t.id ? "true" : "false"} class=${"subtab" + (active === t.id ? " on" : "")} onClick=${() => onChange(t.id)}>${t.label}</button>`)}
    </div>
    ${items.length ? html`<div class="subtabs-more">
      <button type="button" class="icon-btn" aria-label="More options" aria-expanded=${open ? "true" : "false"} onClick=${() => setOpen(!open)}><${Icon} name="dots" /></button>
      ${open ? html`<div class="subtabs-menu" role="menu">${items.map((m) => html`<button key=${m.label} type="button" role="menuitem" class=${m.checked ? "on" : ""} onClick=${() => { setOpen(false); if (m.run) m.run(); }}>${m.checked ? "✓ " : ""}${m.label}</button>`)}</div>` : null}
    </div>` : null}
  </div>`;
}

function App() {
  const [navQuery, setNavQuery] = useState("");
  const [rail, setRail] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [openGroups, setOpenGroups] = useState({});
  const [gate, setGate] = useState(true);
  const [reloadKey, setReloadKey] = useState(0);
  const [notes, setNotes] = useState([]);
  const [unread, setUnread] = useState(0);
  const [notifyOpen, setNotifyOpen] = useState(false);
  useEffect(() => {
    const onKey = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        const el = document.getElementById("navSearch");
        if (el) el.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);
  useEffect(() => {
    const labelTables = () => {
      enhanceSelects(document.body);
      document.querySelectorAll("main table").forEach((t) => {
        const heads = Array.from(t.querySelectorAll("thead th")).map((th) => th.textContent.trim());
        if (!heads.length) return;
        t.querySelectorAll("tbody tr").forEach((tr) => {
          Array.from(tr.children).forEach((td, i) => {
            if (td.tagName === "TD" && heads[i]) td.setAttribute("data-label", heads[i]);
          });
        });
      });
    };
    labelTables();
    let timer = null;
    const obs = new MutationObserver(() => { clearTimeout(timer); timer = setTimeout(labelTables, 60); });
    obs.observe(document.body, { childList: true, subtree: true });
    return () => obs.disconnect();
  }, []);
  function openNotes() {
    localStorage.setItem("cgtiaSeenAt", String(Date.now()));
    setUnread(0);
    setNotifyOpen(true);
  }

  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [section, setSection] = useState("dashboard");
  useEffect(() => {
    // Every page shows its full skeleton for at least three seconds
    setGate(true);
    const t = setTimeout(() => setGate(false), 3000);
    return () => clearTimeout(t);
  }, [section, reloadKey]);
  useEffect(() => {
    if (!user) return;
    let alive = true;
    let timer = null;
    const toMs = (v) => (v && v.toMillis ? v.toMillis() : v ? Date.parse(v) || 0 : 0);
    // col → admin section to open when the notification is tapped
    const feeds = [
      ["payments", "payments", "Payment received", (d) => (d.fullName || d.email || "Someone") + " paid ₦" + Number(d.amountPaid || d.amount || 0).toLocaleString()],
      ["applications", "applications", "New application", (d) => (d.fullName || d.email || "Someone") + " applied"],
      ["contactMessages", "contact", "New message", (d) => (d.name || d.email || "Someone") + " sent a message"],
      ["licensingRequests", "licrequests", "Licensing request", (d) => (d.fullName || d.email || "Someone") + " requested licensing"]
    ];
    const poll = async () => {
      try {
        const api = await getDb();
        const items = [];
        for (const [col, sectionId, title, text] of feeds) {
          try {
            const snap = await api.getDocs(api.collection(api.db, col));
            snap.forEach((doc) => {
              const d = doc.data();
              const at = toMs(d.createdAt || d.paidAt || d.submittedAt);
              if (at) items.push({
                id: col + ":" + doc.id,
                col,
                section: sectionId,
                docId: doc.id,
                title,
                text: text(d),
                at
              });
            });
          } catch (e) { /* collection may be empty / rules */ }
        }
        items.sort((x, y) => y.at - x.at);
        let seen = Number(localStorage.getItem("cgtiaSeenAt") || 0);
        if (!seen) { seen = Date.now(); localStorage.setItem("cgtiaSeenAt", String(seen)); }
        if (alive) {
          setNotes(items.slice(0, 40));
          setUnread(items.filter((i) => i.at > seen).length);
        }
      } catch (e) { /* try again on the next round */ }
      if (alive) timer = setTimeout(poll, 60000);
    };
    poll();
    return () => { alive = false; clearTimeout(timer); };
  }, [user]);
  useEffect(() => {
    // Lets any page (for example the "..." menu) ask for a full refresh
    const onRefresh = () => setReloadKey((k) => k + 1);
    window.addEventListener("cgtia:refresh", onRefresh);
    return () => window.removeEventListener("cgtia:refresh", onRefresh);
  }, []);
  const [boot, setBoot] = useState(true);
  const [authError, setAuthError] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const api = await getDb();
        api.onAuthStateChanged(api.auth, async (u) => {
          setAuthError("");
          setUser(u);
          if (u) {
            const prof = await getMyProfile();
            setProfile(prof);
            // Signed in but not allowed staff → sign out and force login
            if (!isStaffAllowed(prof)) {
              setAuthError(
                prof && prof.missing
                  ? "Your account is not on the staff list yet. Ask the site owner to add you."
                  : "Your access is turned off. Ask the site owner to turn it on."
              );
              try { await api.signOut(api.auth); } catch (e) {}
              setUser(null);
              setProfile(null);
            }
          } else {
            setProfile(null);
          }
          setBoot(false);
        });
      } catch (e) {
        setBoot(false);
        setAuthError(friendlyFirebaseError(e) || "Sign-in could not start. Please refresh the page.");
      }
    })();
  }, []);

  if (boot) return html`<${BootLoader} />`;
  if (!user) return html`
    <div>
      ${authError ? html`<div class="login" style=${{ paddingBottom: "0", maxWidth: "28rem", margin: "1rem auto 0" }}>
        <p class="error" role="alert" style=${{ margin: 0 }}>${authError}</p>
        <button type="button" class="ghost" style=${{ marginTop: "0.75rem" }} onClick=${() => window.location.reload()}>Try again</button>
      </div>` : null}
      <${Login} onAuthed=${async (u) => {
        setUser(u);
        const prof = await getMyProfile();
        setProfile(prof);
        if (!isStaffAllowed(prof)) {
          setAuthError(
            prof && prof.missing
              ? "Your account is not on the staff list yet. Ask the site owner to add you."
              : "Your access is turned off. Ask the site owner to turn it on."
          );
          const api = await getDb();
          try { await api.signOut(api.auth); } catch (e) {}
          setUser(null);
          setProfile(null);
        }
      }} />
    </div>
  `;

  async function logout() {
    const api = await getDb();
    await api.signOut(api.auth);
    setUser(null);
    setProfile(null);
  }

  let panel = null;
  if (section === "dashboard") panel = html`<${Dashboard} profile=${profile} />`;
  else if (section === "applications") panel = html`<${ApplicationsPanel} />`;
  else if (section === "payments") panel = html`<${PaymentsPanel} />`;
  else if (section === "fees") panel = html`<${FeesPanel} />`;
  else if (section === "users") panel = html`<${UsersPanel} myProfile=${profile} />`;
  else if (section === "promotions") panel = html`<${PromotionsPanel} />`;
  else if (section === "dashboardSlides") panel = html`<${DashboardSlidesPanel} />`;
  else if (section === "programs") panel = html`<${ProgramsPanel} />`;
  else if (section === "homePage") panel = html`<${HomePageEditor} />`;
  else if (section === "aboutPage") panel = html`<${AboutPageEditor} />`;
  else if (section === "galleryPage") panel = html`<${GalleryPageEditor} />`;
  else if (section === "programsPage") panel = html`<${ProgramsPageEditor} />`;
  else if (section === "tuitionPage") panel = html`<${TuitionPageEditor} />`;
  else if (section === "legalPages") panel = html`<${LegalPagesEditor} />`;
  else if (section === "applyForm") panel = html`<${ApplyFormEditor} />`;
  else if (section === "pageControl") panel = html`<${PageControlPanel} />`;
  else if (section === "verifyFields") panel = html`<${VerifyFieldsPanel} />`;
  else if (section === "students") panel = html`<${StudentsPanel} />`;
  else if (section === "portalSettings") panel = html`<${PortalSettingsPanel} />`;
  else if (section === "courses") panel = html`<${CoursesPanel} />`;
  else if (section === "assessments") panel = html`<${AssessmentsPanel} />`;
  else if (section === "grades") panel = html`<${GradesPanel} />`;
  else if (section === "transcript") panel = html`<${TranscriptPanel} />`;
  else if (section === "resultsSummary") panel = html`<${ResultsSummaryPanel} />`;
  else if (section === "notifications") panel = html`<${NotificationsPanel} />`;
  else if (section === "schedule") panel = html`<${SchedulePanel} />`;
  else if (section === "attendance") panel = html`<${AttendancePanel} />`;
  else if (section === "supportMessages") panel = html`<${SupportMessagesPanel} />`;
  else if (section === "answerQueries") panel = html`<${AnswerQueriesPanel} />`;
  else if (section === "invites") panel = html`<${InvitesPanel} />`;
  else if (section === "certificates") panel = html`<${CertificatesPanel} />`;
  else if (section === "idcards") panel = html`<${IdCardsPanel} />`;
  else if (section === "licences") panel = html`<${LicencesPanel} />`;
  else if (section === "wall") panel = html`<${SimpleCrud} title="Wall of Fame" collection="wallOfFame" fields=${["studentName", "program", "year", "rank", "quote", "photoUrl"]} pathHint=${"photoUrl example: /assets/images/wall-of-fame/name.webp"} />`;
  else if (section === "graduates") panel = html`<${SimpleCrud} title="Graduates" collection="graduates" fields=${["studentName", "program", "year", "activity", "photoUrl"]} pathHint=${"photoUrl example: /assets/images/graduates/name.webp"} />`;
  else if (section === "partners") panel = html`<${PartnersPanel} />`;
  else if (section === "contact") panel = html`<${ContactPanel} />`;
  else if (section === "contactPage") panel = html`<${ContactPageEditor} />`;
  else if (section === "institutional") panel = html`<${InstitutionalPanel} />`;
  else if (section === "licrequests") panel = html`<${LicensingRequestsPanel} />`;
  else if (section === "licinvites") panel = html`<${LicensingInvitesPanel} />`;
  else if (section === "insights") panel = html`<${InsightsPanel} />`;
  else if (section === "media") panel = html`<${MediaPanel} />`;
  else if (section === "backup") panel = html`<${ExportBackupPanel} />`;
  else if (section === "trash") panel = html`<${TrashPanel} />`;
  else if (section === "settings") panel = html`<${SettingsHelp} />`;
  else panel = html`<${SettingsHelp} />`;

  const q = navQuery.trim().toLowerCase();
  const labelOf = Object.fromEntries(SECTIONS);
  const matches = (id) => !q || labelOf[id].toLowerCase().includes(q) || (SECTION_KEYWORDS[id] || "").toLowerCase().includes(q);
  const groups = NAV_GROUPS
    .map((g) => ({ ...g, items: g.items.filter((id) => labelOf[id] && matches(id)) }))
    .filter((g) => g.items.length);
  const current = SECTIONS.find(([id]) => id === section) || SECTIONS[0];
  const panelEl = section === "profile"
    ? html`<${ProfilePage} user=${user} profile=${profile} notes=${notes} onSignOut=${logout} />`
    : panel;
  const currentGroup = NAV_GROUPS.find((g) => g.items.indexOf(section) >= 0);

  function pick(id) {
    setSection(id);
    setDrawerOpen(false);
    window.scrollTo({ top: 0 });
  }

  return html`
    <div class=${"app" + (rail ? " rail" : "") + (drawerOpen ? " drawer-open" : "")}>
      <header class="topbar">
        <button class="icon-btn menu-btn" type="button" aria-label="Open menu" onClick=${() => setDrawerOpen(!drawerOpen)}><${Icon} name="menu" /></button>
        <button class="icon-btn rail-btn" type="button" aria-label=${rail ? "Expand menu" : "Collapse menu"} onClick=${() => setRail(!rail)}><${Icon} name="menu" /></button>
        <nav class="crumbs" aria-label="Current page">
          ${gate ? html`<span class="skel-inline"></span>` : html`${currentGroup ? html`<span class="crumb-icon"><${Icon} name=${currentGroup.icon} size=18 /></span><strong>${currentGroup.title}</strong>` : html`<strong>${current[1]}</strong>`}`}
        </nav>
        <div class="topbar-right">
          <button class="icon-btn" type="button" aria-label="Refresh this page" onClick=${() => setReloadKey(reloadKey + 1)}><${Icon} name="refresh" /></button>
          <button class="icon-btn bell-wrap" type="button" aria-label=${unread ? unread + " new items" : "Notifications"} onClick=${openNotes}><${Icon} name="bell" />${unread ? html`<span class="bell-badge">${unread > 9 ? "9+" : unread}</span>` : null}</button>
          <button class="icon-btn" type="button" aria-label="My profile" onClick=${() => pick("profile")}><${Icon} name="user" /></button>
        </div>
      </header>

      <aside class="sidebar">
        <div class="drawer-head">
          <button type="button" class="account-switch" aria-label="CGTIA Admin">
            <span class="brand-mark">C</span>
            <span class="brand-text">CGTIA Admin</span>
            <span class="updown"><${Icon} name="updown" size=16 /></span>
          </button>
          <button class="icon-btn close-btn" type="button" aria-label="Close menu" onClick=${() => setDrawerOpen(false)}><${Icon} name="close" /></button>
        </div>
        <label class="search-wrap">
          <${Icon} name="search" size=16 />
          <input id="navSearch" placeholder="Quick search…" value=${navQuery} onInput=${(e) => setNavQuery(e.target.value)} />
          <kbd>Ctrl K</kbd>
        </label>
        <nav class="nav" aria-label="Admin pages">
          ${groups.map((g) => {
            const open = q ? true : (openGroups[g.title] !== undefined ? openGroups[g.title] : g.items.indexOf(section) >= 0);
            return html`
              <div class="nav-group" key=${g.title}>
                <button type="button" class="nav-title" title=${g.title} aria-expanded=${open ? "true" : "false"}
                  onClick=${() => { if (rail) { setRail(false); pick(g.items[0]); } else { setOpenGroups({ ...openGroups, [g.title]: !open }); } }}>
                  <span class="nav-title-icon"><${Icon} name=${g.icon} size=18 /></span>
                  <span class="nav-title-text">${g.title}</span>
                  <span class="nav-chev"><${Icon} name="chevron" size=16 /></span>
                </button>
                ${open ? html`<div class="nav-children">${g.items.map((id) => html`
                  <button key=${id} type="button" class=${"nav-item" + (section === id ? " active" : "")} onClick=${() => pick(id)}>
                    <span class="nav-label">${labelOf[id]}</span>
                  </button>`)}</div>` : null}
              </div>`;
          })}
        </nav>
        <div class="sidebar-foot">
          <p class="muted">${user.email}</p>
          <button type="button" class="nav-item" onClick=${logout}><span class="nav-label">Sign out</span></button>
        </div>
      </aside>
      <div class="scrim" onClick=${() => setDrawerOpen(false)}></div>
      ${notifyOpen ? html`<div class="modal-back" onClick=${(e) => { if (e.target.classList.contains("modal-back")) setNotifyOpen(false); }}>
        <div class="modal sheet-up">
          <h2 class="modal-title">Notifications</h2>
          ${notes.length
            ? html`<div class="note-list">${notes.slice(0, 20).map((n) => html`
                <div class=${"note-row note-row-link"} key=${n.id} role="button" tabindex="0"
                  onClick=${() => {
                    setNotifyOpen(false);
                    if (n.section) {
                      setSection(n.section);
                      setDrawerOpen(false);
                    }
                  }}
                  onKeyDown=${(e) => {
                    if (e.key === "Enter" || e.key === " ") {
                      e.preventDefault();
                      setNotifyOpen(false);
                      if (n.section) {
                        setSection(n.section);
                        setDrawerOpen(false);
                      }
                    }
                  }}>
                  <strong>${n.title}</strong>
                  <span>${n.text}</span>
                  <small>${new Date(n.at).toLocaleString()}</small>
                </div>`)}</div>`
            : html`<p class="modal-text">Nothing has come in yet.</p>`}
          <div class="modal-actions"><button class="ghost" type="button" onClick=${() => setNotifyOpen(false)}>Close</button></div>
        </div>
      </div>` : null}

      <main class="main">
        ${gate
          ? html`<${PageSkeleton} />`
          : html`<div key=${section + ":" + reloadKey}><${ProfileBanner} profile=${profile} />${panelEl}</div>`}
      </main>
    </div>
  `;
}

createRoot(document.getElementById("root")).render(html`<${App} />`);
