# Firestore rules merge — portal + admin (Oct 2026)

## Deploy
1. Firebase Console → Firestore → Rules, **or**
2. `firebase deploy --only firestore:rules` from the project that owns `verify-cgtia-cert`

Use the unified file: `firestore.rules` (same content in client/ and admin/).

## New / updated matches

| Collection | Read | Write |
|------------|------|--------|
| `schedule` | Signed-in | Admin, training-officer, registrar, instructor |
| `supportMessages` | Own email or staff | Create: own email; Update: staff; Delete: admin |
| `attendance` | Own email / uid or staff | Staff create/update |
| `grades` | Published + own email; staff all | Staff |
| `courses` / `assessments` | Signed-in | Staff (existing) |
| `certificates` | Public read | Staff (existing) |

## Transcript
- Admin **Transcript** panel: pick student, print, lock/unlock (`students.transcriptLocked`)
- Student portal reads published grades only
- Lock is an admin flag; grade saves ask for confirm if locked

## Staff doc required
`users/{uid}` → `{ role: "admin"|"registrar"|..., active: true }`
