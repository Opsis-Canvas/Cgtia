# CGTIA Admin CMS

Full control panel for the public client site (applications, students, certificates, content).

## Why data looked empty
Firestore only allows staff who have `users/{yourAuthUid}` with:
```
role: "super-admin"   // or "admin"
active: true
```

If `active` is false or the document is missing, applications/promotions will not load or save.

## Roles
- super-admin / admin — full control
- admissions — applications & payments read
- licensing-officer, registrar, training-officer, instructor — as in main rules
- student — portal only

## Sections

| Section | What it does |
|---------|----------------|
| **Dashboard** | App / payment counts |
| **Applications** | Intake from the public Apply form |
| **Payments** | Payment records |
| **Students** | Full student records (edit name, contact, programme, cohort, cert link) |
| **Certificates** | Generate verification codes, assign to a student, revoke / restore |
| **Users & roles** | Staff accounts |
| **Promotions** | Live pricing offers on the payment screen |
| **Programme cards** | Public programme catalogue |
| **Wall of Fame / Graduates** | Showcase entries (`photoUrl` e.g. `/assets/images/graduates/name.webp`) |
| **Partners** | Partner list (Hibernate hides from public) |
| **Messages** | Contact form inbox |
| **Insights** | Live snapshot |
| **Site settings** | Dates, modality, etc. |

## Profile invites (expiring links)
1. **Profile invites** → Create invite (optional email lock, expiry days)
2. Copy link: `https://YOUR-DOMAIN/field-check/confirm?token=…`
3. Send only to that student (WhatsApp/email)
4. Link works **once** and **expires**; after submit they get a **reg number** (`CGTIA-YYYYMM-0001`)
5. Walk-ins: leave email blank so they type their own (still unique — one profile per email/NIN)

## Certificates workflow
1. Open **Certificates** → **Issue new certificate**
2. Code is auto-generated (`CGTIA-YEAR-XXXX-####`); you can regenerate or type your own
3. Enter student name (and optional Students doc id)
4. Set programme, issue date, status (`valid` / `revoked` / `expired`)
5. Save — public site `/verify` looks up by code in the `certificates` collection

## Student records
Admin owns the student profile: edit contact details, programme, cohort, status, and link a certificate code. Use the same code in Certificates so verification stays consistent.

## Image paths on the client
Put files under the client site `assets/images/{folder}/` and reference them with a **leading slash**:
```
/assets/images/graduates/ada-okonkwo-2025.webp
/assets/images/gallery/lecture-sessions.webp
```
See client `assets/images/REQUIRED-FILES.txt` for the full list.

## Promotions on the public site
When a promotion is **Active**, the payment screen charges that amount for matching programmes.


## Photo URLs (not only local files)
In Graduates, Wall of Fame, Students, Certificates — `photoUrl` can be:
- `/assets/images/graduates/name.webp` (file on the client site)
- Any `https://...` image (Firebase Storage, CDN, public Google Drive direct link)

## Backup
Use **Backup / export** in the admin menu to download a JSON snapshot of Firestore data.

## Deploy Firestore rules (required for Fees tab)

The Fees & payment links feature needs these collections in your live rules:

- `feeDefinitions`
- `feePaymentLinks`

Deploy the included `firestore.rules` to project **verify-cgtia-cert**:

```bash
firebase deploy --only firestore:rules
```

Or paste the full `firestore.rules` file into Firebase Console → Firestore → Rules → Publish.

Until rules are published you will see **Missing or insufficient permissions** on the Fees page.
